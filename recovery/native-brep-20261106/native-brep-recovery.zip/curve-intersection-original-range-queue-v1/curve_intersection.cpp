#include "curve_intersection.h"
#include "brep_curve_use.h"
#include "nurbs_coincidence.h"
#include <numeric>
#include "closest.h"
#include "nurbs_interval.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <tuple>

namespace session_cpp::curve_intersection {
namespace {

constexpr double epsilon = std::numeric_limits<double>::epsilon();
constexpr size_t work_limit = 200000;

bool finite(const Vector& value) {
    return std::isfinite(value[0]) && std::isfinite(value[1]) && std::isfinite(value[2]);
}

bool finite_derivatives(const std::vector<Vector>& values) {
    for (const Vector& value : values)
        if (!finite(value))
            return false;

    return true;
}

std::pair<double, double> unresolved_parameters() {
    const double value = std::numeric_limits<double>::quiet_NaN();
    return {value, value};
}

struct Bounds {
    Point lo;
    Point hi;

    explicit Bounds(const NurbsCurve& curve) : lo(curve.get_cv(0)), hi(lo) {
        for (int i = 1; i < curve.cv_count(); ++i) {
            const Point p = curve.get_cv(i);
            for (int d = 0; d < 3; ++d) {
                lo[d] = std::min(lo[d], p[d]);
                hi[d] = std::max(hi[d], p[d]);
            }
        }
    }

    double size() const {
        return lo.distance(hi);
    }

    double magnitude() const {
        double result = 0.0;
        for (int d = 0; d < 3; ++d)
            result = std::max({result, std::abs(lo[d]), std::abs(hi[d])});

        return result;
    }

    bool overlaps(const Bounds& box, double tolerance) const {
        for (int d = 0; d < 3; ++d)
            if (hi[d] + tolerance < box.lo[d] || box.hi[d] + tolerance < lo[d])
                return false;

        return true;
    }
};

// A negative whole-input proof needs no parameter resolution or root refinement.
bool certified_disjoint(const NurbsCurve& a, const NurbsCurve& b, double tolerance) {
    const auto hull = [](const NurbsCurve& curve, std::array<nurbs_interval::Interval, 3>& box) {
        for (int i = 0; i < curve.cv_count(); ++i) {
            const double* cv = curve.cv(i);
            const double weight = curve.is_rational() ? cv[curve.dimension()] : 1.0;
            if (!(weight > 0) || !std::isfinite(weight))
                return false;
            for (int d = 0; d < 3; ++d) {
                const auto coordinate = nurbs_interval::Interval(d < curve.dimension() ? cv[d] : 0.0)
                    / nurbs_interval::Interval(weight);
                if (!nurbs_interval::finite(coordinate))
                    return false;
                box[d] = i == 0 ? coordinate : nurbs_interval::interval_hull(box[d], coordinate);
            }
        }
        return true;
    };
    std::array<nurbs_interval::Interval, 3> first, second;
    if (!hull(a, first) || !hull(b, second))
        return false;
    for (int d = 0; d < 3; ++d) {
        const auto gap = first[d] - second[d];
        if (nurbs_interval::finite(gap) && (gap.lo > tolerance || gap.hi < -tolerance))
            return true;
    }
    return false;
}

struct Pair {
    NurbsCurve a;
    NurbsCurve b;
    int depth = 0;
};

bool finite_positive(const NurbsCurve& curve) {
    for (int i = 0; i < curve.cv_count(); ++i) {
        const Point p = curve.get_cv(i);
        const double w = curve.weight(i);
        if (!std::isfinite(w) || w <= 0.0)
            return false;

        for (int d = 0; d < 3; ++d)
            if (!std::isfinite(p[d]))
                return false;
    }

    return true;
}

NurbsCurve interval(const NurbsCurve& curve, double a, double b) {
    NurbsCurve result = curve;
    if ((a > curve.domain_start() || b < curve.domain_end()) && !result.trim(a, b))
        throw std::runtime_error("Curve intersection could not trim a parameter interval");

    return result;
}

double flatness(const NurbsCurve& curve) {
    const Point a = curve.point_at_start();
    const Vector chord = curve.point_at_end() - a;
    const double length2 = chord.dot(chord);
    double distance = 0.0;
    double previous = 0.0;
    for (int i = 0; i < curve.cv_count(); ++i) {
        const Point p = curve.get_cv(i);
        const double t = length2 > 0.0 ? std::clamp((p - a).dot(chord) / length2, 0.0, 1.0) : 0.0;
        if (t + epsilon * 64.0 < previous)
            return Bounds(curve).size();

        previous = t;
        distance = std::max(distance, p.distance(a + chord * t));
    }

    return distance;
}

double closest_parameter(const NurbsCurve& curve, const Point& point) {
    double t = Closest::curve_point(curve, point).first;
    const double lo = curve.domain_start();
    const double hi = curve.domain_end();
    for (int i = 0; i < 32; ++i) {
        const std::vector<Vector> d = curve.evaluate(t, 2);
        const Vector r = curve.point_at(t) - point;
        const double den = d[1].dot(d[1]) + r.dot(d[2]);
        if (den <= 0.0)
            break;

        const double next = std::clamp(t - r.dot(d[1]) / den, lo, hi);
        if (next == t)
            break;

        t = next;
    }

    return t;
}

double binomial(int n, int k) {
    double result = 1.0;
    for (int i = 1; i <= std::min(k, n - k); ++i)
        result *= static_cast<double>(n + 1 - i) / i;

    return result;
}

bool same_parameterization(const NurbsCurve& a, const NurbsCurve& b, double tolerance) {
    const int n = a.degree();
    const int m = b.degree();
    if (a.cv_count() != n + 1 || b.cv_count() != m + 1)
        return false;

    double wa = 0.0;
    double wb = 0.0;
    for (int i = 0; i <= n; ++i)
        wa = std::max(wa, a.weight(i));
    for (int j = 0; j <= m; ++j)
        wb = std::max(wb, b.weight(j));

    double minimum = 1.0;
    for (int i = 0; i <= n; ++i)
        for (int j = 0; j <= m; ++j)
            minimum = std::min(minimum, (a.weight(i) / wa) * (b.weight(j) / wb));

    for (int k = 0; k <= n + m; ++k) {
        Vector coefficient(0, 0, 0);
        for (int i = std::max(0, k - m); i <= std::min(n, k); ++i) {
            const int j = k - i;
            const double factor = binomial(n, i) * binomial(m, j) / binomial(n + m, k);
            const double weight = (a.weight(i) / wa) * (b.weight(j) / wb);
            coefficient += (a.get_cv(i) - b.get_cv(j)) * (factor * weight);
        }
        const double distance = coefficient.magnitude();
        if (!std::isfinite(distance) || distance > tolerance * minimum)
            return false;
    }

    return true;
}

bool same_geometry(const NurbsCurve& a, const NurbsCurve& b, double tolerance) {
    if (same_parameterization(a, b, tolerance))
        return true;

    NurbsCurve first = a;
    NurbsCurve second = b;
    const int degree = std::max(a.degree(), b.degree());
    if ((a.degree() < degree && !first.increase_degree(degree)) ||
        (b.degree() < degree && !second.increase_degree(degree)))
        return false;

    const double start = std::log(second.weight(0)) - std::log(first.weight(0));
    const double end = std::log(second.weight(degree)) - std::log(first.weight(degree));
    const double ratio = (end - start) / degree;
    double maximum = -std::numeric_limits<double>::infinity();
    for (int i = 0; i <= degree; ++i)
        maximum = std::max(maximum, std::log(first.weight(i)) + i * ratio);

    for (int i = 0; i <= degree; ++i) {
        const Point point = first.get_cv(i);
        const double weight = std::exp(std::log(first.weight(i)) + i * ratio - maximum);
        if (weight <= 0.0 || !first.set_cv_4d(
            i,
            point[0] * weight,
            point[1] * weight,
            point[2] * weight,
            weight
        ))
            return false;
    }

    return same_parameterization(first, second, tolerance);
}

std::vector<std::pair<double, double>> endpoint_matches(const Pair& pair, double tolerance) {
    std::vector<std::pair<double, double>> matches;
    for (const double ta : {pair.a.domain_start(), pair.a.domain_end()}) {
        const Point p = pair.a.point_at(ta);
        const double tb = closest_parameter(pair.b, p);
        if (p.distance(pair.b.point_at(tb)) <= tolerance)
            matches.emplace_back(ta, tb);
    }
    for (const double tb : {pair.b.domain_start(), pair.b.domain_end()}) {
        const Point p = pair.b.point_at(tb);
        const double ta = closest_parameter(pair.a, p);
        if (p.distance(pair.a.point_at(ta)) <= tolerance)
            matches.emplace_back(ta, tb);
    }
    std::sort(matches.begin(), matches.end());

    return matches;
}

bool overlap(const Pair& pair, double tolerance, Overlap& result) {
    // The pieces end to end first: a closest point search can miss an exact end by more than this proof.
    if (pair.a.point_at_start().distance(pair.b.point_at_start()) <= tolerance &&
        pair.a.point_at_end().distance(pair.b.point_at_end()) <= tolerance && same_geometry(pair.a, pair.b, tolerance)) {
        result = {pair.a.domain_start(), pair.a.domain_end(), pair.b.domain_start(), pair.b.domain_end()};
        return true;
    }

    const std::vector<std::pair<double, double>> matches = endpoint_matches(pair, tolerance);
    for (size_t i = 0; i < matches.size(); ++i)
        for (size_t j = matches.size(); j-- > i + 1;) {
            const double a0 = matches[i].first;
            const double a1 = matches[j].first;
            const double b0 = matches[i].second;
            const double b1 = matches[j].second;
            if (a1 - a0 <= epsilon * 32.0 || std::abs(b1 - b0) <= epsilon * 32.0)
                continue;

            const NurbsCurve a = interval(pair.a, a0, a1);
            NurbsCurve b = interval(pair.b, std::min(b0, b1), std::max(b0, b1));
            if (b1 < b0 && !b.reverse())
                continue;

            const bool linear = flatness(a) <= tolerance && flatness(b) <= tolerance;
            if (linear || same_geometry(a, b, tolerance)) {
                result = {a0, a1, b0, b1};
                return true;
            }
        }

    return false;
}

std::vector<double> split_parameters(const NurbsCurve& curve, double a, double b) {
    const double lo = curve.domain_start();
    const double hi = curve.domain_end();
    std::vector<double> result{lo, hi};
    for (const double t : {a, b})
        if (t > lo + epsilon * 32.0 && t < hi - epsilon * 32.0)
            result.push_back(t);

    std::sort(result.begin(), result.end());
    result.erase(std::unique(result.begin(), result.end()), result.end());
    return result;
}

void remaining_pairs(const Pair& pair, const Overlap& shared, std::vector<Pair>& work) {
    const std::vector<double> a = split_parameters(pair.a, shared.a0, shared.a1);
    const std::vector<double> b = split_parameters(pair.b, shared.b0, shared.b1);
    const double b0 = std::min(shared.b0, shared.b1);
    const double b1 = std::max(shared.b0, shared.b1);
    for (size_t i = 1; i < a.size(); ++i)
        for (size_t j = 1; j < b.size(); ++j) {
            if (a[i - 1] >= shared.a0 && a[i] <= shared.a1 && b[j - 1] >= b0 && b[j] <= b1)
                continue;

            work.push_back({interval(pair.a, a[i - 1], a[i]), interval(pair.b, b[j - 1], b[j])});
        }
}

std::pair<double, double> refine(const Pair& pair, double ta, double tb) {
    for (int i = 0; i < 80; ++i) {
        const std::vector<Vector> a = pair.a.evaluate(ta, 2);
        const std::vector<Vector> b = pair.b.evaluate(tb, 2);
        if (!finite_derivatives(a) || !finite_derivatives(b))
            return unresolved_parameters();

        const Vector r = a[0] - b[0];
        const double uu = a[1].dot(a[1]);
        const double vv = b[1].dot(b[1]);
        const double ru = r.dot(a[2]);
        const double rv = r.dot(b[2]);
        const double aa = uu + ru;
        const double ab = -a[1].dot(b[1]);
        const double bb = vv - rv;
        const double ar = -a[1].dot(r);
        const double br = b[1].dot(r);
        const double det = a[1].cross(b[1]).magnitude_squared() + ru * vv - rv * uu - ru * rv;
        if (!std::isfinite(det) || !std::isfinite(ar) || !std::isfinite(br))
            return unresolved_parameters();
        if (aa <= 0.0 || bb <= 0.0 || det <= 0.0)
            break;

        const double da = (bb * ar - ab * br) / det;
        const double db = (aa * br - ab * ar) / det;
        if (!std::isfinite(da) || !std::isfinite(db))
            return unresolved_parameters();
        double step = 1.0;
        bool accepted = false;
        for (int k = 0; k < 16; ++k) {
            const double na = std::clamp(ta + da * step, pair.a.domain_start(), pair.a.domain_end());
            const double nb = std::clamp(tb + db * step, pair.b.domain_start(), pair.b.domain_end());
            if (pair.a.point_at(na).distance(pair.b.point_at(nb)) <= r.magnitude()) {
                accepted = na != ta || nb != tb;
                ta = na;
                tb = nb;
                break;
            }
            step *= 0.5;
        }
        if (!accepted)
            break;
    }

    return {ta, tb};
}

std::pair<double, double> refine_tangent(const Pair& pair, double ta, double tb) {
    const double scale = Bounds(pair.a).size() * Bounds(pair.b).size();
    for (int i = 0; i < 16; ++i) {
        const std::vector<Vector> a = pair.a.evaluate(ta, 2);
        const std::vector<Vector> b = pair.b.evaluate(tb, 2);
        if (!finite_derivatives(a) || !finite_derivatives(b))
            return unresolved_parameters();

        const double uu = a[1].dot(a[1]);
        const double vv = b[1].dot(b[1]);
        const double divisor = std::sqrt(uu * vv);
        if (!std::isfinite(divisor))
            return unresolved_parameters();
        if (divisor == 0.0)
            break;

        const Vector cross = a[1].cross(b[1]) / divisor;
        if (cross.magnitude() > 1e-4)
            break;

        const Vector ca = a[2].cross(b[1]) / divisor - cross * (a[1].dot(a[2]) / uu);
        const Vector cb = a[1].cross(b[2]) / divisor - cross * (b[1].dot(b[2]) / vv);
        const Vector r = a[0] - b[0];
        const double aa = uu + scale * ca.dot(ca);
        const double ab = -a[1].dot(b[1]) + scale * ca.dot(cb);
        const double bb = vv + scale * cb.dot(cb);
        const double ar = -a[1].dot(r) - scale * ca.dot(cross);
        const double br = b[1].dot(r) - scale * cb.dot(cross);
        const double det = aa * bb - ab * ab;
        if (!std::isfinite(det) || !std::isfinite(ar) || !std::isfinite(br))
            return unresolved_parameters();
        if (det <= epsilon * aa * bb)
            break;

        const double na = std::clamp(ta + (bb * ar - ab * br) / det, pair.a.domain_start(), pair.a.domain_end());
        const double nb = std::clamp(tb + (aa * br - ab * ar) / det, pair.b.domain_start(), pair.b.domain_end());
        if (na == ta && nb == tb)
            break;

        ta = na;
        tb = nb;
    }

    return {ta, tb};
}

double parameter_tolerance(const NurbsCurve& curve, double t, double tolerance) {
    const std::vector<Vector> d = curve.evaluate(t, 1);
    const double speed = d[1].magnitude();
    return std::max(epsilon * 128.0, tolerance / std::max(speed, tolerance));
}

bool add_hit(const Pair& pair, const Pair& leaf, double tolerance, Result& result) {
    double ta = 0.0;
    double tb = 0.0;
    double distance = 0.0;
    std::tie(ta, tb, distance) = Closest::curve_curve(leaf.a, leaf.b);
    if (!std::isfinite(ta) || !std::isfinite(tb) || !std::isfinite(distance))
        return false;

    std::tie(ta, tb) = refine(pair, ta, tb);
    if (!std::isfinite(ta) || !std::isfinite(tb))
        return false;
    const std::pair<double, double> tangent = refine_tangent(pair, ta, tb);
    if (!std::isfinite(tangent.first) || !std::isfinite(tangent.second))
        return false;
    const double roundoff = epsilon * 64.0 * std::max(Bounds(pair.a).magnitude(), Bounds(pair.b).magnitude());
    if (pair.a.point_at(tangent.first).distance(pair.b.point_at(tangent.second)) <= std::min(tolerance, roundoff)) {
        ta = tangent.first;
        tb = tangent.second;
    }
    // Curves that run on through a shared end stay within tolerance a little before it: the hit is that end.
    for (const double ea : {pair.a.domain_start(), pair.a.domain_end()})
        for (const double eb : {pair.b.domain_start(), pair.b.domain_end()})
            if (pair.a.point_at(ea).distance(pair.b.point_at(eb)) <= tolerance &&
                pair.a.point_at(ta).distance(pair.a.point_at(ea)) <= tolerance * 4.0 &&
                pair.b.point_at(tb).distance(pair.b.point_at(eb)) <= tolerance * 4.0) {
                ta = ea;
                tb = eb;
            }
    // A hit at a curve's own end to roundoff is that end: vertices are told apart by exact parameter.
    for (const double end : {pair.a.domain_start(), pair.a.domain_end()})
        if (pair.a.point_at(ta).distance(pair.a.point_at(end)) <= roundoff)
            ta = end;
    for (const double end : {pair.b.domain_start(), pair.b.domain_end()})
        if (pair.b.point_at(tb).distance(pair.b.point_at(end)) <= roundoff)
            tb = end;
    const Point a = pair.a.point_at(ta);
    const Point b = pair.b.point_at(tb);
    const double gap = a.distance(b);
    if (!std::isfinite(gap))
        return false;
    if (gap > tolerance)
        return true;

    const double ea = parameter_tolerance(pair.a, ta, tolerance * 2.0);
    const double eb = parameter_tolerance(pair.b, tb, tolerance * 2.0);
    for (const Hit& hit : result.points)
        if (std::abs(ta - hit.a) <= ea && std::abs(tb - hit.b) <= eb)
            return true;

    const Vector u = pair.a.evaluate(ta, 1)[1];
    const Vector v = pair.b.evaluate(tb, 1)[1];
    if (!finite(u) || !finite(v))
        return false;
    const bool touching = u.cross(v).magnitude() <= 1e-6 * u.magnitude() * v.magnitude();
    result.points.push_back({a + (b - a) * 0.5, ta, tb, touching});
    return true;
}

bool subdivide(const Pair& pair, bool first, std::vector<Pair>& work) {
    const NurbsCurve& curve = first ? pair.a : pair.b;
    const double mid = curve.domain_middle();
    if (mid <= curve.domain_start() || mid >= curve.domain_end())
        return false;

    NurbsCurve left;
    NurbsCurve right;
    if (!curve.split(mid, left, right))
        return false;

    if (first) {
        work.push_back({left, pair.b, pair.depth + 1});
        work.push_back({right, pair.b, pair.depth + 1});
    } else {
        work.push_back({pair.a, left, pair.depth + 1});
        work.push_back({pair.a, right, pair.depth + 1});
    }
    return true;
}

bool isolated(const Pair& pair, double tolerance, size_t& budget, Result& result) {
    std::vector<Pair> work{pair};
    while (!work.empty()) {
        if (budget++ >= work_limit)
            return false;

        const Pair leaf = std::move(work.back());
        work.pop_back();
        const Bounds a(leaf.a);
        const Bounds b(leaf.b);
        if (!a.overlaps(b, tolerance))
            continue;

        const double fa = flatness(leaf.a);
        const double fb = flatness(leaf.b);
        if (fa <= tolerance * 0.05 && fb <= tolerance * 0.05) {
            if (!add_hit(pair, leaf, tolerance, result)) {
                result.failure = "Curve intersection encountered a nonfinite numerical result";
                return false;
            }
            continue;
        }
        // The longer piece: a flat line left whole keeps a box that holds every curved piece under it.
        if (leaf.depth >= 96 || !subdivide(leaf, a.size() >= b.size(), work))
            return false;
    }

    return true;
}

nurbs_interval::Interval binomial_bound(int n, int k) {
    nurbs_interval::Interval result(1.0);
    for (int i = 1; i <= std::min(k, n - k); ++i)
        result = result * nurbs_interval::Interval(n + 1 - i) / nurbs_interval::Interval(i);
    return result;
}

/// Bound the whole normalized correspondence, retaining a common range rather than one point.
bool certified_original_parameter_range(const NurbsCurve& first,const std::pair<double,double>& ar,
    const NurbsCurve& second,const std::pair<double,double>& br,double tolerance,bool reverse) {
    using nurbs_interval::Interval;
    const Point point = first.get_cv(0);
    const std::array<double, 3> origin = {point[0], point[1], point[2]};
    const auto a = nurbs_interval::curve_controls(first,{ar.first,ar.second},origin);
    auto b = nurbs_interval::curve_controls(second,{br.first,br.second},origin);
    if (a.empty() || b.empty())
        return false;
    if (reverse)
        std::reverse(b.begin(), b.end());
    double denominator = std::numeric_limits<double>::infinity();
    for (const auto& first : a)
        for (const auto& second : b) {
            if (!(first[3].lo > 0.0 && second[3].lo > 0.0))
                return false;
            const Interval product = first[3] * second[3];
            if (!nurbs_interval::finite(product) || !(product.lo > 0.0))
                return false;
            denominator = std::min(denominator, product.lo);
        }
    const int n = static_cast<int>(a.size()) - 1;
    const int m = static_cast<int>(b.size()) - 1;
    std::array<Interval, 3> bounds;
    for (int k = 0; k <= n + m; ++k) {
        std::array<Interval, 3> coefficient;
        for (int i = std::max(0, k - m); i <= std::min(n, k); ++i) {
            const int j = k - i;
            const Interval factor = binomial_bound(n, i) * binomial_bound(m, j) / binomial_bound(n + m, k);
            for (int d = 0; d < 3; ++d)
                coefficient[d] = coefficient[d] + factor * (a[i][d] * b[j][3] - b[j][d] * a[i][3]);
        }
        for (int d = 0; d < 3; ++d) {
            if (!nurbs_interval::finite(coefficient[d]))
                return false;
            bounds[d] = k == 0 ? coefficient[d] : nurbs_interval::interval_hull(bounds[d], coefficient[d]);
        }
    }
    Interval squared;
    for (const auto coordinate : bounds) {
        const Interval distance(nurbs_interval::magnitude(coordinate));
        squared = squared + distance * distance;
    }
    const Interval limit = Interval(tolerance) * Interval(tolerance) * Interval(denominator) * Interval(denominator);
    return nurbs_interval::finite(squared) && nurbs_interval::finite(limit) && squared.hi <= limit.lo;
}

bool certified_parameter_range(const Pair& pair,double tolerance,bool reverse) {
    return certified_original_parameter_range(pair.a,pair.a.domain(),pair.b,pair.b.domain(),tolerance,reverse);
}

bool certified_clipped_range(const Pair& pair, double tolerance, Overlap& shared) {
    const auto matches = endpoint_matches(pair, tolerance);
    for (size_t i = 0; i < matches.size(); ++i)
        for (size_t j = matches.size(); j-- > i + 1;) {
            const double a0 = matches[i].first, a1 = matches[j].first;
            const double b0 = matches[i].second, b1 = matches[j].second;
            if (!std::isfinite(a0) || !std::isfinite(a1) || !std::isfinite(b0) || !std::isfinite(b1)
                || a0 < pair.a.domain_start() || a1 > pair.a.domain_end()
                || std::min(b0, b1) < pair.b.domain_start() || std::max(b0, b1) > pair.b.domain_end()
                || a1 - a0 <= epsilon * 32.0 || std::abs(b1 - b0) <= epsilon * 32.0)
                continue;
            const Pair clipped{interval(pair.a, a0, a1), interval(pair.b, std::min(b0, b1), std::max(b0, b1))};
            if (certified_parameter_range(clipped, tolerance, b1 < b0)) {
                shared = {clipped.a.domain_start(), clipped.a.domain_end(),
                    b1 < b0 ? clipped.b.domain_end() : clipped.b.domain_start(),
                    b1 < b0 ? clipped.b.domain_start() : clipped.b.domain_end()};
                return true;
            }
        }
    return false;
}

bool process(const Pair& pair, double tolerance, size_t& budget, Result& result) {
    const Bounds a(pair.a);
    const Bounds b(pair.b);
    if (!a.overlaps(b, tolerance))
        return true;

    const double proof = std::max(tolerance * 1e-5, epsilon * 32.0 * std::max(a.magnitude(), b.magnitude()));
    Overlap shared{};
    if (!overlap(pair, proof, shared)) {
        const bool flat = flatness(pair.a) <= tolerance * 0.05 && flatness(pair.b) <= tolerance * 0.05;
        for (bool reverse : {false, true})
            if (certified_parameter_range(pair, tolerance, reverse)) {
                result.overlaps.push_back({pair.a.domain_start(), pair.a.domain_end(),
                    reverse ? pair.b.domain_end() : pair.b.domain_start(),
                    reverse ? pair.b.domain_start() : pair.b.domain_end()});
                return true;
            }
        if (!flat || !certified_clipped_range(pair, tolerance, shared))
            return isolated(pair, tolerance, budget, result);
    }

    result.overlaps.push_back(shared);
    std::vector<Pair> work;
    remaining_pairs(pair, shared, work);
    for (const Pair& piece : work)
        if (!isolated(piece, tolerance, budget, result))
            return false;

    return true;
}

struct SpanBounds {
    nurbs_interval::CurveBounds box;
    bool valid;
};

std::vector<SpanBounds> span_bounds(const NurbsCurve& curve, const std::vector<double>& knots) {
    std::vector<SpanBounds> result;
    for (size_t i = 1; i < knots.size(); ++i) {
        SpanBounds span{};
        span.valid = nurbs_interval::curve_bounds(curve, {knots[i - 1], knots[i]}, {0, 0, 0}, span.box);
        result.push_back(span);
    }
    return result;
}

bool separated(const SpanBounds& a, const SpanBounds& b, double tolerance) {
    if (!a.valid || !b.valid)
        return false;
    for (int d = 0; d < 3; ++d) {
        const auto gap = a.box.point[d] - b.box.point[d];
        if (gap.lo > tolerance || gap.hi < -tolerance)
            return true;
    }
    return false;
}

bool hit_less(const Hit& a, const Hit& b) {
    return a.a < b.a || (a.a == b.a && a.b < b.b);
}

bool overlap_less(const Overlap& a, const Overlap& b) {
    return a.a0 < b.a0 || (a.a0 == b.a0 && a.b0 < b.b0);
}

void merge_overlaps(Result& result) {
    std::sort(result.overlaps.begin(), result.overlaps.end(), overlap_less);
    std::vector<Overlap> merged;
    for (const Overlap& overlap : result.overlaps) {
        if (!merged.empty()) {
            Overlap& last = merged.back();
            const bool aligned = (last.b1 - last.b0) * (overlap.b1 - overlap.b0) > 0.0;
            if (aligned && std::abs(last.a1 - overlap.a0) <= epsilon * 256.0 &&
                std::abs(last.b1 - overlap.b0) <= epsilon * 256.0) {
                last.a1 = overlap.a1;
                last.b1 = overlap.b1;
                continue;
            }
        }
        merged.push_back(overlap);
    }
    result.overlaps = std::move(merged);
}

// Positive B-spline basis is independent on each open knot span. A rational image
// is constant there iff all active homogeneous poles are proportional.
bool original_nonconstant_span(const NurbsCurve& curve,const std::pair<double,double>& range) {
    auto knots=curve.m_nurbsknot;knots.insert(knots.begin(),knots.front());knots.push_back(knots.back());
    const int degree=curve.degree();
    const int span=std::clamp(static_cast<int>(std::upper_bound(knots.begin(),knots.end(),range.first)-knots.begin())-1,
        degree,curve.cv_count()-1);
    if (range.first<knots[span] || range.second>knots[span+1]) return false;
    const int first=span-degree;const double weight=curve.weight(first);
    for (int i=first+1;i<=span;++i) for (int d=0;d<curve.dimension();++d)
        if (!nurbs_coincidence::exact_products_equal(curve.cv(first)[d],curve.weight(i),curve.cv(i)[d],weight)) return true;
    return false;
}
bool original_queue_basis(const NurbsCurve& curve) {
    const int p=curve.degree(),count=curve.cv_count();const auto& knots=curve.m_nurbsknot;
    if (p<1 || count<=p || knots.size()!=static_cast<size_t>(count+p-1)) return false;
    const auto range=curve.domain();
    for (int i=0;i<p;++i) if (knots[i]!=range.first || knots[knots.size()-1-i]!=range.second) return false;
    for (size_t i=0;i<knots.size();) {
        size_t j=i+1;while (j<knots.size() && knots[j]==knots[i]) ++j;
        if (!std::isfinite(knots[i]) || (i && knots[i]<knots[i-1]) ||
            (knots[i]>range.first && knots[i]<range.second && j-i>static_cast<size_t>(p))) return false;
        i=j;
    }
    return true;
}
struct OriginalPair {
    const NurbsCurve* a;
    const NurbsCurve* b;
    std::pair<double,double> ar,br;
    int depth=0;
};
bool original_range_box(const NurbsCurve& curve,const std::pair<double,double>& range,nurbs_interval::CurveBounds& box) {
    return nurbs_interval::curve_bounds(curve,{range.first,range.second},{0,0,0},box);
}
bool original_boxes_separated(const nurbs_interval::CurveBounds& a,const nurbs_interval::CurveBounds& b,double tolerance) {
    for (int d=0;d<3;++d) {
        const auto gap=a.point[d]-b.point[d];
        if (nurbs_interval::finite(gap) && (gap.lo>tolerance || gap.hi < -tolerance)) return true;
    }
    return false;
}
// Exact arithmetic is a sufficient line-point proposal, followed by ORIGINAL singleton proof.
bool original_line_hit(const OriginalPair& pair,double tolerance,Hit& hit) {
    const auto difference=[](double a,double b,double& value) {
        return nurbs_coincidence::exact_difference(a,b,value) && std::isfinite(value);
    };
    const auto product=[](double a,double b,double& value) {
        value=a*b;return std::isfinite(value) && nurbs_coincidence::exact_products_equal(a,b,value,1.);
    };
    const auto det=[&](double a,double b,double c,double d,double& value) {
        double first,last;return product(a,b,first) && product(c,d,last) && difference(first,last,value);
    };
    const auto line=[&](const NurbsCurve& curve,std::array<double,3>& start,std::array<double,3>& direction) {
        if (curve.degree()!=1 || curve.cv_count()!=2 || curve.weight(0)!=curve.weight(1)) return false;
        const double weight=curve.weight(0);
        for (int d=0;d<3;++d) {
            const double h0=d<curve.dimension()?curve.cv(0)[d]:0,h1=d<curve.dimension()?curve.cv(1)[d]:0;
            const double first=h0/weight,last=h1/weight;
            if (!std::isfinite(first) || !std::isfinite(last) ||
                !nurbs_coincidence::exact_products_equal(first,weight,h0,1.) ||
                !nurbs_coincidence::exact_products_equal(last,weight,h1,1.) || !difference(last,first,direction[d])) return false;
            start[d]=first;
        }
        return true;
    };
    std::array<double,3> a,b,u,v,rhs;
    if (!line(*pair.a,a,u) || !line(*pair.b,b,v)) return false;
    for (int d=0;d<3;++d) if (!difference(b[d],a[d],rhs[d])) return false;
    double denominator=0,na=0,nb=0;bool independent=false;
    for (int i=0;i<3 && !independent;++i) for (int j=i+1;j<3 && !independent;++j) {
        if (!det(u[i],v[j],u[j],v[i],denominator)) return false;
        if (denominator==0) continue;
        if (!det(rhs[i],v[j],rhs[j],v[i],na) || !det(rhs[i],u[j],rhs[j],u[i],nb)) return false;
        independent=true;
    }
    if (!independent) return false;
    const double sa=na/denominator,sb=nb/denominator;
    if (!std::isfinite(sa) || !std::isfinite(sb) ||
        !nurbs_coincidence::exact_products_equal(sa,denominator,na,1.) ||
        !nurbs_coincidence::exact_products_equal(sb,denominator,nb,1.)) return false;
    const auto raw=[&](const NurbsCurve& curve,double fraction,double& t) {
        double width,offset;
        return difference(curve.domain_end(),curve.domain_start(),width) && product(fraction,width,offset) &&
            difference(curve.domain_start(),-offset,t);
    };
    double ta,tb;
    if (!raw(*pair.a,sa,ta) || !raw(*pair.b,sb,tb) || ta<pair.ar.first || ta>pair.ar.second ||
        tb<pair.br.first || tb>pair.br.second) return false;
    Point point;
    for (int d=0;d<3;++d) {
        double da,db,pa,pb;
        if (!product(sa,u[d],da) || !product(sb,v[d],db) || !difference(a[d],-da,pa) ||
            !difference(b[d],-db,pb) || pa!=pb) return false;
        point[d]=pa;
    }
    if (!nurbs_interval::curve_within_ball(*pair.a,{ta,ta},{point[0],point[1],point[2]},tolerance*.25) ||
        !nurbs_interval::curve_within_ball(*pair.b,{tb,tb},{point[0],point[1],point[2]},tolerance*.25)) return false;
    hit={point,ta,tb,false};return true; // Two nonparallel injective original lines have at most this one root.
}
std::vector<double> original_range_knots(const NurbsCurve& curve,const std::pair<double,double>& range) {
    std::vector<double> result{range.first,range.second};
    for (double knot:curve.get_span_vector()) if (knot>range.first && knot<range.second) result.push_back(knot);
    std::sort(result.begin(),result.end());result.erase(std::unique(result.begin(),result.end()),result.end());return result;
}
Result original_range_queue(const NurbsCurve& a,const std::pair<double,double>& ar,
                           const NurbsCurve& b,const std::pair<double,double>& br,double tolerance) {
    Result result;
    const auto fail=[&](const char* reason) { result.complete=false;result.failure=reason; };
    if (!finite_positive(a) || !finite_positive(b)) {
        fail("Original-range curve intersection requires finite positive weights");return result;
    }
    if (!original_queue_basis(a) || !original_queue_basis(b)) {
        fail("Original-range worker requires an exact clamped continuous positive basis");return result;
    }
    const auto av=original_range_knots(a,ar),bv=original_range_knots(b,br);
    std::vector<nurbs_interval::CurveBounds> ab(av.size()-1),bb(bv.size()-1);
    for (size_t i=1;i<av.size();++i) if (!original_range_box(a,{av[i-1],av[i]},ab[i-1])) {
        fail("Original first-curve range has no finite interval enclosure");return result;
    }
    for (size_t i=1;i<bv.size();++i) if (!original_range_box(b,{bv[i-1],bv[i]},bb[i-1])) {
        fail("Original second-curve range has no finite interval enclosure");return result;
    }
    std::vector<OriginalPair> work;size_t budget=0;
    for (size_t i=1;i<av.size();++i) for (size_t j=1;j<bv.size();++j) {
        if (++budget>work_limit) { fail("Original-range pair partition exceeded the existing work budget");return result; }
        if (!original_boxes_separated(ab[i-1],bb[j-1],tolerance))
            work.push_back({&a,&b,{av[i-1],av[i]},{bv[j-1],bv[j]}});
    }
    while (!work.empty()) {
        if (++budget>work_limit) { fail("Original-range subdivision exceeded the existing work budget");break; }
        const auto pair=work.back();work.pop_back();
        nurbs_interval::CurveBounds first,second;
        if (!original_range_box(a,pair.ar,first) || !original_range_box(b,pair.br,second)) {
            fail("Original-range subdivision has no finite original enclosure");break;
        }
        if (original_boxes_separated(first,second,tolerance)) continue;
        bool common=false;
        // A whole original knot-pair correspondence covers both loci. Do not turn a
        // merely small subdivided curved root box into a new common interval.
        if (pair.depth==0 && original_nonconstant_span(a,pair.ar) && original_nonconstant_span(b,pair.br))
            for (bool reverse:{false,true})
            if (certified_original_parameter_range(a,pair.ar,b,pair.br,tolerance,reverse)) {
                result.overlaps.push_back({pair.ar.first,pair.ar.second,
                    reverse?pair.br.second:pair.br.first,reverse?pair.br.first:pair.br.second});common=true;break;
            }
        if (common) continue;
        Hit hit;
        if (original_line_hit(pair,tolerance,hit)) { result.points.push_back(hit);continue; }
        if (pair.depth>=96) { fail("Original-range isolated root coverage remains unresolved");break; }
        const auto size=[](const auto& box) {
            double value=0;for (const auto& coordinate:box.point) value=std::max(value,coordinate.hi-coordinate.lo);return value;
        };
        bool split_first=size(first)>=size(second);
        const auto middle=[](const auto& range) { return std::midpoint(range.first,range.second); };
        double mid=middle(split_first?pair.ar:pair.br);
        const auto interior=[](const auto& range,double t) { return t>range.first && t<range.second; };
        if (!interior(split_first?pair.ar:pair.br,mid)) {
            split_first=!split_first;mid=middle(split_first?pair.ar:pair.br);
        }
        if (!interior(split_first?pair.ar:pair.br,mid)) {
            fail("Original-range root has no representable subdivision; coverage unresolved");break;
        }
        auto left=pair,right=pair;left.depth=right.depth=pair.depth+1;
        if (split_first) { left.ar.second=mid;right.ar.first=mid; }
        else { left.br.second=mid;right.br.first=mid; }
        work.push_back(right);work.push_back(left);
    }
    std::sort(result.points.begin(),result.points.end(),hit_less);
    result.points.erase(std::unique(result.points.begin(),result.points.end(),[](const auto& x,const auto& y) {
        return x.a==y.a && x.b==y.b;
    }),result.points.end());
    std::sort(result.overlaps.begin(),result.overlaps.end(),overlap_less);
    result.overlaps.erase(std::unique(result.overlaps.begin(),result.overlaps.end(),[](const auto& x,const auto& y) {
        return x.a0==y.a0 && x.a1==y.a1 && x.b0==y.b0 && x.b1==y.b1;
    }),result.overlaps.end());
    return result; // Literal ORIGINAL raw values: no map_result, epsilon merging or receipt suppression.
}

void map_result(const NurbsCurve& a, const NurbsCurve& b, Result& result) {
    const double a0 = a.domain_start();
    const double b0 = b.domain_start();
    const double a1 = a.domain_end();
    const double b1 = b.domain_end();
    const double da = a1 - a0;
    const double db = b1 - b0;
    std::sort(result.points.begin(), result.points.end(), hit_less);
    merge_overlaps(result);
    std::vector<Hit> points;
    for (Hit hit : result.points) {
        bool covered = false;
        for (const Overlap& shared : result.overlaps)
            if (hit.a >= shared.a0 - epsilon * 256.0 && hit.a <= shared.a1 + epsilon * 256.0 &&
                hit.b >= std::min(shared.b0, shared.b1) - epsilon * 256.0 &&
                hit.b <= std::max(shared.b0, shared.b1) + epsilon * 256.0)
                covered = true;

        if (covered)
            continue;

        hit.a = std::clamp(a0 + hit.a * da, a0, a1);
        hit.b = std::clamp(b0 + hit.b * db, b0, b1);
        points.push_back(hit);
    }
    result.points = std::move(points);
    for (Overlap& shared : result.overlaps) {
        shared.a0 = std::clamp(a0 + shared.a0 * da, a0, a1);
        shared.a1 = std::clamp(a0 + shared.a1 * da, a0, a1);
        shared.b0 = std::clamp(b0 + shared.b0 * db, b0, b1);
        shared.b1 = std::clamp(b0 + shared.b1 * db, b0, b1);
    }
}

}

Result intersect(const NurbsCurve& a, const NurbsCurve& b, double tolerance) {
    if (!std::isfinite(tolerance) || tolerance <= 0.0 || !a.is_valid() || !b.is_valid())
        throw std::invalid_argument("Curve intersection requires valid curves and a positive finite tolerance");

    Result result;
    if (!finite_positive(a) || !finite_positive(b)) {
        result.complete = false;
        result.failure = "Curve intersection requires finite controls and positive rational weights";
        return result;
    }
    const Bounds bounds_a(a);
    const Bounds bounds_b(b);
    if (bounds_a.size() == 0.0 || bounds_b.size() == 0.0 ||
        epsilon * 32.0 * std::max(bounds_a.magnitude(), bounds_b.magnitude()) > tolerance) {
        if (bounds_a.size() > 0.0 && bounds_b.size() > 0.0 && certified_disjoint(a, b, tolerance))
            return result;
        result.complete = false;
        result.failure = "Curve intersection has a constant input or tolerance below coordinate resolution";
        if (const char* path = std::getenv("SESSION_CC_GUARD_FAILURE"); path && *path) {
            try {
                std::ofstream output(path, std::ios::app);
                if (!output)
                    throw std::runtime_error("cannot open capture file");
                const nlohmann::ordered_json saved = {{"stage", "curve_intersection_input_guard"},
                    {"failure", result.failure}, {"uv_tolerance", tolerance},
                    {"section_pcurve", a.jsondump()}, {"boundary_pcurve", b.jsondump()},
                    {"first_size", bounds_a.size()}, {"second_size", bounds_b.size()},
                    {"first_magnitude", bounds_a.magnitude()}, {"second_magnitude", bounds_b.magnitude()},
                    {"coordinate_resolution", epsilon * 32.0 * std::max(bounds_a.magnitude(), bounds_b.magnitude())}};
                output << saved.dump() << '\n';
                if (!output)
                    throw std::runtime_error("cannot write capture record");
                output.flush();
                if (!output)
                    throw std::runtime_error("cannot flush capture file");
                output.close();
                if (output.fail())
                    throw std::runtime_error("cannot close capture file");
            } catch (const std::exception& error) {
                std::cerr << "Curve intersection guard capture failed: " << error.what() << '\n';
            } catch (...) {
                std::cerr << "Curve intersection guard capture failed: unknown error\n";
            }
        }
        return result;
    }
    NurbsCurve first = a;
    NurbsCurve second = b;
    if (!first.set_domain(0.0, 1.0) || !second.set_domain(0.0, 1.0))
        throw std::runtime_error("Curve intersection could not normalize parameter domains");

    const std::vector<double> av = first.get_span_vector();
    const std::vector<double> bv = second.get_span_vector();
    const auto ab = span_bounds(first, av), bb = span_bounds(second, bv);
    size_t budget = 0;
    for (size_t i = 1; i < av.size() && result.complete; ++i)
        for (size_t j = 1; j < bv.size() && result.complete; ++j) {
            if (separated(ab[i - 1], bb[j - 1], tolerance))
                continue;
            const Pair pair{interval(first, av[i - 1], av[i]), interval(second, bv[j - 1], bv[j])};
            result.complete = budget++ < work_limit && process(pair, tolerance, budget, result);
        }

    if (!result.complete && result.failure.empty())
        result.failure = "Curve intersection exceeded its subdivision or floating-point resolution limit";

    map_result(a, b, result);
    return result;
}

Result intersect(const NurbsCurve& a,const std::pair<double,double>& ar,
                 const NurbsCurve& b,const std::pair<double,double>& br,double tolerance) {
    if (!std::isfinite(tolerance) || !(tolerance>0) || !brep_curve_use::valid_domain(a,ar) ||
        !brep_curve_use::valid_domain(b,br) || a.dimension()<1 || a.dimension()>3 || b.dimension()<1 || b.dimension()>3)
        throw std::invalid_argument("Original-range intersection requires valid contained positive raw ranges");
    return original_range_queue(a,ar,b,br,tolerance);
}
Result intersect(const brep_curve_use::CurveUse& a,const brep_curve_use::CurveUse& b,double tolerance) {
    return intersect(a.original_curve(),a.domain(),b.original_curve(),b.domain(),tolerance);
}

}
