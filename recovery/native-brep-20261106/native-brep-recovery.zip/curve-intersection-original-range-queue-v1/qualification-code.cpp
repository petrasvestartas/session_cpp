
namespace session_cpp {
MINI_TEST("Curve Intersection", "Original Range Queue Retains Actual Sub ULP World Prefix") {
    NurbsCurve source(3,false,2,2);source.m_nurbsknot={0,1};
    MINI_CHECK(source.set_cv(0,{.21999999999999997,-1,-1.044}));
    MINI_CHECK(source.set_cv(1,{.21999999999999997,-1,.956}));
    const double last=2.949029909160572e-17;const auto frozen=source.jsondump();
    const brep_curve_use::CurveUse first(source,{0,last}),second(source,{0,last});
    const auto result=curve_intersection::intersect(first,second,1e-7);
    MINI_CHECK(result.complete && result.points.empty() && result.overlaps.size()==1);
    const auto& range=result.overlaps[0];
    MINI_CHECK(range.a0==0 && range.a1==last && range.b0==0 && range.b1==last);
    MINI_CHECK(source.jsondump()==frozen && source.get_cv(0)[2]!=source.get_cv(1)[2]);
}
MINI_TEST("Curve Intersection", "Original Curved Range Correspondence Keeps Both Orientations") {
    const double q=std::sqrt(.5);
    NurbsCurve first(3,true,3,3);first.m_nurbsknot={-7,-7,13,13};
    MINI_CHECK(first.set_cv_4d(0,1,0,0,1));MINI_CHECK(first.set_cv_4d(1,q,q,0,q));
    MINI_CHECK(first.set_cv_4d(2,0,1,0,1));
    for (bool reverse:{false,true}) {
        NurbsCurve second(3,true,3,3);second.m_nurbsknot={32,32,35,35};
        MINI_CHECK(second.set_cv_4d(0,reverse?0:1,reverse?1:0,0,1));
        MINI_CHECK(second.set_cv_4d(1,q,q,0,q));
        MINI_CHECK(second.set_cv_4d(2,reverse?1:0,reverse?0:1,0,1));
        const auto frozen_a=first.jsondump(),frozen_b=second.jsondump();
        const std::pair<double,double> range_b=reverse?std::pair{33.5,35.}:std::pair{32.,33.5};
        const auto result=curve_intersection::intersect(first,{-7,3},second,range_b,1e-7);
        MINI_CHECK(result.complete && result.overlaps.size()==1 && result.points.empty());
        const auto& common=result.overlaps[0];
        MINI_CHECK(common.a0==-7 && common.a1==3);
        MINI_CHECK(common.b0==(reverse?35.:32.) && common.b1==33.5);
        const Point endpoint=first.point_at(3);
        MINI_CHECK(std::abs(endpoint[0]-q)<1e-14 && std::abs(endpoint[1]-q)<1e-14);
        MINI_CHECK(first.jsondump()==frozen_a && second.jsondump()==frozen_b);
    }
}
MINI_TEST("Curve Intersection", "Original Range Query Excludes Crossings On Unused Pool Continuations") {
    const auto first=NurbsCurve::create(false,1,{Point(0,0,0),Point(10,0,0)});
    const auto second=NurbsCurve::create(false,1,{Point(5,-1,0),Point(5,1,0)});
    const auto frozen_a=first.jsondump(),frozen_b=second.jsondump();
    const auto result=curve_intersection::intersect(first,{0,.1},second,second.domain(),1e-8);
    MINI_CHECK(result.complete && result.points.empty() && result.overlaps.empty());
    MINI_CHECK(first.point_at(.5)[0]==5 && first.jsondump()==frozen_a && second.jsondump()==frozen_b);
}
MINI_TEST("Curve Intersection", "Original Tiny Raw Crossing Keeps Physical Scale And Exact Raw Parameters") {
    NurbsCurve first(3,false,2,2);first.m_nurbsknot={0,1};
    MINI_CHECK(first.set_cv(0,{0,0,0}) && first.set_cv(1,{std::ldexp(1.,60),0,0}));
    NurbsCurve second(3,false,2,2);second.m_nurbsknot={-7,13};
    MINI_CHECK(second.set_cv(0,{.5,-1,0}) && second.set_cv(1,{.5,1,0}));
    const auto result=curve_intersection::intersect(first,{0,std::ldexp(1.,-60)},second,second.domain(),1e-8);
    MINI_CHECK(result.complete && result.points.size()==1 && result.overlaps.empty());
    MINI_CHECK(result.points[0].a==std::ldexp(1.,-61) && result.points[0].b==3);
    MINI_CHECK(result.points[0].point[0]==.5 && result.points[0].point[1]==0 && result.points[0].point[2]==0);
}
MINI_TEST("Curve Intersection", "Unrepresentable Original Root Remains Explicitly Unresolved") {
    NurbsCurve first(3,false,2,2);first.m_nurbsknot={3,std::nextafter(3.,4.)};
    MINI_CHECK(first.set_cv(0,{0,0,0}) && first.set_cv(1,{1,0,0}));
    NurbsCurve second(3,false,2,2);second.m_nurbsknot={7,std::nextafter(7.,8.)};
    MINI_CHECK(second.set_cv(0,{.5,-.5,0}) && second.set_cv(1,{.5,.5,0}));
    const auto result=curve_intersection::intersect(first,first.domain(),second,second.domain(),1e-8);
    MINI_CHECK(!result.complete && !result.failure.empty() && result.points.empty() && result.overlaps.empty());
}
} // namespace session_cpp
