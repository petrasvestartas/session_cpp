// Positive B-spline basis is independent on each open knot span. A rational image
// is constant there iff all active homogeneous poles are proportional.
bool original_nonconstant_span(const NurbsCurve& curve,const std::pair<double,double>& range) {
    auto knots=curve.m_nurbsknot;knots.insert(knots.begin(),knots.front());knots.push_back(knots.back());
    const int degree=curve.degree();
    const int span=std::clamp(static_cast<int>(std::upper_bound(knots.begin(),knots.end(),range.first)-knots.begin())-1,
        degree,curve.cv_count()-1);
    if (range.first<knots[span] || range.second>knots[span+1]) return false;
    const int first=span-degree;const double weight=curve.weight(first);
    for (int i=first+1;i<=span;++i) for (int d=0;d<curve.dimension();++d)
        if (!nurbs_coincidence::exact_products_equal(curve.cv(first)[d],curve.weight(i),curve.cv(i)[d],weight)) return true;
    return false;
}
bool original_queue_basis(const NurbsCurve& curve) {
    const int p=curve.degree(),count=curve.cv_count();const auto& knots=curve.m_nurbsknot;
    if (p<1 || count<=p || knots.size()!=static_cast<size_t>(count+p-1)) return false;
    const auto range=curve.domain();
    for (int i=0;i<p;++i) if (knots[i]!=range.first || knots[knots.size()-1-i]!=range.second) return false;
    for (size_t i=0;i<knots.size();) {
        size_t j=i+1;while (j<knots.size() && knots[j]==knots[i]) ++j;
        if (!std::isfinite(knots[i]) || (i && knots[i]<knots[i-1]) ||
            (knots[i]>range.first && knots[i]<range.second && j-i>static_cast<size_t>(p))) return false;
        i=j;
    }
    return true;
}
struct OriginalPair {
    const NurbsCurve* a;
    const NurbsCurve* b;
    std::pair<double,double> ar,br;
    int depth=0;
};
bool original_range_box(const NurbsCurve& curve,const std::pair<double,double>& range,nurbs_interval::CurveBounds& box) {
    return nurbs_interval::curve_bounds(curve,{range.first,range.second},{0,0,0},box);
}
bool original_boxes_separated(const nurbs_interval::CurveBounds& a,const nurbs_interval::CurveBounds& b,double tolerance) {
    for (int d=0;d<3;++d) {
        const auto gap=a.point[d]-b.point[d];
        if (nurbs_interval::finite(gap) && (gap.lo>tolerance || gap.hi < -tolerance)) return true;
    }
    return false;
}
// Exact arithmetic is a sufficient line-point proposal, followed by ORIGINAL singleton proof.
bool original_line_hit(const OriginalPair& pair,double tolerance,Hit& hit) {
    const auto difference=[](double a,double b,double& value) {
        return nurbs_coincidence::exact_difference(a,b,value) && std::isfinite(value);
    };
    const auto product=[](double a,double b,double& value) {
        value=a*b;return std::isfinite(value) && nurbs_coincidence::exact_products_equal(a,b,value,1.);
    };
    const auto det=[&](double a,double b,double c,double d,double& value) {
        double first,last;return product(a,b,first) && product(c,d,last) && difference(first,last,value);
    };
    const auto line=[&](const NurbsCurve& curve,std::array<double,3>& start,std::array<double,3>& direction) {
        if (curve.degree()!=1 || curve.cv_count()!=2 || curve.weight(0)!=curve.weight(1)) return false;
        const double weight=curve.weight(0);
        for (int d=0;d<3;++d) {
            const double h0=d<curve.dimension()?curve.cv(0)[d]:0,h1=d<curve.dimension()?curve.cv(1)[d]:0;
            const double first=h0/weight,last=h1/weight;
            if (!std::isfinite(first) || !std::isfinite(last) ||
                !nurbs_coincidence::exact_products_equal(first,weight,h0,1.) ||
                !nurbs_coincidence::exact_products_equal(last,weight,h1,1.) || !difference(last,first,direction[d])) return false;
            start[d]=first;
        }
        return true;
    };
    std::array<double,3> a,b,u,v,rhs;
    if (!line(*pair.a,a,u) || !line(*pair.b,b,v)) return false;
    for (int d=0;d<3;++d) if (!difference(b[d],a[d],rhs[d])) return false;
    double denominator=0,na=0,nb=0;bool independent=false;
    for (int i=0;i<3 && !independent;++i) for (int j=i+1;j<3 && !independent;++j) {
        if (!det(u[i],v[j],u[j],v[i],denominator)) return false;
        if (denominator==0) continue;
        if (!det(rhs[i],v[j],rhs[j],v[i],na) || !det(rhs[i],u[j],rhs[j],u[i],nb)) return false;
        independent=true;
    }
    if (!independent) return false;
    const double sa=na/denominator,sb=nb/denominator;
    if (!std::isfinite(sa) || !std::isfinite(sb) ||
        !nurbs_coincidence::exact_products_equal(sa,denominator,na,1.) ||
        !nurbs_coincidence::exact_products_equal(sb,denominator,nb,1.)) return false;
    const auto raw=[&](const NurbsCurve& curve,double fraction,double& t) {
        double width,offset;
        return difference(curve.domain_end(),curve.domain_start(),width) && product(fraction,width,offset) &&
            difference(curve.domain_start(),-offset,t);
    };
    double ta,tb;
    if (!raw(*pair.a,sa,ta) || !raw(*pair.b,sb,tb) || ta<pair.ar.first || ta>pair.ar.second ||
        tb<pair.br.first || tb>pair.br.second) return false;
    Point point;
    for (int d=0;d<3;++d) {
        double da,db,pa,pb;
        if (!product(sa,u[d],da) || !product(sb,v[d],db) || !difference(a[d],-da,pa) ||
            !difference(b[d],-db,pb) || pa!=pb) return false;
        point[d]=pa;
    }
    if (!nurbs_interval::curve_within_ball(*pair.a,{ta,ta},{point[0],point[1],point[2]},tolerance*.25) ||
        !nurbs_interval::curve_within_ball(*pair.b,{tb,tb},{point[0],point[1],point[2]},tolerance*.25)) return false;
    hit={point,ta,tb,false};return true; // Two nonparallel injective original lines have at most this one root.
}
std::vector<double> original_range_knots(const NurbsCurve& curve,const std::pair<double,double>& range) {
    std::vector<double> result{range.first,range.second};
    for (double knot:curve.get_span_vector()) if (knot>range.first && knot<range.second) result.push_back(knot);
    std::sort(result.begin(),result.end());result.erase(std::unique(result.begin(),result.end()),result.end());return result;
}
Result original_range_queue(const NurbsCurve& a,const std::pair<double,double>& ar,
                           const NurbsCurve& b,const std::pair<double,double>& br,double tolerance) {
    Result result;
    const auto fail=[&](const char* reason) { result.complete=false;result.failure=reason; };
    if (!finite_positive(a) || !finite_positive(b)) {
        fail("Original-range curve intersection requires finite positive weights");return result;
    }
    if (!original_queue_basis(a) || !original_queue_basis(b)) {
        fail("Original-range worker requires an exact clamped continuous positive basis");return result;
    }
    const auto av=original_range_knots(a,ar),bv=original_range_knots(b,br);
    std::vector<nurbs_interval::CurveBounds> ab(av.size()-1),bb(bv.size()-1);
    for (size_t i=1;i<av.size();++i) if (!original_range_box(a,{av[i-1],av[i]},ab[i-1])) {
        fail("Original first-curve range has no finite interval enclosure");return result;
    }
    for (size_t i=1;i<bv.size();++i) if (!original_range_box(b,{bv[i-1],bv[i]},bb[i-1])) {
        fail("Original second-curve range has no finite interval enclosure");return result;
    }
    std::vector<OriginalPair> work;size_t budget=0;
    for (size_t i=1;i<av.size();++i) for (size_t j=1;j<bv.size();++j) {
        if (++budget>work_limit) { fail("Original-range pair partition exceeded the existing work budget");return result; }
        if (!original_boxes_separated(ab[i-1],bb[j-1],tolerance))
            work.push_back({&a,&b,{av[i-1],av[i]},{bv[j-1],bv[j]}});
    }
    while (!work.empty()) {
        if (++budget>work_limit) { fail("Original-range subdivision exceeded the existing work budget");break; }
        const auto pair=work.back();work.pop_back();
        nurbs_interval::CurveBounds first,second;
        if (!original_range_box(a,pair.ar,first) || !original_range_box(b,pair.br,second)) {
            fail("Original-range subdivision has no finite original enclosure");break;
        }
        if (original_boxes_separated(first,second,tolerance)) continue;
        bool common=false;
        // A whole original knot-pair correspondence covers both loci. Do not turn a
        // merely small subdivided curved root box into a new common interval.
        if (pair.depth==0 && original_nonconstant_span(a,pair.ar) && original_nonconstant_span(b,pair.br))
            for (bool reverse:{false,true})
            if (certified_original_parameter_range(a,pair.ar,b,pair.br,tolerance,reverse)) {
                result.overlaps.push_back({pair.ar.first,pair.ar.second,
                    reverse?pair.br.second:pair.br.first,reverse?pair.br.first:pair.br.second});common=true;break;
            }
        if (common) continue;
        Hit hit;
        if (original_line_hit(pair,tolerance,hit)) { result.points.push_back(hit);continue; }
        if (pair.depth>=96) { fail("Original-range isolated root coverage remains unresolved");break; }
        const auto size=[](const auto& box) {
            double value=0;for (const auto& coordinate:box.point) value=std::max(value,coordinate.hi-coordinate.lo);return value;
        };
        bool split_first=size(first)>=size(second);
        const auto middle=[](const auto& range) { return std::midpoint(range.first,range.second); };
        double mid=middle(split_first?pair.ar:pair.br);
        const auto interior=[](const auto& range,double t) { return t>range.first && t<range.second; };
        if (!interior(split_first?pair.ar:pair.br,mid)) {
            split_first=!split_first;mid=middle(split_first?pair.ar:pair.br);
        }
        if (!interior(split_first?pair.ar:pair.br,mid)) {
            fail("Original-range root has no representable subdivision; coverage unresolved");break;
        }
        auto left=pair,right=pair;left.depth=right.depth=pair.depth+1;
        if (split_first) { left.ar.second=mid;right.ar.first=mid; }
        else { left.br.second=mid;right.br.first=mid; }
        work.push_back(right);work.push_back(left);
    }
    std::sort(result.points.begin(),result.points.end(),hit_less);
    result.points.erase(std::unique(result.points.begin(),result.points.end(),[](const auto& x,const auto& y) {
        return x.a==y.a && x.b==y.b;
    }),result.points.end());
    std::sort(result.overlaps.begin(),result.overlaps.end(),overlap_less);
    result.overlaps.erase(std::unique(result.overlaps.begin(),result.overlaps.end(),[](const auto& x,const auto& y) {
        return x.a0==y.a0 && x.a1==y.a1 && x.b0==y.b0 && x.b1==y.b1;
    }),result.overlaps.end());
    return result; // Literal ORIGINAL raw values: no map_result, epsilon merging or receipt suppression.
}

