#pragma once

#include "nurbscurve.h"
#include <string>
#include <vector>
#include <utility>

namespace session_cpp::brep_curve_use { class CurveUse; }

namespace session_cpp::curve_intersection {

struct Hit {
    Point point;
    double a;
    double b;
    bool tangent;
};

struct Overlap {
    double a0;
    double a1;
    double b0;
    double b1;
};

struct Result {
    std::vector<Hit> points;
    std::vector<Overlap> overlaps;
    bool complete = true;
    std::string failure;
};

/// Intersect bounded positive rational curves, retaining both parameters and oriented overlap intervals.
Result intersect(const NurbsCurve& a, const NurbsCurve& b, double tolerance = 1e-7);

/// Query literal ORIGINAL raw subranges without narrowing poles or relabeling source domains.
/// Unsupported curved isolated-root coverage returns complete=false, never a claimed empty result.
Result intersect(const NurbsCurve& a,const std::pair<double,double>& range_a,
                 const NurbsCurve& b,const std::pair<double,double>& range_b,double tolerance=1e-7);
Result intersect(const brep_curve_use::CurveUse& a,const brep_curve_use::CurveUse& b,double tolerance=1e-7);

}
