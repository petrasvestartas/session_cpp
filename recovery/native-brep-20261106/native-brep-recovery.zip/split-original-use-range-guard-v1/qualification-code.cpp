
namespace session_cpp {
MINI_TEST("Split", "Restricted Original Uses Refuse Legacy Split Entry Points") {
    auto owner=BRep::create_box(2,2,2);auto& edge=owner.m_edges[0];
    const auto wd=owner.m_curves_3d[edge.curve_3d_index].domain();
    edge.world_range=BRepCurveUseRange{std::lerp(wd.first,wd.second,.25),std::lerp(wd.first,wd.second,.75)};
    for (auto& image:edge.pcurves) {
        const auto pd=owner.m_curves_2d[image.curve_2d_index].domain();
        image.primary_range=BRepCurveUseRange{std::lerp(pd.first,pd.second,.25),std::lerp(pd.first,pd.second,.75)};
        if (image.curve_2d_index_2>=0) {
            const auto sd=owner.m_curves_2d[image.curve_2d_index_2].domain();
            image.secondary_range=BRepCurveUseRange{std::lerp(sd.first,sd.second,.25),std::lerp(sd.first,sd.second,.75)};
        }
    }
    MINI_CHECK(owner.is_valid() && owner.has_restricted_curve_uses());const auto frozen=owner.jsondump();
    for (int entry=0;entry<3;++entry) {
        bool rejected=false;
        try {
            if (entry==0) split::split_brep_edges_at_events(owner,{},1e-7);
            if (entry==1) split::split_brep_face_by_curves(owner,0,{},1e-7);
            if (entry==2) split::split_brep_face_by_pcurves(owner,0,{},1e-7,nullptr);
        } catch(const std::invalid_argument& error) {
            rejected=std::string(error.what())=="Split original curve use ranges require the range-aware producer";
        }
        MINI_CHECK(rejected && owner.jsondump()==frozen);
    }
}
} // namespace session_cpp
