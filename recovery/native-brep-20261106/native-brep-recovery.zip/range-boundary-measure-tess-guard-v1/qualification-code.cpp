
namespace {
BRep pooled_range_box(bool quadratic_pcurves) {
    BRep shape=BRep::create_box(2,3,4);
    const auto extend=[](NurbsCurve& curve) {
        MINI_CHECK(curve.degree()==1 && curve.cv_count()==2);
        const auto a=curve.get_cv(0),b=curve.get_cv(1);
        MINI_CHECK(curve.set_cv(0,a-(b-a)*.5));
        MINI_CHECK(curve.set_cv(1,b+(b-a)*.5));
    };
    for (auto& curve:shape.m_curves_3d) extend(curve);
    for (auto& curve:shape.m_curves_2d) extend(curve);
    for (auto& edge:shape.m_edges) {
        const auto full=shape.m_curves_3d[edge.curve_3d_index].domain();
        edge.world_range=BRepCurveUseRange{std::lerp(full.first,full.second,.25),std::lerp(full.first,full.second,.75)};
        for (auto& pc:edge.pcurves) for (int side=0;side<2;++side) {
            const int index=side?pc.curve_2d_index_2:pc.curve_2d_index;
            if (index<0) continue;
            const auto raw=shape.m_curves_2d[index].domain();
            (side?pc.secondary_range:pc.primary_range)=BRepCurveUseRange{
                std::lerp(raw.first,raw.second,.25),std::lerp(raw.first,raw.second,.75)};
        }
    }
    if (quadratic_pcurves)
        for (auto& pc:shape.m_curves_2d) MINI_CHECK(pc.increase_degree(2));
    MINI_CHECK(shape.is_valid() && shape.is_solid() && shape.has_restricted_curve_uses());
    return shape;
}
BRep explicit_range_box(const BRep& ranged) {
    BRep shape=ranged;
    std::set<int> world_done,pc_done;
    for (auto& edge:shape.m_edges) {
        if (world_done.insert(edge.curve_3d_index).second)
            MINI_CHECK(shape.m_curves_3d[edge.curve_3d_index].trim(edge.world_range->first,edge.world_range->last));
        edge.world_range.reset();
        for (auto& pc:edge.pcurves) for (int side=0;side<2;++side) {
            const int index=side?pc.curve_2d_index_2:pc.curve_2d_index;
            if (index<0) continue;
            auto& range=side?pc.secondary_range:pc.primary_range;
            if (pc_done.insert(index).second) MINI_CHECK(shape.m_curves_2d[index].trim(range->first,range->last));
            range.reset();
        }
    }
    MINI_CHECK(shape.is_valid() && shape.is_solid() && !shape.has_restricted_curve_uses());
    return shape;
}
}
MINI_TEST("BRep Native Measure", "Original Curve Use Ranges Match Explicit Box Trims And Signed Volume") {
    for (bool quadratic:{false,true}) for (bool reverse:{false,true}) {
        auto ranged=pooled_range_box(quadratic);
        auto explicit_shape=explicit_range_box(ranged);
        if (reverse) {
            ranged.m_solids[0].shells[0].orientation=BRepOrientation::Reversed;
            explicit_shape.m_solids[0].shells[0].orientation=BRepOrientation::Reversed;
        }
        const auto frozen=ranged.jsondump(),explicit_frozen=explicit_shape.jsondump();
        const double expected=reverse?-24.:24.;
        const double a=ranged.volume_exact(1e-8),b=explicit_shape.volume_exact(1e-8);
        MINI_CHECK(std::abs(a-expected)<=24e-8 && std::abs(b-expected)<=24e-8);
        MINI_CHECK(std::abs(a-b)<=24e-8);
        MINI_CHECK(ranged.m_curves_3d.size()==12 && ranged.m_edges.size()==12);
        MINI_CHECK(ranged.jsondump()==frozen && explicit_shape.jsondump()==explicit_frozen);
    }
}
MINI_TEST("BRep Native Measure", "Extracted Boundary Uses Keep Original Active Ranges And Primary Fallback") {
    const auto owner=pooled_range_box(false);const auto frozen=owner.jsondump();
    for (int face=0;face<owner.face_count();++face) {
        const auto boundary=brep_face_boundary::extract(owner,face);
        MINI_CHECK(boundary.complete);
        for (const auto& wire:boundary.wires) for (const auto& use:wire.uses) {
            MINI_CHECK(use.world_domain==owner.edge_domain(use.edge.index));
            MINI_CHECK(use.pcurve_domain==owner.pcurve_domain(use.edge.index,face,use.edge.orientation));
            MINI_CHECK(use.world_domain!=owner.m_curves_3d[owner.m_edges[use.edge.index].curve_3d_index].domain());
            brep_face_boundary::Use reverse;std::string reason;
            MINI_CHECK(brep_face_boundary::detail::extract_use(owner,face,
                {use.edge.index,BRepOrientation::Reversed},reverse,reason));
            MINI_CHECK(reverse.pcurve==owner.pcurve_index(use.edge.index,face,BRepOrientation::Reversed));
            MINI_CHECK(reverse.pcurve_domain==owner.pcurve_domain(use.edge.index,face,BRepOrientation::Reversed));
        }
    }
    MINI_CHECK(owner.jsondump()==frozen);
}
MINI_TEST("BRep Native Measure", "Restricted Curve Uses Reject Tessellation Before Full Pool Fallback") {
    const auto owner=pooled_range_box(false);const auto frozen=owner.jsondump();
    for (int entry=0;entry<3;++entry) {
        bool rejected=false;
        try {
            if (entry==0) owner.mesh();
            else if (entry==1) owner.face_meshes();
            else owner.tessellate(.01,.2);
        } catch (const std::runtime_error& error) {
            rejected=std::string(error.what()).find("restricted original curve uses")!=std::string::npos;
        }
        MINI_CHECK(rejected);
    }
    MINI_CHECK(owner.jsondump()==frozen);
}
