#pragma once
#include "curve_surface_intersection.h"
#include "nurbs_interval.h"
#include <numeric>

namespace session_cpp::curve_surface_intersection::range_detail {
using I=nurbs_interval::Interval;
using H=nurbs_interval::Homogeneous;
using Polynomial=std::vector<I>;

inline I mapped(const std::pair<double,double>& range,double t) {
    if (t==0) return I(range.first);
    if (t==1) return I(range.second);
    return I(range.first)+I(t)*(I(range.second)-I(range.first));
}
inline bool valid(const NurbsCurve& curve,const std::pair<double,double>& range) {
    return curve.is_valid() && std::isfinite(range.first) && std::isfinite(range.second) &&
        range.first<range.second && range.first>=curve.domain_start() && range.second<=curve.domain_end();
}
inline std::vector<H> controls(const NurbsCurve& curve,I lo,I hi,const std::array<double,3>& origin) {
    if (!nurbs_interval::finite(lo) || !nurbs_interval::finite(hi) || lo.lo>hi.hi ||
        lo.lo<curve.domain_start() || hi.hi>curve.domain_end()) return {};
    auto knots=curve.m_nurbsknot;
    knots.insert(knots.begin(),knots.front());knots.push_back(knots.back());
    const int p=curve.degree();
    const int span=std::clamp(static_cast<int>(std::upper_bound(knots.begin(),knots.end(),lo.lo)-knots.begin())-1,
        p,curve.cv_count()-1);
    if (lo.lo<knots[span] || hi.hi>knots[span+1]) return {};
    std::vector<H> initial(p+1),result(p+1);
    for (int i=0;i<=p;++i) {
        const double* cv=curve.cv(span-p+i);
        const double w=curve.is_rational()?cv[curve.dimension()]:1;
        if (!(w>0) || !std::isfinite(w)) return {};
        initial[i][3]=I(w);
        for (int d=0;d<3;++d)
            initial[i][d]=I(d<curve.dimension()?cv[d]:0)-I(origin[d])*I(w);
    }
    for (int pole=0;pole<=p;++pole) {
        auto work=initial;
        for (int level=1;level<=p;++level) {
            const I t=level>p-pole?hi:lo;
            for (int j=p;j>=level;--j) {
                const int k=span-p+j;
                const I width=I(knots[k+p-level+1])-I(knots[k]);
                if (!(width.lo>0)) return {};
                const I alpha=t.lo==t.hi && t.lo==knots[k]?I(0):
                    t.lo==t.hi && t.lo==knots[k+p-level+1]?I(1):(t-I(knots[k]))/width;
                for (int d=0;d<4;++d)
                    if (!(work[j-1][d].lo==work[j-1][d].hi && work[j][d].lo==work[j][d].hi &&
                          work[j-1][d].lo==work[j][d].lo))
                        work[j][d]=(I(1)-alpha)*work[j-1][d]+alpha*work[j][d];
            }
        }
        result[pole]=work[p];
    }
    return result;
}
inline I choose(int n,int k) {
    I result(1);
    for (int i=1;i<=k;++i) result=result*I(n-k+i)/I(i);
    return result;
}
inline Polynomial product(const Polynomial& a,const Polynomial& b) {
    const int m=static_cast<int>(a.size())-1,n=static_cast<int>(b.size())-1;
    if (m<0 || n<0 || m+n>64) return {};
    Polynomial result(m+n+1);
    for (int i=0;i<=m;++i)
        for (int j=0;j<=n;++j)
            result[i+j]=result[i+j]+a[i]*b[j]*(choose(m,i)*choose(n,j)/choose(m+n,i+j));
    return result;
}
inline Polynomial power(const Polynomial& value,int exponent) {
    Polynomial result{I(1)};
    for (int i=0;i<exponent;++i) { result=product(result,value);if (result.empty()) break; }
    return result;
}
inline std::array<Polynomial,4> compose(const std::vector<H>& pc,const NurbsSurface& surface,
                                      const std::array<double,3>& origin) {
    std::array<Polynomial,4> result;
    std::array<std::pair<double,double>,2> span;
    for (int d=0;d<2;++d) {
        I hull;bool first=true;
        for (const auto& h:pc) {
            if (!(h[3].lo>0)) return {};
            const I value=h[d]/h[3];
            if (!nurbs_interval::finite(value)) return {};
            hull=first?value:nurbs_interval::interval_hull(hull,value);first=false;
        }
        const auto knots=surface.get_span_vector(d);bool found=false;
        for (size_t i=1;i<knots.size();++i)
            if (knots[i-1]<knots[i] && hull.lo>=knots[i-1] && hull.hi<=knots[i]) {
                span[d]={knots[i-1],knots[i]};found=true;break;
            }
        if (!found) return {};
    }
    const auto patch=nurbs_interval::surface_controls(surface,
        {span[0].first,span[0].second,span[1].first,span[1].second},origin);
    const int p=surface.degree(0),q=surface.degree(1),n=static_cast<int>(pc.size())-1;
    if (p<1 || q<1 || n*(p+q)>64 || patch.size()!=static_cast<size_t>((p+1)*(q+1))) return {};
    std::array<Polynomial,2> a,b;
    for (int d=0;d<2;++d) {
        const I width=I(span[d].second)-I(span[d].first);
        if (!(width.lo>0)) return {};
        for (const auto& h:pc) {
            a[d].push_back((h[d]-I(span[d].first)*h[3])/width);
            b[d].push_back((I(span[d].second)*h[3]-h[d])/width);
        }
    }
    for (int i=0;i<=p;++i)
        for (int j=0;j<=q;++j) {
            const auto u=product(power(a[0],i),power(b[0],p-i));
            const auto v=product(power(a[1],j),power(b[1],q-j));
            const auto basis=product(u,v);
            if (basis.empty()) return {};
            const I factor=choose(p,i)*choose(q,j);
            for (int d=0;d<4;++d) {
                if (result[d].empty()) result[d].resize(basis.size());
                for (size_t k=0;k<basis.size();++k)
                    result[d][k]=result[d][k]+basis[k]*factor*patch[i*(q+1)+j][d];
            }
        }
    return result;
}
inline ParameterMatch bound(const std::vector<H>& world,const std::vector<H>& pc,
                            const NurbsSurface& surface,const std::array<double,3>& origin,double tolerance) {
    if (world.empty() || pc.empty()) return ParameterMatch::Unresolved;
    const auto lifted=compose(pc,surface,origin);
    if (lifted[3].empty()) return ParameterMatch::Unresolved;
    Polynomial weight;
    double minimum=std::numeric_limits<double>::infinity(),surface_minimum=minimum;
    for (const auto& h:world) { weight.push_back(h[3]);minimum=std::min(minimum,h[3].lo); }
    for (I value:lifted[3]) surface_minimum=std::min(surface_minimum,value.lo);
    if (!(minimum>0 && surface_minimum>0)) return ParameterMatch::Unresolved;
    I squared;
    for (int d=0;d<3;++d) {
        Polynomial coordinate;
        for (const auto& h:world) coordinate.push_back(h[d]);
        const auto a=product(coordinate,lifted[3]),b=product(weight,lifted[d]);
        if (a.empty() || a.size()!=b.size()) return ParameterMatch::Unresolved;
        double maximum=0;
        for (size_t i=0;i<a.size();++i) {
            const I residual=a[i]-b[i];
            if (!nurbs_interval::finite(residual)) return ParameterMatch::Unresolved;
            maximum=std::max(maximum,nurbs_interval::magnitude(residual));
        }
        squared=squared+I(maximum)*I(maximum);
    }
    const I denominator=I(minimum)*I(surface_minimum);
    const I allowed=I(tolerance)*I(tolerance)*denominator*denominator;
    return nurbs_interval::finite(squared) && nurbs_interval::finite(allowed) && squared.hi<=allowed.lo
        ?ParameterMatch::Matched:ParameterMatch::Unresolved;
}
inline bool point_mismatch(const std::vector<H>& world,const std::vector<H>& pc,
                           const NurbsSurface& surface,const std::array<double,3>& origin,double tolerance) {
    if (world.empty() || pc.empty()) return false;
    const auto lifted=compose(pc,surface,origin);
    if (lifted[3].empty()) return false;
    I squared;
    for (int d=0;d<3;++d) {
        I a,b;bool first=true;
        for (const auto& h:world) {
            if (!(h[3].lo>0)) return false;
            const I value=h[d]/h[3];
            a=first?value:nurbs_interval::interval_hull(a,value);first=false;
        }
        first=true;
        for (size_t i=0;i<lifted[3].size();++i) {
            if (!(lifted[3][i].lo>0)) return false;
            const I value=lifted[d][i]/lifted[3][i];
            b=first?value:nurbs_interval::interval_hull(b,value);first=false;
        }
        const I gap=a-b;
        if (!nurbs_interval::finite(gap)) return false;
        const double distance=gap.lo>0?gap.lo:gap.hi<0?-gap.hi:0;
        squared=squared+I(distance)*I(distance);
    }
    const I allowed=I(tolerance)*I(tolerance);
    return nurbs_interval::finite(squared) && nurbs_interval::finite(allowed) && squared.lo>allowed.hi;
}
} // namespace session_cpp::curve_surface_intersection::range_detail
