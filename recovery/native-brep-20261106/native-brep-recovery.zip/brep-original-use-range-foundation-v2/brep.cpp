#include "brep.h"
#include "brep_curve_use.h"
#include <google/protobuf/unknown_field_set.h>
#include "mesh_parametric_metadata.h"
#include "brep.pb.h"
#include "brep_boolean.h"
#include "brep_measure.h"
#include "brep_offset.h"
#include "closest.h"
#include "fmt/core.h"
#include "nurbssurface_trimmed.h"
#include "primitives.h"
#include "remesh_cdt.h"
#include "remesh_nurbssurface_grid.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <limits>
#include <map>
#include <numeric>
#include <optional>
#include <stdexcept>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

namespace session_cpp {

// ═══════════════════════════════════════════════════════════════════════════
// Orientation
// ═══════════════════════════════════════════════════════════════════════════
BRepOrientation brep_reverse(BRepOrientation o) {

    if (o == BRepOrientation::Forward)
        return BRepOrientation::Reversed;

    if (o == BRepOrientation::Reversed)
        return BRepOrientation::Forward;

    return o;
}

BRepOrientation brep_compose(BRepOrientation a, BRepOrientation b) {

    if (a == BRepOrientation::Internal || a == BRepOrientation::External)
        return a;

    if (a == BRepOrientation::Forward)
        return b;

    return brep_reverse(b);
}

namespace {

const BRepOrientation F = BRepOrientation::Forward;
const BRepOrientation R = BRepOrientation::Reversed;

/// JSON name of an orientation
std::string orientation_to_str(BRepOrientation o) {

    if (o == BRepOrientation::Reversed)
        return "reversed";

    if (o == BRepOrientation::Internal)
        return "internal";

    if (o == BRepOrientation::External)
        return "external";

    return "forward";
}

/// Orientation of a JSON name, Forward when unknown
BRepOrientation orientation_from_str(const std::string& s) {

    if (s == "reversed")
        return BRepOrientation::Reversed;

    if (s == "internal")
        return BRepOrientation::Internal;

    if (s == "external")
        return BRepOrientation::External;

    return BRepOrientation::Forward;
}

/// True when `index` addresses one of `count` table entries
bool in_range(int index, size_t count) {

    return index >= 0 && index < (int)count;
}

// ═══════════════════════════════════════════════════════════════════════════
// Geometry helpers
// ═══════════════════════════════════════════════════════════════════════════
/// Bilinear planar patch: u runs p00 -> p10, v runs p00 -> p01, natural normal = u x v
NurbsSurface bilinear_patch(const Point& p00, const Point& p10, const Point& p01, const Point& p11) {

    NurbsSurface srf(3, false, 2, 2, 2, 2);

    if (!srf.set_cv(0, 0, p00) || !srf.set_cv(1, 0, p10) || !srf.set_cv(0, 1, p01) || !srf.set_cv(1, 1, p11))
        return NurbsSurface();

    return srf;
}

/// Straight pcurve from (u0, v0) to (u1, v1)
NurbsCurve uv_line(double u0, double v0, double u1, double v1) {

    return NurbsCurve::create(false, 1, {
        Point(u0, v0, 0),
        Point(u1, v1, 0)
    });
}

/// Exact pcurve of a 3D curve lying on a bilinear planar patch: the affine image of its CVs
NurbsCurve project_to_patch(const NurbsCurve& crv, const NurbsSurface& srf) {

    const Point p00 = srf.get_cv(0, 0);
    const Vector eu = srf.get_cv(1, 0) - p00;
    const Vector ev = srf.get_cv(0, 1) - p00;
    const double eu2 = eu.dot(eu);
    const double ev2 = ev.dot(ev);
    NurbsCurve c2(3, crv.is_rational(), crv.order(), crv.cv_count());

    for (int i = 0; i < crv.nurbsknot_count(); ++i)
        if (!c2.set_nurbsknot(i, crv.nurbsknot(i)))
            return NurbsCurve();

    for (int i = 0; i < crv.cv_count(); ++i) {
        double wx = 0.0;
        double wy = 0.0;
        double wz = 0.0;
        double w = 0.0;
        std::tie(wx, wy, wz, w) = crv.get_cv_4d(i);
        const Vector d = Point(wx / w, wy / w, wz / w) - p00;
        const double u = d.dot(eu) / eu2;
        const double v = d.dot(ev) / ev2;

        const bool written = crv.is_rational() ? c2.set_cv_4d(i, u * w, v * w, 0.0, w) : c2.set_cv(i, Point(u, v, 0));

        if (!written)
            return NurbsCurve();
    }

    return c2;
}

/// Signed area of a closed pcurve's sampled polygon (positive = counter-clockwise)
double uv_signed_area(const NurbsCurve& c2d) {

    // even steps of the parameter: only the sign matters, so no arc-length integration
    const int count = std::max(c2d.cv_count() * 4, 16);
    const std::pair<double, double> domain = c2d.domain();
    std::vector<Point> pts;
    for (int i = 0; i <= count; ++i)
        pts.push_back(c2d.point_at(domain.first + (domain.second - domain.first) * i / count));
    double area = 0.0;

    for (size_t i = 0; i + 1 < pts.size(); ++i)
        area += pts[i][0] * pts[i + 1][1] - pts[i + 1][0] * pts[i][1];

    return 0.5 * area;
}

/// Signed area of a closed UV polygon (positive = counter-clockwise)
double polygon_signed_area(const std::vector<Point>& pts) {

    const size_t n = pts.size();
    double area = 0.0;

    for (size_t i = 0; i < n; ++i) {
        const Point& p = pts[i];
        const Point& q = pts[(i + 1) % n];
        area += p[0] * q[1] - q[0] * p[1];
    }

    return 0.5 * area;
}

/// Diagonal of the control point bounding box
double bbox_diagonal(const NurbsSurface& srf) {

    Point lo(1e30, 1e30, 1e30);
    Point hi(-1e30, -1e30, -1e30);

    for (int i = 0; i < srf.cv_count(0); ++i)
        for (int j = 0; j < srf.cv_count(1); ++j) {
            const Point p = srf.get_cv(i, j);

            for (int k = 0; k < 3; ++k) {
                lo[k] = std::min(lo[k], p[k]);
                hi[k] = std::max(hi[k], p[k]);
            }
        }

    return hi.distance(lo);
}

/// Diagonal of the bounding box of every surface's control points: the size a chord tolerance and a face's share of the sampling are measured against
double brep_diagonal(const BRep& b) {

    Point lo(1e30, 1e30, 1e30);
    Point hi(-1e30, -1e30, -1e30);

    for (const NurbsSurface& srf : b.m_surfaces)
        for (int i = 0; i < srf.cv_count(0); ++i)
            for (int j = 0; j < srf.cv_count(1); ++j) {
                const Point p = srf.get_cv(i, j);

                for (int k = 0; k < 3; ++k) {
                    lo[k] = std::min(lo[k], p[k]);
                    hi[k] = std::max(hi[k], p[k]);
                }
            }

    if (b.m_surfaces.empty())
        return 0.0;

    return hi.distance(lo);
}

// ═══════════════════════════════════════════════════════════════════════════
// Factory helpers
// ═══════════════════════════════════════════════════════════════════════════
/// Planar polygon faces from a vertex table: edges run lo -> hi vertex and are shared, a face lists its vertices counter-clockwise seen from outside so the patch normal points outward
struct PolyFaceBuilder {
    BRep& b; // BRep being built.
    std::map<std::pair<int, int>, int> edge_map; // Edge per (lo, hi) pair.

    /// Straight edge between two vertices, shared by every face that uses it
    int edge(int v0, int v1) {

        const int lo = std::min(v0, v1);
        const int hi = std::max(v0, v1);
        const auto it = edge_map.find({lo, hi});

        if (it != edge_map.end())
            return it->second;

        const NurbsCurve line = NurbsCurve::create(false, 1, {b.m_vertices[lo].point, b.m_vertices[hi].point});
        const int ei = b.add_edge(b.add_curve_3d(line), lo, hi);
        edge_map[{lo, hi}] = ei;

        return ei;
    }

    /// Oriented edge references of the vertex cycle `vi`, each with its pcurve on surface `si`
    std::vector<BRepRef> wire_refs(int si, const std::vector<int>& vi) {

        const NurbsSurface& srf = b.m_surfaces[si];
        std::vector<BRepRef> refs;
        const int n = (int)vi.size();

        for (int i = 0; i < n; ++i) {
            const int va = vi[i];
            const int vb = vi[(i + 1) % n];
            const int ei = edge(va, vb);
            b.add_pcurve(ei, si, b.add_curve_2d(project_to_patch(b.m_curves_3d[b.m_edges[ei].curve_3d_index], srf)));
            refs.push_back({ei, b.m_edges[ei].start_vertex == va ? F : R});
        }

        return refs;
    }

    /// Face on `srf` bounded by the vertex cycle `vi`, with one inner wire per hole cycle; returns the face index
    int face(const NurbsSurface& srf, const std::vector<int>& vi, const std::vector<std::vector<int>>& holes = {}) {

        const int si = b.add_surface(srf);
        std::vector<BRepRef> wires{{b.add_wire(wire_refs(si, vi)), F}};

        for (const std::vector<int>& hole : holes)
            wires.push_back({b.add_wire(wire_refs(si, hole)), F});

        return b.add_face(si, wires);
    }
};

const std::vector<int> BOX_FACES[6] = {
    {0, 3, 2, 1},
    {4, 5, 6, 7},
    {0, 1, 5, 4},
    {1, 2, 6, 5},
    {2, 3, 7, 6},
    {3, 0, 4, 7},
};

/// Bilinear patch spanned by four vertex indices in face order (p00, p10, p11, p01)
NurbsSurface quad_patch(const BRep& b, const std::vector<int>& fv) {

    return bilinear_patch(b.m_vertices[fv[0]].point, b.m_vertices[fv[1]].point, b.m_vertices[fv[3]].point, b.m_vertices[fv[2]].point);
}

/// The eight corners of an origin-centered box, bottom ring then top ring
void box_corners(BRep& b, double sx, double sy, double sz) {

    const double hx = sx * 0.5;
    const double hy = sy * 0.5;
    const double hz = sz * 0.5;

    b.add_vertex(Point(-hx, -hy, -hz));
    b.add_vertex(Point(hx, -hy, -hz));
    b.add_vertex(Point(hx, hy, -hz));
    b.add_vertex(Point(-hx, hy, -hz));
    b.add_vertex(Point(-hx, -hy, hz));
    b.add_vertex(Point(hx, -hy, hz));
    b.add_vertex(Point(hx, hy, hz));
    b.add_vertex(Point(-hx, hy, hz));
}

/// Planar cap at height z with natural normal +Z (up) or -Z (down), spanning [-r, r]^2
NurbsSurface cap_patch(double r, double z, bool up) {

    if (up)
        return bilinear_patch(Point(-r, -r, z), Point(r, -r, z), Point(-r, r, z), Point(r, r, z));

    return bilinear_patch(Point(-r, -r, z), Point(-r, r, z), Point(r, -r, z), Point(r, r, z));
}

/// Cap face bounded by one closed edge: outer wire counter-clockwise in the patch's UV
int cap_face(BRep& b, const NurbsSurface& cap, int edge) {

    const int si = b.add_surface(cap);
    const NurbsCurve c2d = project_to_patch(b.m_curves_3d[b.m_edges[edge].curve_3d_index], cap);
    const BRepOrientation o = uv_signed_area(c2d) > 0.0 ? F : R;
    b.add_pcurve(edge, si, b.add_curve_2d(c2d));

    return b.add_face(si, {{b.add_wire({{edge, o}}), F}});
}

/// Periodic body face (cylinder / cone / bore): seam from v0 to v1 at u0 == u1, bottom ring forward at v0, top ring (or degenerated apex) reversed at v1
int body_face(BRep& b, int si, int e_bot, int e_seam, int e_top) {

    const std::pair<double, double> du = b.m_surfaces[si].domain(0);
    const std::pair<double, double> dv = b.m_surfaces[si].domain(1);
    const double u0 = du.first;
    const double u1 = du.second;
    const double v0 = dv.first;
    const double v1 = dv.second;

    b.add_pcurve(e_bot, si, b.add_curve_2d(uv_line(u0, v0, u1, v0)));
    b.add_pcurve(e_top, si, b.add_curve_2d(uv_line(u0, v1, u1, v1)));
    b.add_pcurve(e_seam, si, b.add_curve_2d(uv_line(u1, v0, u1, v1)), b.add_curve_2d(uv_line(u0, v0, u0, v1)));

    return b.add_face(si, {{b.add_wire({{e_bot, F}, {e_seam, F}, {e_top, R}, {e_seam, R}}), F}});
}

/// Point of the plane (org, xa, ya) at (u, v)
Point plane_point(const Point& org, const Vector& xa, const Vector& ya, double u, double v) {

    return org + xa * u + ya * v;
}

/// Padded bilinear patch through `pts` in the plane (org, xa, ya)
NurbsSurface planar_patch_through(const std::vector<Point>& pts, const Point& org, const Vector& xa, const Vector& ya) {

    double umin = 1e30;
    double umax = -1e30;
    double vmin = 1e30;
    double vmax = -1e30;

    for (const Point& p : pts) {
        const Vector d = p - org;
        const double u = d.dot(xa);
        const double v = d.dot(ya);
        umin = std::min(umin, u);
        umax = std::max(umax, u);
        vmin = std::min(vmin, v);
        vmax = std::max(vmax, v);
    }

    const double pad = std::max(umax - umin, vmax - vmin) * 0.01;
    umin -= pad;
    umax += pad;
    vmin -= pad;
    vmax += pad;

    return bilinear_patch(
        plane_point(org, xa, ya, umin, vmin),
        plane_point(org, xa, ya, umax, vmin),
        plane_point(org, xa, ya, umin, vmax),
        plane_point(org, xa, ya, umax, vmax)
    );
}

/// Signed area of a closed cycle of points seen in the plane (org, xa, ya): positive when it runs counter-clockwise
double signed_area_in_plane(const std::vector<Point>& pts, const Point& org, const Vector& xa, const Vector& ya) {

    double area = 0.0;
    const size_t n = pts.size();

    for (size_t i = 0; i < n; ++i) {
        const Vector a = pts[i] - org;
        const Vector b = pts[(i + 1) % n] - org;
        area += a.dot(xa) * b.dot(ya) - b.dot(xa) * a.dot(ya);
    }

    return area * 0.5;
}

/// The vertices of a polyline without the closing duplicate
std::vector<Point> open_points(const Polyline& pl) {

    std::vector<Point> pts = pl.get_points();
    const size_t n = pl.is_closed() ? (pts.empty() ? 0 : pts.size() - 1) : pts.size();
    pts.resize(n);

    return pts;
}

/// Index of the first vertex within `tol` of `p`, a new vertex when none is
int find_or_add_vertex(BRep& b, const Point& p, double tol) {

    for (int i = 0; i < (int)b.m_vertices.size(); ++i)
        if (b.m_vertices[i].point.distance(p) < tol)
            return i;

    return b.add_vertex(p);
}

/// Euclidean control points of a curve, zero weights skipped
std::vector<Point> cv_points(const NurbsCurve& c) {

    std::vector<Point> pts;

    for (int k = 0; k < c.cv_count(); ++k) {
        double wx = 0.0;
        double wy = 0.0;
        double wz = 0.0;
        double w = 0.0;
        std::tie(wx, wy, wz, w) = c.get_cv_4d(k);

        if (w != 0.0)
            pts.push_back(Point(wx / w, wy / w, wz / w));
    }

    return pts;
}

/// One-edge wire of a closed or open curve on planar surface `si`, sharing vertices within `tol`
int curve_wire(BRep& b, const NurbsCurve& crv, int si, double tol) {

    const Point sp = crv.point_at(crv.domain().first);
    const Point ep = crv.point_at(crv.domain().second);
    const int vs = find_or_add_vertex(b, sp, tol);
    const int ve = crv.is_closed() ? vs : find_or_add_vertex(b, ep, tol);
    const int ei = b.add_edge(b.add_curve_3d(crv), vs, ve);
    b.add_pcurve(ei, si, b.add_curve_2d(project_to_patch(crv, b.m_surfaces[si])));

    return b.add_wire({{ei, F}});
}

// ═══════════════════════════════════════════════════════════════════════════
// Sewing helpers
// ═══════════════════════════════════════════════════════════════════════════
/// Signed volume of face meshes (positive when the windings point outward)
double signed_volume(const std::vector<Mesh>& meshes) {

    double total = 0.0;

    for (const Mesh& fm : meshes)
        for (const std::pair<const size_t, std::vector<size_t>>& entry : fm.face)
            for (size_t k = 1; k + 1 < entry.second.size(); ++k) {
                const Point a = fm.vertex.at(entry.second[0]).position();
                const Point b = fm.vertex.at(entry.second[k]).position();
                const Point c = fm.vertex.at(entry.second[k + 1]).position();
                total += a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0]);
            }

    return total / 6.0;
}

/// Face uses of every edge as (face, composed orientation); empty when some edge is not used exactly twice
std::vector<std::vector<std::pair<int, BRepOrientation>>> edge_uses(const BRep& b) {

    std::vector<std::vector<std::pair<int, BRepOrientation>>> uses(b.m_edges.size());

    for (int fi = 0; fi < b.face_count(); ++fi)
        for (const BRepRef& wr : b.m_faces[fi].wires)
            for (const BRepRef& er : b.wire_edges(wr))
                uses[er.index].push_back({fi, er.orientation});

    for (const std::vector<std::pair<int, BRepOrientation>>& use : uses)
        if (use.size() != 2)
            return {};

    return uses;
}

/// Connected components of faces, each face oriented consistently with the neighbour it was reached from
std::vector<std::vector<int>> face_components(
    const BRep& b,
    const std::vector<std::vector<std::pair<int, BRepOrientation>>>& uses,
    std::vector<BRepOrientation>& fo
) {

    const int nf = b.face_count();
    std::vector<bool> seen(nf, false);
    std::vector<std::vector<int>> components;

    for (int seed = 0; seed < nf; ++seed) {
        if (seen[seed])
            continue;

        std::vector<int> comp;
        std::vector<int> stack = {seed};
        seen[seed] = true;

        while (!stack.empty()) {
            const int fi = stack.back();
            stack.pop_back();
            comp.push_back(fi);

            for (const BRepRef& wr : b.m_faces[fi].wires)
                for (const BRepRef& er : b.wire_edges(wr))
                    for (const std::pair<int, BRepOrientation>& use : uses[er.index]) {
                        if (use.first == fi || seen[use.first])
                            continue;

                        fo[use.first] = use.second == er.orientation ? brep_reverse(fo[fi]) : fo[fi];
                        seen[use.first] = true;
                        stack.push_back(use.first);
                    }
        }

        components.push_back(comp);
    }

    return components;
}

/// BRepBuilderAPI_Sewing + MakeSolid for free faces: when every edge is shared by exactly two face uses, one shell per connected component wound outward and one solid per shell
void close_free_faces(BRep& b) {

    const int nf = b.face_count();

    if (nf == 0)
        return;

    const std::vector<std::vector<std::pair<int, BRepOrientation>>> uses = edge_uses(b);

    if (uses.empty())
        return;

    std::vector<BRepOrientation> fo(nf, F);
    std::vector<BRepRef> shells;

    for (const std::vector<int>& comp : face_components(b, uses, fo)) {
        std::vector<BRepRef> refs;

        for (const int fi : comp)
            refs.push_back({fi, fo[fi]});

        shells.push_back({b.add_shell(refs), F});
    }

    const std::vector<Mesh> fm = b.face_meshes();

    for (const BRepRef& sr : shells) {
        std::vector<Mesh> part;

        for (const BRepRef& fr : b.m_shells[sr.index].faces)
            part.push_back(fm[fr.index]);

        if (signed_volume(part) < 0.0)
            for (BRepRef& fr : b.m_shells[sr.index].faces)
                fr.orientation = brep_reverse(fr.orientation);

        b.add_solid({sr});
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Planar face helpers
// ═══════════════════════════════════════════════════════════════════════════
const int CURVED_EDGE_SAMPLES = 16; // Samples per curved edge of a planar face.

/// Open outline of a face's outer wire in wire order: vertices of straight edges, samples of curved ones
std::vector<Point> face_outline(const BRep& b, int fi) {

    std::vector<Point> points;

    for (const BRepRef& er : b.wire_edges(b.m_faces[fi].wires[0])) {
        if (er.index < 0 || er.index >= (int)b.m_edges.size())
            continue;

        const BRepEdge& edge = b.m_edges[er.index];

        if (edge.degenerated)
            continue;

        const bool reversed = er.orientation == BRepOrientation::Reversed;
        const bool curved = edge.curve_3d_index >= 0 && b.m_curves_3d[edge.curve_3d_index].degree() > 1;

        if (curved) {
            const NurbsCurve& c = b.m_curves_3d[edge.curve_3d_index];
            const double d0 = c.domain().first;
            const double d1 = c.domain().second;

            for (int s = 0; s < CURVED_EDGE_SAMPLES; ++s) {
                const double u = (double)s / (double)CURVED_EDGE_SAMPLES;
                const double t = reversed ? d1 + (d0 - d1) * u : d0 + (d1 - d0) * u;
                points.push_back(c.point_at(t));
            }
        } else {
            const int start = reversed ? edge.end_vertex : edge.start_vertex;

            if (start >= 0 && start < (int)b.m_vertices.size())
                points.push_back(b.m_vertices[start].point);
        }
    }

    return points;
}

/// Signed volume enclosed by closed outlines (tetrahedra fans from the origin), positive when wound outward
double outline_volume(const std::vector<Polyline>& polylines) {

    double total = 0.0;

    for (const Polyline& pl : polylines) {
        const std::vector<Point> pts = pl.get_points();

        if (pts.size() < 3)
            continue;

        const Point& p0 = pts[0];

        for (size_t k = 1; k + 1 < pts.size(); ++k) {
            const Point& p1 = pts[k];
            const Point& p2 = pts[k + 1];
            total += p0[0] * (p1[1] * p2[2] - p1[2] * p2[1]) + p0[1] * (p1[2] * p2[0] - p1[0] * p2[2]) + p0[2] * (p1[0] * p2[1] - p1[1] * p2[0]);
        }
    }

    return total / 6.0;
}

/// Outer polyline and outward plane of every planar face in one walk, so the two stay index-aligned
std::pair<std::vector<Polyline>, std::vector<Plane>> planar_faces(const BRep& b) {

    std::vector<Polyline> polylines;
    std::vector<Plane> planes;

    for (int fi = 0; fi < b.face_count(); ++fi) {
        const BRepFace& face = b.m_faces[fi];

        if (face.surface_index < 0 || face.wires.empty())
            continue;

        if (!b.m_surfaces[face.surface_index].is_planar())
            continue;

        std::vector<Point> points = face_outline(b, fi);

        if (points.size() < 3)
            continue;

        const Point origin = Point::centroid(points);
        Vector normal = Vector::average_normal(points);

        if (b.face_orientation(fi) == BRepOrientation::Reversed)
            normal.reverse();

        points.push_back(points.front());
        polylines.emplace_back(points);
        planes.push_back(Plane::from_point_normal(origin, normal));
    }

    if (b.is_solid() && outline_volume(polylines) < 0.0)
        for (Plane& pl : planes) {
            Vector n = pl.z_axis();
            n.reverse();
            pl = Plane::from_point_normal(pl.origin(), n);
        }

    return {polylines, planes};
}

// ═══════════════════════════════════════════════════════════════════════════
// Meshing helpers
// ═══════════════════════════════════════════════════════════════════════════
/// Canonical boundary of every shared edge: model points, the (face, pcurve, parameters) that produced them, and refined (t, uv) samples
using ParametricBoundarySample = std::tuple<double, Point, Point>;

struct EdgeBoundary {
    std::map<int, std::vector<Point>> points; // Canonical model points per edge.
    std::map<int, std::tuple<int, int, std::vector<double>>> basis; // (face, pcurve, parameters) per edge.
    std::map<int, std::vector<std::pair<double, Point>>> samples; // Refined (t, uv) samples per edge.
    std::map<std::tuple<int, int, int, int>, std::vector<ParametricBoundarySample>> parametric_uses;
};

/// Order (parameter, point) pairs by parameter
bool parameter_less(const std::pair<double, Point>& a, const std::pair<double, Point>& b) {

    return a.first < b.first;
}

/// Same parameter of two (parameter, point) pairs
bool parameter_equal(const std::pair<double, Point>& a, const std::pair<double, Point>& b) {

    return a.first == b.first;
}

/// Order boundary samples (t, uv, point) by t
bool sample_less(const std::tuple<double, Point, Point>& a, const std::tuple<double, Point, Point>& b) {

    return std::get<0>(a) < std::get<0>(b);
}

/// Same t of two boundary samples
bool sample_equal(const std::tuple<double, Point, Point>& a, const std::tuple<double, Point, Point>& b) {

    return std::get<0>(a) == std::get<0>(b);
}

/// Order UV points by u, then v
bool uv_less(const Point& a, const Point& b) {

    return a[0] < b[0] || (a[0] == b[0] && a[1] < b[1]);
}

/// UV polygon of one wire of a face (pcurves sampled in traversal order)
std::vector<Point> wire_uv_points(const BRep& b, int face_index, const BRepRef& wire) {

    std::vector<Point> pts;

    for (const BRepRef& er : b.wire_edges(wire)) {
        const int ci = b.pcurve_index(er.index, face_index, er.orientation);

        if (ci < 0)
            continue;

        const NurbsCurve& crv = b.m_curves_2d[ci];
        std::vector<Point> seg;

        if (crv.degree() <= 1 && !crv.is_rational())
            for (int k = 0; k < crv.cv_count(); ++k)
                seg.push_back(crv.get_cv(k));
        else
            seg = crv.divide_by_count(std::max(crv.cv_count() * 4, 16), true).first;

        if (er.orientation == BRepOrientation::Reversed)
            std::reverse(seg.begin(), seg.end());

        for (size_t k = 0; k + 1 < seg.size(); ++k)
            pts.push_back(seg[k]);
    }

    return pts;
}

/// Distance from `point` to the surface point the pcurve reaches at t
double lifted_distance(const NurbsSurface& surface, const NurbsCurve& curve, const Point& point, double t) {

    const Point uv = curve.point_at(t);

    return surface.point_at(uv[0], uv[1]).distance(point);
}

/// Parameter and distance of the lifted pcurve closest to `point` within [left, right] by 64 golden-section steps
std::pair<double, double> golden_parameter(const NurbsSurface& surface, const NurbsCurve& curve, const Point& point, double left, double right) {

    const double ratio = (std::sqrt(5.0) - 1.0) * 0.5;
    double a = right - ratio * (right - left);
    double b = left + ratio * (right - left);
    double da = lifted_distance(surface, curve, point, a);
    double db = lifted_distance(surface, curve, point, b);

    for (int i = 0; i < 64; ++i) {
        if (da < db) {
            right = b;
            b = a;
            db = da;
            a = right - ratio * (right - left);
            da = lifted_distance(surface, curve, point, a);
        } else {
            left = a;
            a = b;
            da = db;
            b = left + ratio * (right - left);
            db = lifted_distance(surface, curve, point, b);
        }
    }

    return da < db ? std::make_pair(a, da) : std::make_pair(b, db);
}

/// Parameter of the lifted pcurve closest to `point`: a coarse scan then golden-section steps in the best cell, and in the cell at the other end too when a closed pcurve scans best at an end, since both ends are one point
double boundary_parameter(const NurbsSurface& surface, const NurbsCurve& curve, const Point& point) {

    const double start = curve.domain().first;
    const double end = curve.domain().second;
    const int count = std::clamp(curve.cv_count() * 4, 32, 4096);
    const double step = (end - start) / count;
    double best = start;
    double error = lifted_distance(surface, curve, point, start);

    for (int index = 1; index <= count; ++index) {
        const double t = index == count ? end : start + index * step;
        const double candidate = lifted_distance(surface, curve, point, t);

        if (candidate < error) {
            best = t;
            error = candidate;
        }
    }

    std::vector<std::pair<double, double>> cells = {{std::max(best - step, start), std::min(best + step, end)}};
    const bool closed = curve.point_at(start).distance(curve.point_at(end)) <= Tolerance::ZERO_TOLERANCE;

    if (closed && best == start)
        cells.push_back({end - step, end});

    if (closed && best == end)
        cells.push_back({start, start + step});

    for (const std::pair<double, double>& cell : cells) {
        const std::pair<double, double> found = golden_parameter(surface, curve, point, cell.first, cell.second);

        if (found.second < error) {
            best = found.first;
            error = found.second;
        }
    }

    return best;
}

/// Unit normal on a boundary, taking the one-sided limit toward `toward` at a singular endpoint
std::optional<Vector> boundary_normal(const NurbsSurface& surface, const NurbsCurve& curve, double t, double toward) {

    for (const double at : {t, t + (toward - t) * 1e-6}) {
        const Point uv = curve.point_at(at);
        const std::vector<Vector> derivatives = surface.evaluate(uv[0], uv[1], 1);

        if (derivatives.size() < 3)
            continue;

        // At a pole one derivative is rounding noise, which still crosses to a nonzero vector at any size but one.
        const double first = derivatives[1].magnitude();
        const double second = derivatives[2].magnitude();

        if (std::min(first, second) <= 1e-10 * std::max(first, second))
            continue;

        Vector n = derivatives[1].cross(derivatives[2]);
        const double scale = std::max({std::abs(n[0]), std::abs(n[1]), std::abs(n[2])});

        if (!std::isfinite(scale) || scale == 0.0)
            continue;

        n = n / scale;
        const double length = n.magnitude();

        if (std::isfinite(length) && length > 0.0)
            return n / length;
    }

    return std::nullopt;
}

/// True when the normals at ta, t and tb turn more than the angle whose cosine is given
bool boundary_turns(const NurbsSurface& surface, const NurbsCurve& curve, double ta, double t, double tb, double cosine) {

    const std::optional<Vector> normals[3] = {
        boundary_normal(surface, curve, ta, tb),
        boundary_normal(surface, curve, t, ta),
        boundary_normal(surface, curve, tb, ta),
    };

    for (int j = 0; j < 3; ++j)
        for (int k = j + 1; k < 3; ++k) {
            if (!normals[j] || !normals[k])
                continue;

            if (normals[j]->dot(*normals[k]) < cosine)
                return true;
        }

    return false;
}

/// Refine samples of a lifted pcurve until chord and angle hold, the chord measured against the whole BRep's size `scale`; existing samples stay exact, eight split levels and 4096 added points per edge bound the work
std::vector<std::tuple<double, Point, Point>> refine_surface_boundary(
    const NurbsSurface& surface,
    const NurbsCurve& curve,
    const std::vector<std::tuple<double, Point, Point>>& samples,
    double scale,
    double angle,
    double chord
) {

    if (samples.size() < 2)
        return samples;

    const double tolerance = scale * chord;
    const double cosine = std::cos(std::clamp(angle, 0.1, 179.0) * Tolerance::PI / 180.0);
    std::vector<std::tuple<double, Point, Point>> result;
    int added = 0;

    for (size_t i = 1; i < samples.size(); ++i) {
        std::vector<std::tuple<std::tuple<double, Point, Point>, std::tuple<double, Point, Point>, int>> stack = {{samples[i - 1], samples[i], 0}};

        while (!stack.empty()) {
            std::tuple<double, Point, Point> a;
            std::tuple<double, Point, Point> b;
            int depth = 0;
            std::tie(a, b, depth) = stack.back();
            stack.pop_back();
            const double t = (std::get<0>(a) + std::get<0>(b)) * 0.5;
            const Point uv = curve.point_at(t);
            const Point point = surface.point_at(uv[0], uv[1]);
            const Point& pa = std::get<2>(a);
            const Point& pb = std::get<2>(b);
            const Point center((pa[0] + pb[0]) * 0.5, (pa[1] + pb[1]) * 0.5, (pa[2] + pb[2]) * 0.5);
            const bool split = (point.distance(center) > tolerance || boundary_turns(surface, curve, std::get<0>(a), t, std::get<0>(b), cosine)) && depth < 8 && added < 4096;

            if (!split) {
                result.push_back(a);
                continue;
            }

            ++added;
            const std::tuple<double, Point, Point> middle{t, uv, point};
            stack.push_back({middle, b, depth + 1});
            stack.push_back({a, middle, depth + 1});
        }
    }

    result.push_back(samples.back());

    return result;
}

/// Compare canonical boundary positions exactly, without tolerance
bool same_boundary_point(const Point& a, const Point& b) {

    return a[0] == b[0] && a[1] == b[1] && a[2] == b[2];
}

/// Planarity tolerance for a surface of any size: 1e-9 of its control-point bounding box diagonal, never below the zero tolerance
double planar_patch_tolerance(const NurbsSurface& srf) {

    double lo[3] = {1e300, 1e300, 1e300};
    double hi[3] = {-1e300, -1e300, -1e300};

    for (int i = 0; i < srf.cv_count(0); ++i)
        for (int j = 0; j < srf.cv_count(1); ++j) {
            const Point p = srf.get_cv(i, j);

            for (int k = 0; k < 3; ++k) {
                lo[k] = std::min(lo[k], p[k]);
                hi[k] = std::max(hi[k], p[k]);
            }
        }

    const double diagonal = std::sqrt((hi[0] - lo[0]) * (hi[0] - lo[0]) + (hi[1] - lo[1]) * (hi[1] - lo[1]) + (hi[2] - lo[2]) * (hi[2] - lo[2]));

    return std::max(1e-9 * diagonal, Tolerance::ZERO_TOLERANCE);
}

/// True for a surface flat within planar_patch_tolerance, whatever its coordinates
bool is_planar_patch(const NurbsSurface& srf) {

    return srf.is_planar(nullptr, planar_patch_tolerance(srf));
}

/// Positions of the start and end vertex of an edge: the one point every face must place at each end of the edge
std::pair<Point, Point> edge_ends(const BRep& b, int ei) {

    const BRepEdge& edge = b.m_edges[ei];

    return {b.m_vertices[edge.start_vertex].point, b.m_vertices[edge.end_vertex].point};
}

/// Place the first and last sample of an edge on its vertices, so every incident face meets there bit for bit
void snap_sample_ends(std::vector<std::tuple<double, Point, Point>>& samples, const std::pair<Point, Point>& ends) {

    if (samples.empty())
        return;

    std::get<2>(samples.front()) = ends.first;
    std::get<2>(samples.back()) = ends.second;
}

/// Phase 1: move the grid vertices of a direct face that sit on a pcurve end onto that edge's vertex, as every other face does
void snap_grid_corners(const BRep& b, int fi, Mesh& grid) {

    const BRepFace& face = b.m_faces[fi];
    const NurbsSurface& srf = b.m_surfaces[face.surface_index];
    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const double utol = (du.second - du.first) * 1e-4;
    const double vtol = (dv.second - dv.first) * 1e-4;
    std::vector<std::pair<Point, Point>> corners;

    for (const BRepRef& er : b.wire_edges(face.wires[0])) {
        const int ci = b.pcurve_index(er.index, fi, er.orientation);

        if (ci < 0)
            continue;

        const NurbsCurve& crv = b.m_curves_2d[ci];
        const std::pair<Point, Point> ends = edge_ends(b, er.index);
        corners.push_back({crv.get_cv(0), ends.first});
        corners.push_back({crv.get_cv(crv.cv_count() - 1), ends.second});
    }

    for (std::pair<const size_t, VertexData>& entry : grid.vertex) {
        const auto u = entry.second.attributes.find("u");
        const auto v = entry.second.attributes.find("v");

        if (u == entry.second.attributes.end() || v == entry.second.attributes.end())
            continue;

        for (const std::pair<Point, Point>& corner : corners) {
            if (std::abs(corner.first[0] - u->second) <= utol && std::abs(corner.first[1] - v->second) <= vtol) {
                entry.second.set_position(corner.second);
                break;
            }
        }
    }
}

/// Phase 1: the outer wire is the full UV rectangle (straight pcurves enclosing the whole domain, no holes), so the face meshes directly on the surface grid
bool direct_face(const BRep& b, int fi) {

    const BRepFace& face = b.m_faces[fi];

    if (face.wires.size() != 1)
        return false;

    for (const BRepRef& er : b.wire_edges(face.wires[0])) {
        const int ci = b.pcurve_index(er.index, fi, er.orientation);

        if (ci < 0)
            continue;

        if (b.m_curves_2d[ci].degree() > 1 || b.m_curves_2d[ci].is_rational())
            return false;
    }

    const std::vector<Point> outer = wire_uv_points(b, fi, face.wires[0]);

    if (outer.size() < 3)
        return false;

    const NurbsSurface& srf = b.m_surfaces[face.surface_index];
    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);

    for (const BRepRef& er : b.wire_edges(face.wires[0])) {
        const int ci = b.pcurve_index(er.index, fi, er.orientation);

        if (ci < 0)
            continue;

        const NurbsCurve& curve = b.m_curves_2d[ci];

        for (int k : {0, std::max(0, curve.cv_count() - 1)}) {
            const Point p = curve.get_cv(k);
            const bool corner_u = std::min(std::abs(p[0] - du.first), std::abs(p[0] - du.second)) <= (du.second - du.first) * 1e-9;
            const bool corner_v = std::min(std::abs(p[1] - dv.first), std::abs(p[1] - dv.second)) <= (dv.second - dv.first) * 1e-9;

            if (!corner_u || !corner_v)
                return false;
        }
    }

    const double domain_area = (du.second - du.first) * (dv.second - dv.first);

    return std::abs(std::abs(polygon_signed_area(outer)) - domain_area) < 1e-3 * domain_area;
}

/// Grid vertices on the domain sides flagged by (at_v0, at_v1, at_u0, at_u1), as (parameter along the side, model point) sorted and unique
std::vector<std::pair<double, Point>> grid_side_points(
    const Mesh& grid,
    const NurbsSurface& srf,
    bool at_v0,
    bool at_v1,
    bool at_u0,
    bool at_u1
) {

    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const double utol = (du.second - du.first) * 0.001;
    const double vtol = (dv.second - dv.first) * 0.001;
    std::vector<std::pair<double, Point>> pts;

    for (const std::pair<const size_t, VertexData>& entry : grid.vertex) {
        const VertexData& vd = entry.second;
        const auto iu = vd.attributes.find("u");
        const auto iv = vd.attributes.find("v");

        if (iu == vd.attributes.end() || iv == vd.attributes.end())
            continue;

        if ((at_v0 && std::abs(iv->second - dv.first) < vtol * 0.1) || (at_v1 && std::abs(iv->second - dv.second) < vtol * 0.1))
            pts.push_back({iu->second, vd.position()});
        else if ((at_u0 && std::abs(iu->second - du.first) < utol * 0.1) || (at_u1 && std::abs(iu->second - du.second) < utol * 0.1))
            pts.push_back({iv->second, vd.position()});
    }

    std::sort(pts.begin(), pts.end(), parameter_less);
    pts.erase(std::unique(pts.begin(), pts.end(), parameter_equal), pts.end());

    return pts;
}

/// Phase 2: grid vertices of a direct face along a shared edge that runs on a domain side, as (pcurve parameter, model point) sorted along the edge; empty elsewhere
std::vector<std::pair<double, Point>> grid_edge_samples(const BRep& b, int fi, const Mesh& grid, const BRepRef& er) {

    std::vector<std::pair<double, Point>> samples;
    bool shared = false;

    for (const BRepRef& fr : b.edge_faces(er.index))
        if (fr.index != fi)
            shared = true;

    if (!shared)
        return samples;

    const int ci = b.pcurve_index(er.index, fi, er.orientation);

    if (ci < 0)
        return samples;

    const NurbsSurface& srf = b.m_surfaces[b.m_faces[fi].surface_index];
    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const double utol = (du.second - du.first) * 0.001;
    const double vtol = (dv.second - dv.first) * 0.001;
    const NurbsCurve& c2d = b.m_curves_2d[ci];
    const Point sp = c2d.get_cv(0);
    const Point ep = c2d.get_cv(c2d.cv_count() - 1);
    const bool at_v0 = std::abs(sp[1] - dv.first) < vtol && std::abs(ep[1] - dv.first) < vtol;
    const bool at_v1 = std::abs(sp[1] - dv.second) < vtol && std::abs(ep[1] - dv.second) < vtol;
    const bool at_u0 = std::abs(sp[0] - du.first) < utol && std::abs(ep[0] - du.first) < utol;
    const bool at_u1 = std::abs(sp[0] - du.second) < utol && std::abs(ep[0] - du.second) < utol;

    if (!at_v0 && !at_v1 && !at_u0 && !at_u1)
        return samples;

    const std::vector<std::pair<double, Point>> pts = grid_side_points(grid, srf, at_v0, at_v1, at_u0, at_u1);

    if (pts.size() < 2)
        return samples;

    const int varying = (at_v0 || at_v1) ? 0 : 1;
    const double t0 = c2d.domain().first;
    const double t1 = c2d.domain().second;

    for (const std::pair<double, Point>& pt : pts)
        samples.push_back({t0 + (pt.first - sp[varying]) / (ep[varying] - sp[varying]) * (t1 - t0), pt.second});

    return samples;
}

/// Phase 2: the first incident grid supplies the canonical polygon of every shared edge; true when this face's grid disagrees with an earlier one and must be rebuilt
bool grid_boundaries(const BRep& b, int fi, const Mesh& grid, EdgeBoundary& boundary) {

    bool rebuild = false;

    for (const BRepRef& er : b.wire_edges(b.m_faces[fi].wires[0])) {
        const int eidx = er.index;
        const std::vector<std::pair<double, Point>> samples = grid_edge_samples(b, fi, grid, er);

        if (samples.empty())
            continue;

        std::vector<double> parameters;
        std::vector<Point> bnd;

        for (const std::pair<double, Point>& sample : samples) {
            parameters.push_back(sample.first);
            bnd.push_back(sample.second);
        }

        if (!boundary.points.count(eidx)) {
            boundary.points[eidx] = bnd;
            boundary.basis[eidx] = {fi, b.pcurve_index(eidx, fi, er.orientation), parameters};
            continue;
        }

        const std::vector<Point>& canonical = boundary.points.at(eidx);
        const bool matches = canonical.size() == bnd.size()
            && (std::equal(canonical.begin(), canonical.end(), bnd.begin(), same_boundary_point)
                || std::equal(canonical.begin(), canonical.end(), bnd.rbegin(), same_boundary_point));
        rebuild = rebuild || !matches;
    }

    return rebuild;
}

/// Refine the canonical polygon of every edge shared with a curved CDT face, then mark every incident face for rebuild with the same refined polygon
void refine_shared_boundaries(
    const BRep& b,
    const std::vector<bool>& face_direct,
    std::vector<bool>& rebuild_grid,
    EdgeBoundary& boundary,
    double scale,
    double angle,
    double chord
) {

    for (const std::pair<const int, std::tuple<int, int, std::vector<double>>>& entry : boundary.basis) {
        const int edge = entry.first;
        const std::vector<double>& parameters = std::get<2>(entry.second);
        bool curved_cdt = false;

        for (const BRepRef& incident : b.edge_faces(edge)) {
            const int fi = incident.index;
            const bool cdt = !face_direct[fi] || rebuild_grid[fi];
            curved_cdt = curved_cdt || (cdt && !is_planar_patch(b.m_surfaces[b.m_faces[fi].surface_index]));
        }

        if (!curved_cdt)
            continue;

        const NurbsSurface& surface = b.m_surfaces[b.m_faces[std::get<0>(entry.second)].surface_index];
        const NurbsCurve& curve = b.m_curves_2d[std::get<1>(entry.second)];
        const std::vector<Point>& points = boundary.points.at(edge);
        std::vector<std::tuple<double, Point, Point>> samples;

        for (size_t i = 0; i < parameters.size(); ++i)
            samples.emplace_back(parameters[i], curve.point_at(parameters[i]), points[i]);

        std::sort(samples.begin(), samples.end(), sample_less);
        const double end = curve.domain().second;

        if (b.m_edges[edge].start_vertex == b.m_edges[edge].end_vertex && !samples.empty() && std::get<0>(samples.back()) < end)
            samples.emplace_back(end, curve.point_at(end), std::get<2>(samples.front()));

        const std::vector<std::tuple<double, Point, Point>> refined = refine_surface_boundary(surface, curve, samples, scale, angle, chord);

        if (refined.size() <= samples.size())
            continue;

        std::vector<Point> refined_points;
        std::vector<std::pair<double, Point>> refined_samples;

        for (const std::tuple<double, Point, Point>& sample : refined) {
            refined_points.push_back(std::get<2>(sample));
            refined_samples.emplace_back(std::get<0>(sample), std::get<1>(sample));
        }

        boundary.points[edge] = refined_points;
        boundary.samples[edge] = refined_samples;

        for (const BRepRef& incident : b.edge_faces(edge))
            rebuild_grid[incident.index] = true;
    }
}

/// Interior UV seeds of a rebuilt face: its grid vertices strictly inside the domain
std::vector<Point> grid_interior_uv(const NurbsSurface& srf, const Mesh& grid) {

    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    std::vector<Point> seeds;

    for (const std::pair<const size_t, VertexData>& entry : grid.vertex) {
        const auto u = entry.second.attributes.find("u");
        const auto v = entry.second.attributes.find("v");

        if (u == entry.second.attributes.end() || v == entry.second.attributes.end())
            continue;

        if (u->second > du.first && u->second < du.second && v->second > dv.first && v->second < dv.second)
            seeds.push_back(Point(u->second, v->second, 0.0));
    }

    std::sort(seeds.begin(), seeds.end(), uv_less);

    return seeds;
}

/// Surface parameters of a point on a degree-1 parallelogram patch by two dot products; false when the patch is not that shape
bool planar_patch_uv(const NurbsSurface& srf, const Point& p, double& u, double& v) {

    if (srf.degree(0) != 1 || srf.degree(1) != 1 || srf.cv_count(0) != 2 || srf.cv_count(1) != 2)
        return false;

    const Point p00 = srf.get_cv(0, 0);
    const Point p10 = srf.get_cv(1, 0);
    const Point p01 = srf.get_cv(0, 1);
    const Point p11 = srf.get_cv(1, 1);
    const Vector eu = p10 - p00;
    const Vector ev = p01 - p00;
    const Vector skew = (p11 - p10) - ev;

    if (skew.magnitude() > planar_patch_tolerance(srf))
        return false;

    const double eu2 = eu.dot(eu);
    const double ev2 = ev.dot(ev);

    if (eu2 <= 0.0 || ev2 <= 0.0)
        return false;

    const Vector d = p - p00;
    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    u = du.first + d.dot(eu) / eu2 * (du.second - du.first);
    v = dv.first + d.dot(ev) / ev2 * (dv.second - dv.first);

    return true;
}

/// Parameter of the closest point on a two-point degree-1 pcurve by one projection; false for any other curve
bool linear_pcurve_parameter(const NurbsCurve& crv, double u, double v, double& t) {

    if (crv.degree() != 1 || crv.is_rational() || crv.cv_count() != 2)
        return false;

    const Point c0 = crv.get_cv(0);
    const Point c1 = crv.get_cv(1);
    const double dx = c1[0] - c0[0];
    const double dy = c1[1] - c0[1];
    const double length_squared = dx * dx + dy * dy;

    if (length_squared <= 0.0)
        return false;

    const double fraction = std::clamp(((u - c0[0]) * dx + (v - c0[1]) * dy) / length_squared, 0.0, 1.0);
    const std::pair<double, double> domain = crv.domain();
    t = domain.first + fraction * (domain.second - domain.first);

    return true;
}

/// Parameter of the pcurve closest to `uv` by Newton steps from `seed`, clamped to the domain; the model-space check of the caller decides whether it is the right one
double pcurve_newton(const NurbsCurve& crv, const Point& uv, double seed) {

    const std::pair<double, double> domain = crv.domain();
    double t = std::clamp(seed, domain.first, domain.second);

    for (int i = 0; i < 16; ++i) {
        const std::vector<Vector> d = crv.evaluate(t, 2);

        if (d.size() < 3)
            break;

        const double rx = d[0][0] - uv[0];
        const double ry = d[0][1] - uv[1];
        const double f = rx * d[1][0] + ry * d[1][1];
        const double df = d[1][0] * d[1][0] + d[1][1] * d[1][1] + rx * d[2][0] + ry * d[2][1];

        if (df == 0.0)
            break;

        const double next = std::clamp(t - f / df, domain.first, domain.second);
        const double moved = std::abs(next - t);
        t = next;

        if (moved <= (domain.second - domain.first) * 1e-14)
            break;
    }

    return t;
}

/// Phase 3: first guess of the pcurve parameter of a canonical point: two dot products on a planar patch with a straight pcurve, Newton from the seed when the previous points of the edge give one, else the full closest-point search
double canonical_parameter(const NurbsSurface& srf, const NurbsCurve& crv, const Point& p, bool planar, bool seeded, double seed) {

    double u = 0.0;
    double v = 0.0;
    double t = 0.0;
    const bool on_patch = planar && planar_patch_uv(srf, p, u, v);

    if (!on_patch)
        std::tie(u, v) = srf.closest_parameters(p);

    if (on_patch && linear_pcurve_parameter(crv, u, v, t))
        return t;

    if (seeded)
        return pcurve_newton(crv, Point(u, v, 0.0), seed);

    return crv.closest_parameter(Point(u, v, 0.0));
}

/// Phase 3: map the canonical points of edge `ei` onto pcurve `ci` of face `fi`, checked in model space, each point seeded by the parameters of the two before it since the points run along the edge; a point the pcurve cannot reach within tolerance keeps the nearest parameter, since the canonical position is what the face places and the parameter only orders the loop
void lift_canonical(
    const BRep& b,
    int fi,
    int ei,
    int ci,
    EdgeBoundary& boundary,
    std::vector<std::tuple<double, Point, Point>>& samples
) {

    const BRepFace& face = b.m_faces[fi];
    const BRepEdge& edge = b.m_edges[ei];
    const NurbsSurface& srf = b.m_surfaces[face.surface_index];
    const NurbsCurve& crv = b.m_curves_2d[ci];
    const bool cached = boundary.basis.count(ei) && std::get<0>(boundary.basis[ei]) == fi && std::get<1>(boundary.basis[ei]) == ci && boundary.samples.count(ei);
    const std::vector<Point>& points = boundary.points[ei];
    const bool planar = is_planar_patch(srf);
    std::vector<double> lifted;

    for (size_t index = 0; index < points.size(); ++index) {
        const Point& p = points[index];
        const bool seeded = !lifted.empty();
        const double seed = lifted.size() < 2 ? (seeded ? lifted[0] : 0.0) : 2.0 * lifted[lifted.size() - 1] - lifted[lifted.size() - 2];
        double t = 0.0;
        Point q;

        if (cached) {
            t = boundary.samples[ei][index].first;
            q = boundary.samples[ei][index].second;
        } else {
            t = canonical_parameter(srf, crv, p, planar, seeded, seed);
            q = crv.point_at(t);
        }

        const double scale = std::max({std::abs(p[0]), std::abs(p[1]), std::abs(p[2]), 1.0});
        const double tolerance = std::max({edge.tolerance, face.tolerance, std::sqrt(std::numeric_limits<double>::epsilon()) * scale});

        if (srf.point_at(q[0], q[1]).distance(p) > tolerance) {
            t = boundary_parameter(srf, crv, p);
            q = crv.point_at(t);
        }

        lifted.push_back(t);
        samples.push_back({t, q, p});
    }

    std::sort(samples.begin(), samples.end(), sample_less);
    samples.erase(std::unique(samples.begin(), samples.end(), sample_equal), samples.end());
}

std::array<std::vector<double>, 2> parametric_crease_knots(const NurbsSurface& surface) {
    std::array<std::vector<double>, 2> result;
    for (int direction = 0; direction < 2; ++direction) {
        const std::pair<double, double> domain = surface.domain(direction);
        const std::vector<double>& knots = surface.m_nurbsknot[direction];
        for (double knot : knots)
            if (knot > domain.first && knot < domain.second
                && std::count(knots.begin(), knots.end(), knot) >= surface.degree(direction)
                && std::find(result[direction].begin(), result[direction].end(), knot) == result[direction].end())
                result[direction].push_back(knot);
    }
    return result;
}

/// Phase 3: fresh samples of a pcurve nobody has sampled yet, its ends on the edge's vertices, refined to the face's angle and chord
std::vector<std::tuple<double, Point, Point>> fresh_samples(const NurbsSurface& srf, const NurbsCurve& crv, const std::pair<Point, Point>& ends, double scale, double angle, double chord) {

    std::vector<Point> points;
    std::vector<double> parameters;

    if (crv.degree() <= 1 && !crv.is_rational() && is_planar_patch(srf)) {
        for (int k = 0; k < crv.cv_count(); ++k) {
            points.push_back(crv.get_cv(k));
            parameters.push_back(crv.greville_abcissa(k));
        }
    } else {
        const int count = std::min(std::max(crv.cv_count() * 4, (int)std::ceil(360.0 / std::max(angle, 0.1))), 4096);
        std::tie(points, parameters) = crv.divide_by_count(count, true);
    }

    // a sample on every crease the pcurve crosses, so the face across the edge gets that vertex too
    const std::array<std::vector<double>, 2> creases = parametric_crease_knots(srf);

    for (int dir = 0; dir < 2; ++dir)
        for (double knot : creases[dir])
            for (size_t k = 1; k < points.size(); ++k) {
                if (!((points[k - 1][dir] < knot && points[k][dir] > knot) || (points[k - 1][dir] > knot && points[k][dir] < knot)))
                    continue;

                double low = parameters[k - 1];
                double high = parameters[k];

                for (int step = 0; step < 64; ++step) {
                    const double middle = 0.5 * (low + high);

                    if ((crv.point_at(middle)[dir] < knot) == (points[k - 1][dir] < knot))
                        low = middle;
                    else
                        high = middle;
                }

                Point crossing = crv.point_at(low);
                crossing[dir] = knot;
                points.insert(points.begin() + k, crossing);
                parameters.insert(parameters.begin() + k, low);
            }

    std::vector<std::tuple<double, Point, Point>> samples;

    for (size_t k = 0; k < points.size(); ++k) {
        const Point& q = points[k];
        samples.push_back({parameters[k], q, srf.point_at(q[0], q[1])});
    }

    snap_sample_ends(samples, ends);

    return refine_surface_boundary(srf, crv, samples, scale, angle, chord);
}

/// A sample where the edge crosses a crease of the surface across it, or that face's mesh would have a vertex this one lacks.
void add_other_face_creases(const BRep& b, int fi, const BRepEdge& edge, const NurbsCurve& crv,
                            std::vector<std::tuple<double, Point, Point>>& samples) {

    const NurbsSurface& own = b.m_surfaces[b.m_faces[fi].surface_index];

    for (const BRepCurveOnSurface& use : edge.pcurves) {
        if (use.surface_index == b.m_faces[fi].surface_index)
            continue;

        const NurbsCurve& other = b.m_curves_2d[use.curve_2d_index];
        const std::array<std::vector<double>, 2> creases = parametric_crease_knots(b.m_surfaces[use.surface_index]);
        const auto mapped = [&](double t) {
            const double share = (t - crv.domain().first) / (crv.domain().second - crv.domain().first);
            return other.point_at(other.domain().first + share * (other.domain().second - other.domain().first));
        };

        for (int dir = 0; dir < 2; ++dir)
            for (double knot : creases[dir])
                for (size_t k = 1; k < samples.size(); ++k) {
                    double low = std::get<0>(samples[k - 1]);
                    double high = std::get<0>(samples[k]);
                    const double start = mapped(low)[dir] - knot;

                    if (start == 0.0 || start * (mapped(high)[dir] - knot) >= 0.0)
                        continue;

                    for (int step = 0; step < 64; ++step) {
                        const double middle = 0.5 * (low + high);

                        if ((mapped(middle)[dir] - knot) * start > 0.0)
                            low = middle;
                        else
                            high = middle;
                    }

                    const Point uv = crv.point_at(low);
                    samples.insert(samples.begin() + k, {low, uv, own.point_at(uv[0], uv[1])});
                    break;
                }
    }
}

/// Phase 3: samples of one edge use of a CDT face in traversal direction, a closed edge repeating its first point at the end; false when the edge has no pcurve
bool edge_use_samples(
    const BRep& b,
    int fi,
    const BRepRef& er,
    EdgeBoundary& boundary,
    double scale,
    double angle,
    double chord,
    std::vector<std::tuple<double, Point, Point>>& samples
) {

    const int ei = er.index;
    const BRepEdge& edge = b.m_edges[ei];
    const int ci = b.pcurve_index(ei, fi, er.orientation);

    if (ci < 0)
        return false;
    const auto cached = boundary.parametric_uses.find({fi, ei, ci, int(er.orientation)});
    if (mesh_parametric_metadata::capture_depth && cached != boundary.parametric_uses.end()) {
        samples = cached->second;
        return samples.size() >= 2;
    }

    const NurbsCurve& crv = b.m_curves_2d[ci];

    if (boundary.points.count(ei)) {
        lift_canonical(b, fi, ei, ci, boundary, samples);
    } else {
        samples = fresh_samples(b.m_surfaces[b.m_faces[fi].surface_index], crv, edge_ends(b, ei), scale, angle, chord);
        add_other_face_creases(b, fi, edge, crv, samples);
        std::vector<Point> positions;

        for (const std::tuple<double, Point, Point>& sample : samples)
            positions.push_back(std::get<2>(sample));

        boundary.points[ei] = positions;
    }

    if (edge.start_vertex == edge.end_vertex && samples.size() > 1) {
        const std::tuple<double, Point, Point> first = samples.front();

        if (!same_boundary_point(std::get<2>(first), std::get<2>(samples.back())))
            samples.push_back({crv.domain().second, crv.point_at(crv.domain().second), std::get<2>(first)});
    }

    if (er.orientation == BRepOrientation::Reversed)
        std::reverse(samples.begin(), samples.end());

    return samples.size() >= 2;
}


struct ParametricBoundaryUse {
    int face;
    int edge;
    int pcurve;
    BRepOrientation orientation;
    std::vector<ParametricBoundarySample> samples;
    bool reversed = false;
};

bool parametric_same_point(const Point& first, const Point& second) {
    return first[0] == second[0] && first[1] == second[1] && first[2] == second[2];
}

bool align_parametric_use(const std::vector<ParametricBoundarySample>& canonical, ParametricBoundaryUse& use) {
    if (canonical.size() != use.samples.size())
        return false;
    bool forward = true, reversed = true;
    for (size_t i = 0; i < canonical.size(); ++i) {
        const Point& point = std::get<2>(canonical[i]);
        forward &= parametric_same_point(point, std::get<2>(use.samples[i]));
        reversed &= parametric_same_point(point, std::get<2>(use.samples[canonical.size() - 1 - i]));
    }
    if (forward == reversed)
        return false;
    use.reversed = reversed;
    if (reversed)
        std::reverse(use.samples.begin(), use.samples.end());
    return true;
}

using ParametricPin = std::tuple<size_t, int, double>;
using ParametricCuts = std::map<double, std::vector<ParametricPin>>;

ParametricCuts parametric_segment_cuts(const BRep& brep, const std::vector<ParametricBoundaryUse>& uses,
                                      size_t segment) {
    ParametricCuts cuts = {{0, {}}, {1, {}}};
    for (size_t index = 0; index < uses.size(); ++index) {
        const ParametricBoundaryUse& use = uses[index];
        const NurbsSurface& surface = brep.m_surfaces[brep.m_faces[use.face].surface_index];
        const std::array<std::vector<double>, 2> knots = parametric_crease_knots(surface);
        const Point& first = std::get<1>(use.samples[segment]);
        const Point& last = std::get<1>(use.samples[segment + 1]);
        for (int direction = 0; direction < 2; ++direction)
            for (double knot : knots[direction]) {
                if (!(knot > std::min(first[direction], last[direction])
                    && knot < std::max(first[direction], last[direction])))
                    continue;
                const double fraction = (knot - first[direction]) / (last[direction] - first[direction]);
                if (!std::isfinite(fraction) || !(fraction > 0 && fraction < 1))
                    throw std::runtime_error("Native tessellation cannot represent a shared crease crossing");
                cuts[fraction].push_back({index, direction, knot});
            }
    }
    return cuts;
}

void verify_parametric_partition(const BRep& brep, const ParametricBoundaryUse& use) {
    const NurbsSurface& surface = brep.m_surfaces[brep.m_faces[use.face].surface_index];
    const std::array<std::vector<double>, 2> knots = parametric_crease_knots(surface);
    for (size_t i = 1; i < use.samples.size(); ++i) {
        const Point& first = std::get<1>(use.samples[i - 1]);
        const Point& last = std::get<1>(use.samples[i]);
        for (int direction = 0; direction < 2; ++direction)
            for (double knot : knots[direction])
                if (knot > std::min(first[direction], last[direction])
                    && knot < std::max(first[direction], last[direction]))
                    throw std::runtime_error("Native tessellation shared crease partition is unresolved");
    }
}

bool split_parametric_edge(const BRep& brep, std::vector<ParametricBoundaryUse>& uses, size_t& added) {
    const std::vector<ParametricBoundarySample> canonical = uses[0].samples;
    for (size_t i = 1; i < uses.size(); ++i)
        if (!align_parametric_use(canonical, uses[i]))
            throw std::runtime_error("Native tessellation has incompatible shared edge sample ancestry");
    std::vector<std::vector<ParametricBoundarySample>> expanded(uses.size());
    bool changed = false;
    for (size_t segment = 0; segment + 1 < canonical.size(); ++segment) {
        const ParametricCuts cuts = parametric_segment_cuts(brep, uses, segment);
        changed |= cuts.size() > 2;
        for (const auto& cut : cuts) {
            if (cut.first == 1 && segment + 2 < canonical.size())
                continue;
            if (cut.first != 0 && cut.first != 1 && ++added > 200000)
                throw std::runtime_error("Native tessellation exceeded its shared boundary node budget");
            const Point& a = std::get<2>(canonical[segment]);
            const Point& b = std::get<2>(canonical[segment + 1]);
            const Point point = cut.first == 0 ? a : cut.first == 1 ? b : a + (b - a) * cut.first;
            for (size_t index = 0; index < uses.size(); ++index) {
                const ParametricBoundarySample& first = uses[index].samples[segment];
                const ParametricBoundarySample& last = uses[index].samples[segment + 1];
                Point uv = cut.first == 0 ? std::get<1>(first) : cut.first == 1 ? std::get<1>(last)
                    : std::get<1>(first) + (std::get<1>(last) - std::get<1>(first)) * cut.first;
                for (const ParametricPin& pin : cut.second)
                    if (std::get<0>(pin) == index)
                        uv[std::get<1>(pin)] = std::get<2>(pin);
                const double parameter = cut.first == 0 ? std::get<0>(first) : cut.first == 1 ? std::get<0>(last)
                    : std::get<0>(first) + (std::get<0>(last) - std::get<0>(first)) * cut.first;
                expanded[index].push_back({parameter, uv, point});
            }
        }
    }
    for (size_t i = 0; i < uses.size(); ++i) {
        uses[i].samples = std::move(expanded[i]);
        verify_parametric_partition(brep, uses[i]);
        if (uses[i].reversed)
            std::reverse(uses[i].samples.begin(), uses[i].samples.end());
    }
    return changed;
}

/// Refine the canonical samples of each edge against every surface using it: the first face to sample an edge cannot see how its neighbour's normals turn along it, and a span the neighbour cannot follow leaves a needle beside the boundary at any density. Strip and ruled faces pace their own loops, so their edges stay.
std::set<int> refine_parametric_boundaries(const BRep& brep, const std::vector<bool>& paced, EdgeBoundary& boundary,
                                           double scale, double angle, double chord) {
    std::map<int, std::vector<std::pair<int, BRepRef>>> uses;
    for (int face = 0; face < brep.face_count(); ++face)
        for (const BRepRef& wire : brep.m_faces[face].wires)
            for (const BRepRef& edge : brep.wire_edges(wire))
                if (!brep.m_edges[edge.index].degenerated)
                    uses[edge.index].push_back({face, edge});
    std::set<int> rebuild;
    for (const auto& group : uses) {
        if (std::any_of(group.second.begin(), group.second.end(), [&](const std::pair<int, BRepRef>& use) { return paced[use.first]; }))
            continue;
        for (const std::pair<int, BRepRef>& use : group.second) {
            std::vector<std::tuple<double, Point, Point>> samples;
            if (!edge_use_samples(brep, use.first, use.second, boundary, scale, angle, chord, samples))
                continue;
            const NurbsSurface& surface = brep.m_surfaces[brep.m_faces[use.first].surface_index];
            const int pcurve = brep.pcurve_index(group.first, use.first, use.second.orientation);
            const std::vector<std::tuple<double, Point, Point>> refined = refine_surface_boundary(
                surface, brep.m_curves_2d[pcurve], samples, scale, angle, chord);
            if (refined.size() <= samples.size())
                continue;
            std::vector<Point> points;
            for (const std::tuple<double, Point, Point>& sample : refined)
                points.push_back(std::get<2>(sample));
            if (use.second.orientation == BRepOrientation::Reversed)
                std::reverse(points.begin(), points.end());
            boundary.points[group.first] = points;
            boundary.samples.erase(group.first);
            boundary.basis.erase(group.first);
            for (const std::pair<int, BRepRef>& other : group.second)
                rebuild.insert(other.first);
        }
    }
    return rebuild;
}

std::set<int> synchronize_parametric_boundaries(const BRep& brep, const std::vector<bool>& paced, EdgeBoundary& boundary,
                                              double scale, double angle, double chord) {
    if (!mesh_parametric_metadata::capture_depth)
        return {};
    std::set<int> rebuild = refine_parametric_boundaries(brep, paced, boundary, scale, angle, chord);
    std::map<int, std::vector<ParametricBoundaryUse>> groups;
    for (int face = 0; face < brep.face_count(); ++face)
        for (const BRepRef& wire : brep.m_faces[face].wires)
            for (const BRepRef& edge : brep.wire_edges(wire)) {
                if (brep.m_edges[edge.index].degenerated)
                    continue;
                const int pc = brep.pcurve_index(edge.index, face, edge.orientation);
                ParametricBoundaryUse use{face, edge.index, pc, edge.orientation, {}};
                if (!edge_use_samples(brep, face, edge, boundary, scale, angle, chord, use.samples))
                    throw std::runtime_error("Native tessellation cannot collect a shared boundary use");
                groups[edge.index].push_back(std::move(use));
            }
    size_t added = 0;
    for (auto& group : groups) {
        const bool changed = split_parametric_edge(brep, group.second, added);
        for (ParametricBoundaryUse& use : group.second) {
            if (changed)
                rebuild.insert(use.face);
            boundary.parametric_uses[{use.face, use.edge, use.pcurve, int(use.orientation)}] = std::move(use.samples);
        }
    }
    return rebuild;
}

/// Phase 3: trim loops of a CDT face, every edge use keeping its boundary-node identities; false when some edge cannot be sampled
bool trim_loops(
    const BRep& b,
    int fi,
    EdgeBoundary& boundary,
    double scale,
    double angle,
    double chord,
    TrimLoops& loops,
    std::vector<std::tuple<int, size_t, size_t, size_t>>& uses
) {

    const BRepFace& face = b.m_faces[fi];

    for (size_t wi = 0; wi < face.wires.size(); ++wi) {
        std::vector<Point> uv;
        std::vector<Point> xyz;

        for (const BRepRef& er : b.wire_edges(face.wires[wi])) {
            std::vector<std::tuple<double, Point, Point>> samples;

            if (!edge_use_samples(b, fi, er, boundary, scale, angle, chord, samples))
                return false;

            uses.push_back({er.index, wi, uv.size(), samples.size()});

            for (size_t k = 0; k + 1 < samples.size(); ++k) {
                uv.push_back(std::get<1>(samples[k]));
                xyz.push_back(std::get<2>(samples[k]));
            }
        }

        loops.uv.push_back(uv);
        loops.xyz.push_back(xyz);
    }

    return true;
}

/// Plane coordinates of the points in the frame (origin, xaxis, yaxis)
std::vector<std::pair<double, double>> plane_coordinates(const std::vector<Point>& pts, const Point& origin, const Vector& xaxis, const Vector& yaxis) {

    std::vector<std::pair<double, double>> out;
    out.reserve(pts.size());

    for (const Point& p : pts) {
        const Vector d = p - origin;
        out.emplace_back(d.dot(xaxis), d.dot(yaxis));
    }

    return out;
}

/// Signed area of a 2D ring, positive when counter-clockwise
double ring_signed_area(const std::vector<std::pair<double, double>>& pts) {

    double area = 0.0;
    const size_t n = pts.size();

    for (size_t i = 0; i < n; ++i) {
        const size_t j = (i + 1) % n;
        area += pts[i].first * pts[j].second - pts[j].first * pts[i].second;
    }

    return area * 0.5;
}

/// Set every vertex normal and tag every loop vertex boundary/{loop}/{sample} as mesh_loops does
void tag_loop_vertices(Mesh& mesh, const TrimLoops& loops, const Vector& normal) {

    std::map<std::array<double, 3>, std::pair<size_t, size_t>> lookup;

    for (size_t li = 0; li < loops.xyz.size(); ++li)
        for (size_t k = 0; k < loops.xyz[li].size(); ++k) {
            const Point& p = loops.xyz[li][k];
            lookup.emplace(std::array<double, 3>{p[0], p[1], p[2]}, std::make_pair(li, k));
        }

    for (std::pair<const size_t, VertexData>& entry : mesh.vertex) {
        VertexData& vd = entry.second;
        vd.set_normal(normal[0], normal[1], normal[2]);
        const Point position = vd.position();
        const auto hit = lookup.find(std::array<double, 3>{position[0], position[1], position[2]});

        if (hit != lookup.end())
            vd.attributes[fmt::format("boundary/{}/{}", hit->second.first, hit->second.second)] = 1.0;
    }
}

/// Add the border and hole vertices and the CDT triangles of their 2D rings, degenerate triangles skipped
void add_ring_faces(
    Mesh& mesh,
    const std::vector<Point>& border,
    const std::vector<std::vector<Point>>& holes,
    const std::vector<std::pair<double, double>>& border_2d,
    const std::vector<std::vector<std::pair<double, double>>>& holes_2d,
    const std::vector<Point>& border_uv,
    const std::vector<std::vector<Point>>& holes_uv
) {

    std::vector<size_t> vkeys;

    for (const Point& p : border)
        vkeys.push_back(mesh.add_vertex(p));

    for (const std::vector<Point>& hole : holes)
        for (const Point& p : hole)
            vkeys.push_back(mesh.add_vertex(p));

    std::vector<Point> parameters = border_uv;
    if (mesh_parametric_metadata::capture_depth)
        for (const std::vector<Point>& hole : holes_uv)
            parameters.insert(parameters.end(), hole.begin(), hole.end());
    for (const std::array<int, 3>& t : cdt_triangulate(border_2d, holes_2d))
        if (t[0] != t[1] && t[1] != t[2] && t[2] != t[0]) {
            const std::array<size_t, 3> keys = {vkeys[t[0]], vkeys[t[1]], vkeys[t[2]]};
            const std::optional<size_t> face = mesh.add_face({keys[0], keys[1], keys[2]});
            if (face && mesh_parametric_metadata::capture_depth) {
                std::array<mesh_parametric_metadata::UV, 3> uv;
                for (int i = 0; i < 3; ++i)
                    uv[i] = {parameters[t[i]][0], parameters[t[i]][1]};
                mesh_parametric_metadata::triangle(mesh, *face, keys, uv, 4);
            }
        }
}

/// Flip the mesh when its first face winds against the normal
void wind_to_normal(Mesh& mesh, const Vector& normal) {

    if (mesh.face.empty())
        return;

    const std::vector<size_t>& fverts = mesh.face.begin()->second;
    const Point a = mesh.vertex[fverts[0]].position();
    const Point b = mesh.vertex[fverts[1]].position();
    const Point c = mesh.vertex[fverts[2]].position();

    if ((b - a).cross(c - a).dot(normal) < 0.0)
        mesh.flip();
}

/// Phase 3 for a planar face: the sampled loops triangulated as one polygon with holes, wound to the surface normal, every loop vertex tagged boundary/{loop}/{sample} as mesh_loops does; no grid, no surface evaluation
Mesh planar_loops_mesh(const NurbsSurface& srf, const TrimLoops& loops) {

    Mesh mesh;

    if (loops.xyz.empty() || loops.xyz[0].size() < 3)
        return mesh;

    std::vector<Point> all_pts;

    for (const std::vector<Point>& loop : loops.xyz)
        all_pts.insert(all_pts.end(), loop.begin(), loop.end());

    Point origin;
    Vector xaxis;
    Vector yaxis;
    Vector zaxis;
    Polyline(all_pts).get_average_plane(origin, xaxis, yaxis, zaxis);
    std::vector<Point> border = loops.xyz[0];
    std::vector<Point> border_uv;
    if (mesh_parametric_metadata::capture_depth)
        border_uv = loops.uv[0];
    std::vector<std::pair<double, double>> border_2d = plane_coordinates(border, origin, xaxis, yaxis);

    if (ring_signed_area(border_2d) < 0.0) {
        std::reverse(border.begin(), border.end());
        std::reverse(border_2d.begin(), border_2d.end());
        std::reverse(border_uv.begin(), border_uv.end());
    }

    std::vector<std::vector<Point>> holes;
    std::vector<std::vector<Point>> holes_uv;
    std::vector<std::vector<std::pair<double, double>>> holes_2d;

    for (size_t li = 1; li < loops.xyz.size(); ++li) {
        if (loops.xyz[li].size() < 3)
            continue;

        std::vector<Point> hole = loops.xyz[li];
        std::vector<Point> hole_uv;
        if (mesh_parametric_metadata::capture_depth)
            hole_uv = loops.uv[li];
        std::vector<std::pair<double, double>> hole_2d = plane_coordinates(hole, origin, xaxis, yaxis);

        if (ring_signed_area(hole_2d) > 0.0) {
            std::reverse(hole.begin(), hole.end());
            std::reverse(hole_2d.begin(), hole_2d.end());
            std::reverse(hole_uv.begin(), hole_uv.end());
        }

        holes.push_back(hole);
        holes_uv.push_back(hole_uv);
        holes_2d.push_back(hole_2d);
    }

    add_ring_faces(mesh, border, holes, border_2d, holes_2d, border_uv, holes_uv);

    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const Vector normal = srf.normal_at(0.5 * (du.first + du.second), 0.5 * (dv.first + dv.second));
    wind_to_normal(mesh, normal);
    tag_loop_vertices(mesh, loops, normal);

    return mesh;
}

/// Vertex keys per boundary attribute name, so tagging edge uses touches only the vertices each sample owns
std::map<std::string, std::vector<size_t>> boundary_lookup(const Mesh& mesh) {

    std::map<std::string, std::vector<size_t>> lookup;

    for (const std::pair<const size_t, VertexData>& entry : mesh.vertex)
        for (const std::pair<const std::string, double>& attribute : entry.second.attributes)
            if (attribute.first.rfind("boundary", 0) == 0)
                lookup[attribute.first].push_back(entry.first);

    return lookup;
}

/// Tag every boundary vertex of a CDT mesh with the edge use it samples; each use keeps both ends, including the next edge's start
void tag_edge_uses(Mesh& mesh, const TrimLoops& loops, const std::vector<std::tuple<int, size_t, size_t, size_t>>& uses) {

    const std::map<std::string, std::vector<size_t>> lookup = boundary_lookup(mesh);
    const std::vector<size_t> none;

    for (size_t use_id = 0; use_id < uses.size(); ++use_id) {
        int edge = 0;
        size_t li = 0;
        size_t start = 0;
        size_t count = 0;
        std::tie(edge, li, start, count) = uses[use_id];
        const size_t length = loops.uv[li].size();

        if (length == 0)
            continue;

        for (size_t sample = 0; sample < count; ++sample) {
            const std::string key = fmt::format("boundary/{}/{}", li, (start + sample) % length);
            const std::string tag = fmt::format("brep_edge/{}/{}/{}", edge, use_id, sample);

            const auto tagged = lookup.find(key);

            for (const size_t vk : tagged == lookup.end() ? none : tagged->second)
                mesh.vertex[vk].attributes[tag] = 1.0;

            if (sample + 1 >= count)
                continue;

            const std::string interval = fmt::format("boundary_interval/{}/{}", li, (start + sample) % length);
            const std::string interval_tag = fmt::format("brep_edge_interval/{}/{}/{}", edge, use_id, sample);

            const auto crossed = lookup.find(interval);

            for (const size_t vk : crossed == lookup.end() ? none : crossed->second)
                if (mesh.vertex[vk].attributes.count(interval))
                    mesh.vertex[vk].attributes[interval_tag] = mesh.vertex[vk].attributes[interval];
        }
    }
}

/// Phase 0: UV of a pcurve at a fraction of its domain
Point strip_uv(const NurbsCurve& crv, double fraction) {

    const std::pair<double, double> domain = crv.domain();

    return crv.point_at(domain.first + fraction * (domain.second - domain.first));
}

/// Phase 0: a face ruled between two closed loops along one seam, as a cylinder body or a drilled bore: one wire of a loop forward, the seam forward, a loop reversed and the seam reversed, on a surface straight across its rulings, both loops crossing the whole u domain at the same pace and neither sampled yet
bool strip_face(const BRep& b, int fi, const EdgeBoundary& boundary) {

    const BRepFace& face = b.m_faces[fi];

    if (face.wires.size() != 1)
        return false;

    const std::vector<BRepRef> edges = b.wire_edges(face.wires[0]);

    if (edges.size() != 4 || edges[1].index != edges[3].index || edges[1].orientation == edges[3].orientation || edges[0].index == edges[2].index)
        return false;

    const NurbsSurface& srf = b.m_surfaces[face.surface_index];

    if (srf.degree(1) != 1 || srf.cv_count(1) != 2 || srf.is_singular(0) || srf.is_singular(2))
        return false;

    std::vector<const NurbsCurve*> loops;

    for (const int k : {0, 2}) {
        const BRepEdge& edge = b.m_edges[edges[k].index];
        const int ci = b.pcurve_index(edges[k].index, fi, edges[k].orientation);

        if (edge.degenerated || edge.start_vertex != edge.end_vertex || ci < 0 || boundary.points.count(edges[k].index))
            return false;

        loops.push_back(&b.m_curves_2d[ci]);
    }

    const std::pair<double, double> du = srf.domain(0);
    const double tolerance = 1e-9 * (du.second - du.first);
    const double u0 = strip_uv(*loops[0], 0.0)[0];
    const double u1 = strip_uv(*loops[0], 1.0)[0];

    if (std::abs(std::min(u0, u1) - du.first) > tolerance || std::abs(std::max(u0, u1) - du.second) > tolerance)
        return false;

    for (int k = 0; k <= 8; ++k)
        if (std::abs(strip_uv(*loops[0], k / 8.0)[0] - strip_uv(*loops[1], k / 8.0)[0]) > tolerance)
            return false;

    return true;
}

/// Phase 0: a loop sampled at count equal parameter steps as (t, uv, point), closed on its first point, the nearest step of each crease of the surface across u moved onto it, so the strip's rows hold its C0 lines and no shared boundary has a crease to split
std::vector<std::tuple<double, Point, Point>> strip_samples(const NurbsSurface& srf, const NurbsCurve& crv, int count) {

    const std::pair<double, double> domain = crv.domain();
    const double span = domain.second - domain.first;
    std::vector<double> fractions;
    std::map<int, double> pins;

    for (int k = 0; k <= count; ++k)
        fractions.push_back((double)k / count);

    const std::array<std::vector<double>, 2> crease_knots = parametric_crease_knots(srf);

    for (double knot : crease_knots[0]) {
        const bool rising = strip_uv(crv, 0.0)[0] < strip_uv(crv, 1.0)[0];
        double low = 0.0;
        double high = 1.0;

        for (int step = 0; step < 64; ++step) {
            const double middle = 0.5 * (low + high);

            if ((strip_uv(crv, middle)[0] < knot) == rising)
                low = middle;
            else
                high = middle;
        }

        const int nearest = std::clamp((int)std::lround(low * count), 1, count - 1);

        if (!pins.count(nearest)) {
            fractions[nearest] = low;
            pins[nearest] = knot;
        }
    }

    std::vector<std::tuple<double, Point, Point>> samples;

    for (int k = 0; k <= count; ++k) {
        const double t = domain.first + span * fractions[k];
        Point uv = crv.point_at(t);

        if (pins.count(k))
            uv[0] = pins[k];

        samples.push_back({t, uv, k < count ? srf.point_at(uv[0], uv[1]) : std::get<2>(samples[0])});
    }

    return samples;
}

/// Phase 0: how far the chords of a loop at count steps sag from it
double strip_sag(const NurbsSurface& srf, const NurbsCurve& crv, int count) {

    const std::vector<std::tuple<double, Point, Point>> coarse = strip_samples(srf, crv, count);
    const std::vector<std::tuple<double, Point, Point>> fine = strip_samples(srf, crv, 2 * count);
    double sag = 0.0;

    for (int k = 0; k < count; ++k) {
        const Point& a = std::get<2>(coarse[k]);
        const Point& z = std::get<2>(coarse[k + 1]);
        sag = std::max(sag, std::get<2>(fine[2 * k + 1]).distance(a + (z - a) * 0.5));
    }

    return sag;
}

/// Phase 0: the steps a loop asks for on its own: four per control point of its pcurve when that is curved, and four per control point of the surface across u when that is curved, as fresh samples ask of a curve
int strip_steps(const NurbsSurface& srf, const NurbsCurve& crv) {

    int steps = 0;

    if (crv.degree() > 1)
        steps = crv.cv_count() * 4;

    if (srf.degree(0) > 1)
        steps = std::max(steps, srf.cv_count(0) * 4);

    return steps;
}

/// Phase 0: the steps of a strip: the angle's share of a turn and what the loops ask for, scaled by the face's size against the whole BRep so a small bore in a large body keeps few steps, never under thirty-two so a bore still reads round up close, doubled until both loops sag within the chord tolerance measured against the BRep
int strip_count(const NurbsSurface& srf, const NurbsCurve& a, const NurbsCurve& c, double scale, double angle, double chord) {

    const double tolerance = scale * chord;
    const int asked = std::max({strip_steps(srf, a), strip_steps(srf, c), (int)std::ceil(360.0 / std::max(angle, 0.1))});
    const double share = scale > 0.0 ? std::min(bbox_diagonal(srf) / scale, 1.0) : 1.0;
    int count = std::max((int)std::ceil(asked * share), 32);

    while (count < 4096 && tolerance > 0.0 && std::max(strip_sag(srf, a, count), strip_sag(srf, c, count)) > tolerance)
        count *= 2;

    return count;
}

/// Phase 0: a strip vertex at a sample, tagged with its parameters, its normal and its index in the keyhole loop
size_t strip_vertex(const NurbsSurface& srf, Mesh& mesh, const std::tuple<double, Point, Point>& sample, size_t index) {

    const Point& uv = std::get<1>(sample);
    const Vector normal = srf.normal_at(uv[0], uv[1]);
    const size_t key = mesh.add_vertex(std::get<2>(sample));

    mesh.vertex[key].attributes["u"] = uv[0];
    mesh.vertex[key].attributes["v"] = uv[1];
    mesh.vertex[key].attributes[fmt::format("boundary/0/{}", index)] = 1.0;
    mesh.vertex[key].set_normal(normal[0], normal[1], normal[2]);

    return key;
}

/// Phase 0: the strip of a face: both loops sampled at the same steps, closed on their vertex, and made the canonical boundary of their edges, two triangles between every pair of steps, the vertices numbered as the keyhole polygon a CDT face runs (first loop, seam, second loop backwards, seam) so the edge uses tag as there; no surface refinement, no lifting
Mesh strip_mesh(const BRep& b, int fi, EdgeBoundary& boundary, double scale, double angle, double chord) {

    const BRepFace& face = b.m_faces[fi];
    const NurbsSurface& srf = b.m_surfaces[face.surface_index];
    const std::vector<BRepRef> edges = b.wire_edges(face.wires[0]);
    const NurbsCurve& a = b.m_curves_2d[b.pcurve_index(edges[0].index, fi, edges[0].orientation)];
    const NurbsCurve& c = b.m_curves_2d[b.pcurve_index(edges[2].index, fi, edges[2].orientation)];
    const int count = strip_count(srf, a, c, scale, angle, chord);
    std::vector<std::tuple<double, Point, Point>> first = strip_samples(srf, a, count);
    std::vector<std::tuple<double, Point, Point>> second = strip_samples(srf, c, count);
    snap_sample_ends(first, edge_ends(b, edges[0].index));
    snap_sample_ends(second, edge_ends(b, edges[2].index));
    Mesh mesh;
    TrimLoops loops;
    loops.uv.resize(1, std::vector<Point>(2 * count + 2));
    loops.xyz.resize(1, std::vector<Point>(2 * count + 2));
    std::vector<size_t> bottom;
    std::vector<size_t> top;

    for (int k = 0; k <= count; ++k) {
        bottom.push_back(strip_vertex(srf, mesh, first[k], k));
        top.push_back(strip_vertex(srf, mesh, second[k], 2 * count + 1 - k));
        loops.uv[0][k] = std::get<1>(first[k]);
        loops.xyz[0][k] = std::get<2>(first[k]);
        loops.uv[0][2 * count + 1 - k] = std::get<1>(second[k]);
        loops.xyz[0][2 * count + 1 - k] = std::get<2>(second[k]);
        boundary.points[edges[0].index].push_back(std::get<2>(first[k]));
        boundary.points[edges[2].index].push_back(std::get<2>(second[k]));
    }

    for (int k = 0; k < count; ++k) {
        mesh.add_face({bottom[k], bottom[k + 1], top[k + 1]});
        mesh.add_face({bottom[k], top[k + 1], top[k]});
    }

    const Point& start = std::get<1>(first[0]);
    wind_to_normal(mesh, srf.normal_at(start[0], start[1]));
    const std::vector<std::tuple<int, size_t, size_t, size_t>> uses = {
        {edges[0].index, 0, 0, (size_t)count + 1},
        {edges[1].index, 0, (size_t)count, 2},
        {edges[2].index, 0, (size_t)count + 1, (size_t)count + 1},
        {edges[3].index, 0, 2 * (size_t)count + 1, 2},
    };
    tag_edge_uses(mesh, loops, uses);

    return mesh;
}

/// Phase 1: the side of the surface domain a straight two-point pcurve runs along, corner to corner: 0 along v0, 1 along v1, 2 along u0, 3 along u1; -1 for any other pcurve
int ruled_side(const NurbsSurface& srf, const NurbsCurve& crv) {

    if (crv.degree() != 1 || crv.is_rational() || crv.cv_count() != 2)
        return -1;

    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const double tolerance_u = (du.second - du.first) * 1e-9;
    const double tolerance_v = (dv.second - dv.first) * 1e-9;
    const Point c0 = crv.get_cv(0);
    const Point c1 = crv.get_cv(1);

    for (const Point& p : {c0, c1}) {
        const bool corner_u = std::min(std::abs(p[0] - du.first), std::abs(p[0] - du.second)) <= tolerance_u;
        const bool corner_v = std::min(std::abs(p[1] - dv.first), std::abs(p[1] - dv.second)) <= tolerance_v;

        if (!corner_u || !corner_v)
            return -1;
    }

    if (std::abs(c0[1] - c1[1]) <= tolerance_v && std::abs(c0[0] - c1[0]) > tolerance_u)
        return std::abs(c0[1] - dv.first) <= tolerance_v ? 0 : 1;

    if (std::abs(c0[0] - c1[0]) <= tolerance_u && std::abs(c0[1] - c1[1]) > tolerance_v)
        return std::abs(c0[0] - du.first) <= tolerance_u ? 2 : 3;

    return -1;
}

/// Phase 1: true when the normals along a ruling turn past the angle: a ruled mesh has no vertex between the ends of a ruling, so such a twisted surface is no ruled face however fine its stations
bool ruled_twists(const NurbsSurface& srf, double angle) {

    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const double cosine = std::cos(std::clamp(angle, 0.1, 179.0) * Tolerance::PI / 180.0);

    for (int k = 0; k <= 16; ++k) {
        const double u = du.first + (du.second - du.first) * (.0625 + k * .875 / 16);
        const Vector first = srf.normal_at(u, dv.first);
        const Vector last = srf.normal_at(u, dv.second);

        if (first.magnitude_squared() > 0.0 && last.magnitude_squared() > 0.0 && first.dot(last) < cosine)
            return true;
    }

    return false;
}

/// Phase 1: a face on the whole domain of a curved surface straight across its rulings, its wire four distinct open edges each a straight pcurve along one domain side: the place in the wire of the edge along v0, so the wire turned there reads as the loop at v0, a ruling, the loop at v1 and a ruling; -1 for any other face
int ruled_face(const BRep& b, int fi) {

    const BRepFace& face = b.m_faces[fi];

    if (face.wires.size() != 1)
        return -1;

    const std::vector<BRepRef> edges = b.wire_edges(face.wires[0]);
    const NurbsSurface& srf = b.m_surfaces[face.surface_index];

    if (edges.size() != 4 || srf.degree(1) != 1 || srf.cv_count(1) != 2 || is_planar_patch(srf))
        return -1;

    for (int side = 0; side < 4; ++side)
        if (srf.is_singular(side))
            return -1;

    std::array<int, 4> sides = {-1, -1, -1, -1};

    for (size_t k = 0; k < 4; ++k) {
        const BRepEdge& edge = b.m_edges[edges[k].index];
        const int ci = b.pcurve_index(edges[k].index, fi, edges[k].orientation);

        for (size_t j = 0; j < k; ++j)
            if (edges[j].index == edges[k].index)
                return -1;

        if (edge.degenerated || edge.start_vertex == edge.end_vertex || ci < 0)
            return -1;

        sides[k] = ruled_side(srf, b.m_curves_2d[ci]);
    }

    for (int side = 0; side < 4; ++side)
        if (std::count(sides.begin(), sides.end(), side) != 1)
            return -1;

    const int shift = (int)(std::find(sides.begin(), sides.end(), 0) - sides.begin());

    return sides[(shift + 2) % 4] == 1 ? shift : -1;
}

/// Phase 1: the wire of a ruled face turned to start at its loop along v0
std::vector<BRepRef> ruled_edges(const BRep& b, int fi, int shift) {

    std::vector<BRepRef> edges = b.wire_edges(b.m_faces[fi].wires[0]);
    std::rotate(edges.begin(), edges.begin() + shift, edges.end());

    return edges;
}

/// Phase 1: the distinct nurbsknots of a ruled face's surface across u from the start of its domain to its end: the spans within which its loops are smooth, so a kink between two spans never asks for steps
std::vector<double> ruled_spans(const NurbsSurface& srf) {

    const std::pair<double, double> du = srf.domain(0);
    const double tolerance = (du.second - du.first) * 1e-9;
    std::vector<double> spans = {du.first};

    for (int k = 0; k < srf.nurbsknot_count(0); ++k) {
        const double knot = srf.nurbsknot(0, k);

        if (knot > spans.back() + tolerance && knot < du.second - tolerance)
            spans.push_back(knot);
    }

    spans.push_back(du.second);

    return spans;
}

/// Phase 1: the stations across u of a ruled face: every span at its own count of equal steps
std::vector<double> ruled_steps(const std::vector<double>& spans, const std::vector<int>& counts) {

    std::vector<double> steps;

    for (size_t span = 0; span + 1 < spans.size(); ++span)
        for (int k = 0; k < counts[span]; ++k)
            steps.push_back(spans[span] + (spans[span + 1] - spans[span]) * k / counts[span]);

    steps.push_back(spans.back());

    return steps;
}

/// Phase 1: how far one span of a ruled face at count equal steps is from the quality asked, on whichever loop and step is worse: the sag of a chord over the tolerance or the turn of the normals over the angle, as a share of what is allowed; zero or below when the span passes, the normals taken just inside a step so a kink at a station is not a turn
double ruled_excess(const NurbsSurface& srf, double u0, double u1, int count, double cosine, double tolerance) {

    const std::pair<double, double> dv = srf.domain(1);
    double excess = -1.0;

    for (const double v : {dv.first, dv.second})
        for (int k = 0; k < count; ++k) {
            const double ua = u0 + (u1 - u0) * k / count;
            const double ub = u0 + (u1 - u0) * (k + 1) / count;
            const double inside = (ub - ua) * 1e-6;
            const Point a = srf.point_at(ua, v);
            const Point z = srf.point_at(ub, v);
            const Point middle = srf.point_at((ua + ub) * 0.5, v);
            const double sag = middle.distance(a + (z - a) * 0.5);
            const double dot = srf.normal_at(ua + inside, v).dot(srf.normal_at(ub - inside, v));
            excess = std::max({excess, tolerance > 0.0 ? sag / tolerance - 1.0 : -1.0, (cosine - dot) / (1.0 - cosine)});
        }

    return excess;
}

/// Phase 1: the steps of every span of a ruled face: one, doubled while the span is coarser than the chord tolerance measured against the whole BRep or the angle allows and doubling still brings it closer, so a kink or a fold inside a span does not ask for ever more steps; 4096 stations at most over all spans
std::vector<int> ruled_counts(const NurbsSurface& srf, const std::vector<double>& spans, double scale, double angle, double chord) {

    const double tolerance = scale * chord;
    const double cosine = std::cos(std::clamp(angle, 0.1, 179.0) * Tolerance::PI / 180.0);
    std::vector<int> counts(spans.size() - 1, 1);
    int total = (int)counts.size();

    for (size_t span = 0; span + 1 < spans.size(); ++span) {
        double excess = ruled_excess(srf, spans[span], spans[span + 1], counts[span], cosine, tolerance);

        while (excess > 0.0 && total + counts[span] <= 4096) {
            const double finer = ruled_excess(srf, spans[span], spans[span + 1], 2 * counts[span], cosine, tolerance);

            if (finer > 0.75 * excess)
                break;

            total += counts[span];
            counts[span] *= 2;
            excess = finer;
        }
    }

    return counts;
}

/// Phase 1: the canonical points of a loop of a ruled face lifted onto the face along the loop's own iso curve, each the parameter of its closest point there searched between the neighbours of its nearest sample of the curve, in the loop's traversal order with equal parameters kept once; empty while nobody has sampled the edge
std::vector<std::tuple<double, Point, Point>> ruled_lift(const BRep& b, int fi, const BRepRef& er, const EdgeBoundary& boundary) {

    std::vector<std::tuple<double, Point, Point>> samples;

    if (!boundary.points.count(er.index))
        return samples;

    const NurbsSurface& srf = b.m_surfaces[b.m_faces[fi].surface_index];
    const NurbsCurve& crv = b.m_curves_2d[b.pcurve_index(er.index, fi, er.orientation)];
    const Point c0 = crv.get_cv(0);
    const Point c1 = crv.get_cv(1);
    const NurbsCurve iso = srf.iso_curve(0, c0[1]);
    const std::pair<double, double> domain = crv.domain();
    const std::pair<double, double> du = srf.domain(0);
    const int count = std::max(50, iso.cv_count() * 10);
    std::vector<Point> table;

    for (int k = 0; k <= count; ++k)
        table.push_back(iso.point_at(du.first + (du.second - du.first) * k / count));

    for (const Point& p : boundary.points.at(er.index)) {
        int nearest = 0;

        for (int k = 1; k <= count; ++k)
            if (table[k].distance(p) < table[nearest].distance(p))
                nearest = k;

        const double lo = du.first + (du.second - du.first) * std::max(nearest - 1, 0) / count;
        const double hi = du.first + (du.second - du.first) * std::min(nearest + 1, count) / count;
        const double u = Closest::curve_point(iso, p, lo, hi).first;
        const double t = domain.first + (domain.second - domain.first) * (u - c0[0]) / (c1[0] - c0[0]);
        samples.push_back({t, Point(u, c0[1], 0.0), p});
    }

    std::sort(samples.begin(), samples.end(), sample_less);
    samples.erase(std::unique(samples.begin(), samples.end(), sample_equal), samples.end());

    return samples;
}

/// Phase 1: the stations across u where a ruled face runs its rulings: its own steps in every span and the u of every canonical point of either loop, sorted and merged within the tolerance
std::vector<double> ruled_stations(
    const std::vector<double>& spans,
    const std::vector<int>& counts,
    const std::vector<std::tuple<double, Point, Point>>& first,
    const std::vector<std::tuple<double, Point, Point>>& second,
    double tolerance
) {

    std::vector<double> stations = ruled_steps(spans, counts);

    for (const std::vector<std::tuple<double, Point, Point>>* lifted : {&first, &second})
        for (const std::tuple<double, Point, Point>& sample : *lifted)
            stations.push_back(std::get<1>(sample)[0]);

    std::sort(stations.begin(), stations.end());
    std::vector<double> merged;

    for (const double u : stations)
        if (merged.empty() || u - merged.back() > tolerance)
            merged.push_back(u);

    return merged;
}

/// Phase 1: the stations a loop of a ruled face has no canonical point at yet, added to its edge at the loop's v up to 4096 points on the edge, the domain ends snapped onto the edge's vertices; true when any was added
bool ruled_extend(
    const NurbsSurface& srf,
    double v,
    const std::vector<double>& stations,
    const std::vector<std::tuple<double, Point, Point>>& lifted,
    double tolerance,
    const std::pair<Point, Point>& ends,
    std::vector<Point>& points
) {

    const std::pair<double, double> du = srf.domain(0);
    bool added = false;

    for (const double u : stations) {
        bool present = false;

        for (const std::tuple<double, Point, Point>& sample : lifted)
            present = present || std::abs(std::get<1>(sample)[0] - u) <= tolerance;

        if (present || points.size() >= 4096)
            continue;

        Point p = srf.point_at(u, v);

        if (std::abs(u - du.first) <= tolerance || std::abs(u - du.second) <= tolerance)
            p = p.distance(ends.first) <= p.distance(ends.second) ? ends.first : ends.second;

        points.push_back(p);
        added = true;
    }

    return added;
}

/// Phase 1: the rulings of every ruled face agreed with its neighbours: each pass every face asks its stations of both loops and adds the points a loop lacks, which the faces sharing that edge pick up on the next pass, until no face adds a point or sixteen passes are spent
void ruled_boundaries(const BRep& b, const std::vector<int>& face_ruled, EdgeBoundary& boundary, double scale, double angle, double chord) {

    std::vector<std::vector<double>> spans(face_ruled.size());
    std::vector<std::vector<int>> counts(face_ruled.size());

    for (size_t fi = 0; fi < face_ruled.size(); ++fi)
        if (face_ruled[fi] >= 0) {
            spans[fi] = ruled_spans(b.m_surfaces[b.m_faces[fi].surface_index]);
            counts[fi] = ruled_counts(b.m_surfaces[b.m_faces[fi].surface_index], spans[fi], scale, angle, chord);
        }

    for (int pass = 0; pass < 16; ++pass) {
        bool changed = false;

        for (size_t fi = 0; fi < face_ruled.size(); ++fi) {
            if (face_ruled[fi] < 0)
                continue;

            const NurbsSurface& srf = b.m_surfaces[b.m_faces[fi].surface_index];
            const std::vector<BRepRef> edges = ruled_edges(b, (int)fi, face_ruled[fi]);
            const std::pair<double, double> du = srf.domain(0);
            const std::pair<double, double> dv = srf.domain(1);
            const double tolerance = (du.second - du.first) * 1e-6;
            const std::vector<std::tuple<double, Point, Point>> first = ruled_lift(b, (int)fi, edges[0], boundary);
            const std::vector<std::tuple<double, Point, Point>> second = ruled_lift(b, (int)fi, edges[2], boundary);
            const std::vector<double> stations = ruled_stations(spans[fi], counts[fi], first, second, tolerance);
            changed = ruled_extend(srf, dv.first, stations, first, tolerance, edge_ends(b, edges[0].index), boundary.points[edges[0].index]) || changed;
            changed = ruled_extend(srf, dv.second, stations, second, tolerance, edge_ends(b, edges[2].index), boundary.points[edges[2].index]) || changed;
        }

        if (!changed)
            return;
    }
}

/// Phase 1: the order of lifted samples by increasing u
std::vector<size_t> ruled_order(const std::vector<std::tuple<double, Point, Point>>& lifted) {

    std::vector<size_t> order(lifted.size());
    std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(), [&lifted](size_t i, size_t j) { return std::get<1>(lifted[i])[0] < std::get<1>(lifted[j])[0]; });

    return order;
}

/// Phase 1: the mesh of a ruled face: both loops at the agreed stations, paired ruling by ruling into two triangles per step so no triangle spans two rulings, degenerate triangles at a collapsed ruling skipped, the loop numbered as the CDT polygon (loop at v0, ruling, loop at v1, ruling) so the edge uses tag as there; empty when the loops disagree on their stations
Mesh ruled_mesh(const BRep& b, int fi, int shift, EdgeBoundary& boundary) {

    const NurbsSurface& srf = b.m_surfaces[b.m_faces[fi].surface_index];
    const std::vector<BRepRef> edges = ruled_edges(b, fi, shift);
    const std::vector<std::tuple<double, Point, Point>> first = ruled_lift(b, fi, edges[0], boundary);
    std::vector<std::tuple<double, Point, Point>> second = ruled_lift(b, fi, edges[2], boundary);
    const size_t n = first.size();

    // the second loop numbered on round the loop, from the ruling where the first ends, so the rulings tag their own two ends
    if (n >= 2 && second.size() == n && std::abs(std::get<1>(first[n - 1])[0] - std::get<1>(second[0])[0]) > std::abs(std::get<1>(first[n - 1])[0] - std::get<1>(second[n - 1])[0]))
        std::reverse(second.begin(), second.end());

    const std::vector<size_t> bottom_order = ruled_order(first);
    const std::vector<size_t> top_order = ruled_order(second);
    const double tolerance = (srf.domain(0).second - srf.domain(0).first) * 1e-6;
    Mesh mesh;

    if (n < 2 || second.size() != n)
        return mesh;

    for (size_t k = 0; k < n; ++k)
        if (std::abs(std::get<1>(first[bottom_order[k]])[0] - std::get<1>(second[top_order[k]])[0]) > tolerance)
            return mesh;

    for (const int k : {1, 3})
        if (!boundary.points.count(edges[k].index)) {
            const std::pair<Point, Point> ends = edge_ends(b, edges[k].index);
            boundary.points[edges[k].index] = {ends.first, ends.second};
        }

    TrimLoops loops;
    loops.uv.resize(1, std::vector<Point>(2 * n));
    loops.xyz.resize(1, std::vector<Point>(2 * n));
    std::vector<size_t> bottom;
    std::vector<size_t> top;

    for (size_t k = 0; k < n; ++k) {
        bottom.push_back(strip_vertex(srf, mesh, first[k], k));
        top.push_back(strip_vertex(srf, mesh, second[k], n + k));
        loops.uv[0][k] = std::get<1>(first[k]);
        loops.xyz[0][k] = std::get<2>(first[k]);
        loops.uv[0][n + k] = std::get<1>(second[k]);
        loops.xyz[0][n + k] = std::get<2>(second[k]);
    }

    for (size_t k = 0; k + 1 < n; ++k) {
        const std::array<size_t, 4> quad = {bottom[bottom_order[k]], bottom[bottom_order[k + 1]], top[top_order[k + 1]], top[top_order[k]]};

        for (const std::array<size_t, 3>& triangle : {std::array<size_t, 3>{quad[0], quad[1], quad[2]}, std::array<size_t, 3>{quad[0], quad[2], quad[3]}}) {
            const Point a = mesh.vertex[triangle[0]].position();
            const Point c = mesh.vertex[triangle[1]].position();
            const Point d = mesh.vertex[triangle[2]].position();

            if (!same_boundary_point(a, c) && !same_boundary_point(c, d) && !same_boundary_point(d, a))
                mesh.add_face({triangle[0], triangle[1], triangle[2]});
        }
    }

    const Point& start = std::get<1>(first[bottom_order[0]]);
    wind_to_normal(mesh, srf.normal_at(start[0], start[1]));
    const std::vector<std::tuple<int, size_t, size_t, size_t>> uses = {
        {edges[0].index, 0, 0, n},
        {edges[1].index, 0, n - 1, 2},
        {edges[2].index, 0, n, n},
        {edges[3].index, 0, 2 * n - 1, 2},
    };
    tag_edge_uses(mesh, loops, uses);

    return mesh;
}

/// Flip every face mesh of a face Reversed in its shell, vertex normals included
void flip_reversed_faces(const BRep& b, std::vector<Mesh>& fmesh) {

    for (int fi = 0; fi < (int)fmesh.size(); ++fi) {
        if (b.face_orientation(fi) != BRepOrientation::Reversed)
            continue;

        fmesh[fi].flip();

        for (std::pair<const size_t, VertexData>& entry : fmesh[fi].vertex) {
            const std::optional<std::array<double, 3>> n = entry.second.normal();

            if (n)
                entry.second.set_normal(-(*n)[0], -(*n)[1], -(*n)[2]);
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Cutting helpers
// ═══════════════════════════════════════════════════════════════════════════
/// Vertex rings of every face in one mesh keyed by BRep vertex index, outer rings wound to the face normal, holes as face holes; false when some face or edge is curved
bool face_rings(const BRep& b, Mesh& rings) {

    bool planar = true;

    for (int vi = 0; vi < b.vertex_count(); ++vi)
        rings.add_vertex(b.m_vertices[vi].point, vi);

    for (int fi = 0; fi < b.face_count(); ++fi) {
        const NurbsSurface& surface = b.m_surfaces[b.m_faces[fi].surface_index];
        const std::pair<double, double> u = surface.domain(0);
        const std::pair<double, double> v = surface.domain(1);
        const Plane frame = Plane::from_point_normal(Point(), b.normal_at(fi, (u.first + u.second) * 0.5, (v.first + v.second) * 0.5));
        std::vector<std::vector<size_t>> loops;
        std::vector<Point> outer;
        planar = planar && is_planar_patch(surface);

        for (const BRepRef& wire : b.m_faces[fi].wires) {
            loops.emplace_back();

            for (const BRepRef& er : b.wire_edges(wire)) {
                const BRepEdge& edge = b.m_edges[er.index];

                if (edge.degenerated)
                    continue;

                planar = planar && b.m_curves_3d[edge.curve_3d_index].degree() == 1;
                loops.back().push_back(er.orientation == BRepOrientation::Reversed ? edge.end_vertex : edge.start_vertex);
            }
        }

        for (size_t vi : loops[0])
            outer.push_back(b.m_vertices[vi].point);

        if (signed_area_in_plane(outer, frame.origin(), frame.x_axis(), frame.y_axis()) < 0.0)
            std::reverse(loops[0].begin(), loops[0].end());

        const std::optional<size_t> fk = rings.add_face(loops[0]);

        if (fk && loops.size() > 1)
            rings.set_face_holes(*fk, {loops.begin() + 1, loops.end()});
    }

    return planar;
}

/// Closed polyline through the positions of a vertex ring of `mesh`
Polyline ring_polyline(const Mesh& mesh, const std::vector<size_t>& ring) {

    std::vector<Point> points;

    for (size_t vk : ring)
        points.push_back(mesh.vertex.at(vk).position());

    points.push_back(points.front());

    return Polyline(points);
}

// ═══════════════════════════════════════════════════════════════════════════
// Serialization helpers
// ═══════════════════════════════════════════════════════════════════════════
/// JSON array of oriented references
nlohmann::ordered_json refs_to_json(const std::vector<BRepRef>& refs) {

    nlohmann::ordered_json arr = nlohmann::ordered_json::array();

    for (const BRepRef& r : refs) {
        nlohmann::ordered_json rj;
        rj["index"] = r.index;
        rj["orientation"] = orientation_to_str(r.orientation);
        arr.push_back(rj);
    }

    return arr;
}

/// Oriented references of a JSON array
std::vector<BRepRef> refs_from_json(const nlohmann::json& arr) {

    std::vector<BRepRef> refs;

    for (const nlohmann::json& r : arr)
        refs.push_back({r.at("index"), orientation_from_str(r.at("orientation"))});

    return refs;
}

BRepCurveUseRange use_range_from_json(const nlohmann::json& value) {
    if (!value.is_array() || value.size()!=2 || !value[0].is_number() || !value[1].is_number())
        throw std::invalid_argument("Curve use range JSON needs two numeric endpoints");
    BRepCurveUseRange range{value[0].get<double>(),value[1].get<double>()};
    if (!std::isfinite(range.first) || !std::isfinite(range.last) || !(range.first<range.last))
        throw std::invalid_argument("Curve use range JSON must be finite and positive");
    return range;
}
bool unknown_range_field(const google::protobuf::Message& message,int number) {
    const auto& fields=message.GetReflection()->GetUnknownFields(message);
    for (int i=0;i<fields.field_count();++i) if (fields.field(i).number()==number) return true;
    return false;
}

/// JSON object of an edge, fields in alphabetical order
nlohmann::ordered_json edge_to_json(const BRepEdge& e) {

    nlohmann::ordered_json ej;
    ej["curve_3d_index"] = e.curve_3d_index;
    ej["degenerated"] = e.degenerated;
    ej["end_vertex"] = e.end_vertex;
    ej["pcurves"] = nlohmann::ordered_json::array();

    for (const BRepCurveOnSurface& pc : e.pcurves) {
        nlohmann::ordered_json pj;
        pj["curve_2d_index"] = pc.curve_2d_index;
        pj["curve_2d_index_2"] = pc.curve_2d_index_2;
        if (pc.primary_range) pj["primary_range"]={pc.primary_range->first,pc.primary_range->last};
        if (pc.secondary_range) pj["secondary_range"]={pc.secondary_range->first,pc.secondary_range->last};
        pj["surface_index"] = pc.surface_index;
        ej["pcurves"].push_back(pj);
    }

    ej["start_vertex"] = e.start_vertex;
    ej["tolerance"] = e.tolerance;
    if (e.world_range) ej["world_range"]={e.world_range->first,e.world_range->last};

    return ej;
}

/// Edge of a JSON object
BRepEdge edge_from_json(const nlohmann::json& e) {

    BRepEdge be;
    be.curve_3d_index = e.at("curve_3d_index");
    be.degenerated = e.at("degenerated");
    be.end_vertex = e.at("end_vertex");

    for (const nlohmann::json& pc:e.at("pcurves")) {
        BRepCurveOnSurface image{pc.at("surface_index"),pc.at("curve_2d_index"),pc.at("curve_2d_index_2")};
        if (pc.contains("primary_range")) image.primary_range=use_range_from_json(pc.at("primary_range"));
        if (pc.contains("secondary_range")) image.secondary_range=use_range_from_json(pc.at("secondary_range"));
        be.pcurves.push_back(std::move(image));
    }
    if (e.contains("world_range")) be.world_range=use_range_from_json(e.at("world_range"));

    be.start_vertex = e.at("start_vertex");
    be.tolerance = e.at("tolerance");

    return be;
}

/// JSON object of a face, facecolor only when set
nlohmann::ordered_json face_to_json(const BRepFace& f) {

    nlohmann::ordered_json fj;

    if (f.facecolor.a > 0)
        fj["facecolor"] = f.facecolor.jsondump();

    fj["surface_index"] = f.surface_index;
    fj["tolerance"] = f.tolerance;
    fj["wires"] = refs_to_json(f.wires);

    return fj;
}

/// Face of a JSON object
BRepFace face_from_json(const nlohmann::json& f) {

    BRepFace bf;

    if (f.contains("facecolor"))
        bf.facecolor = Color::jsonload(f["facecolor"]);

    bf.surface_index = f.at("surface_index");
    bf.tolerance = f.at("tolerance");
    bf.wires = refs_from_json(f.at("wires"));

    return bf;
}

/// Append oriented references to a repeated proto field
void refs_to_proto(const std::vector<BRepRef>& refs, google::protobuf::RepeatedPtrField<session_proto::BRepRef>* out) {

    for (const BRepRef& r : refs) {
        session_proto::BRepRef* p = out->Add();
        p->set_index(r.index);
        p->set_orientation(static_cast<session_proto::BRepOrientation>(r.orientation));
    }
}

/// Oriented references of a repeated proto field
std::vector<BRepRef> refs_from_proto(const google::protobuf::RepeatedPtrField<session_proto::BRepRef>& in) {

    std::vector<BRepRef> refs;

    for (const session_proto::BRepRef& r : in)
        refs.push_back({r.index(), static_cast<BRepOrientation>(r.orientation())});

    return refs;
}

/// Fill a proto edge
void edge_to_proto(const BRepEdge& e, session_proto::BRepEdge* p) {

    p->set_curve_3d_index(e.curve_3d_index);
    p->set_start_vertex(e.start_vertex);
    p->set_end_vertex(e.end_vertex);
    p->set_tolerance(e.tolerance);
    p->set_degenerated(e.degenerated);

    for (const BRepCurveOnSurface& pc : e.pcurves) {
        session_proto::BRepCurveOnSurface* q = p->add_pcurves();
        q->set_surface_index(pc.surface_index);
        q->set_curve_2d_index(pc.curve_2d_index);
        q->set_curve_2d_index_2(pc.curve_2d_index_2);
    }
}

/// Edge of a proto edge
BRepEdge edge_from_proto(const session_proto::BRepEdge& e) {

    BRepEdge be;
    be.curve_3d_index = e.curve_3d_index();
    be.start_vertex = e.start_vertex();
    be.end_vertex = e.end_vertex();
    be.tolerance = e.tolerance();
    be.degenerated = e.degenerated();

    for (const session_proto::BRepCurveOnSurface& pc : e.pcurves())
        be.pcurves.push_back({pc.surface_index(), pc.curve_2d_index(), pc.curve_2d_index_2()});

    return be;
}

/// Fill a proto face, facecolor only when set
void face_to_proto(const BRepFace& f, session_proto::BRepFace* p) {

    p->set_surface_index(f.surface_index);
    refs_to_proto(f.wires, p->mutable_wires());
    p->set_tolerance(f.tolerance);

    if (f.facecolor.a > 0)
        *p->mutable_facecolor() = f.facecolor.to_proto();
}

/// Face of a proto face
BRepFace face_from_proto(const session_proto::BRepFace& f) {

    BRepFace bf;
    bf.surface_index = f.surface_index();
    bf.wires = refs_from_proto(f.wires());
    bf.tolerance = f.tolerance();

    if (f.has_facecolor())
        bf.facecolor = Color::from_proto(f.facecolor());

    return bf;
}

} // namespace

// ═══════════════════════════════════════════════════════════════════════════
// Constructors
// ═══════════════════════════════════════════════════════════════════════════
BRep::BRep() {}

BRep::BRep(const BRep& other) {

    *this = other;
}

BRep& BRep::operator=(const BRep& other) {

    if (this == &other)
        return *this;

    _guid.clear();
    name = other.name;
    is_visible = other.is_visible;
    is_locked = other.is_locked;
    width = other.width;
    surfacecolor = other.surfacecolor;
    m_surfaces = other.m_surfaces;
    m_curves_3d = other.m_curves_3d;
    m_curves_2d = other.m_curves_2d;
    m_vertices = other.m_vertices;
    m_edges = other.m_edges;
    m_wires = other.m_wires;
    m_faces = other.m_faces;
    m_shells = other.m_shells;
    m_solids = other.m_solids;

    return *this;
}

BRep::~BRep() {}

// ═══════════════════════════════════════════════════════════════════════════
// Static constructors
// ═══════════════════════════════════════════════════════════════════════════
BRep BRep::create_box(double sx, double sy, double sz) {

    BRep b;
    b.name = "box";
    box_corners(b, sx, sy, sz);
    PolyFaceBuilder pb{b, {}};
    std::vector<BRepRef> faces;

    for (const std::vector<int>& fv : BOX_FACES)
        faces.push_back({pb.face(quad_patch(b, fv), fv), F});

    b.add_solid({{b.add_shell(faces), F}});

    return b;
}

BRep BRep::create_cylinder(double radius, double height) {

    BRep b;
    b.name = "cylinder";
    const NurbsSurface body = Primitives::cylinder_surface(0, 0, 0, radius, height);
    const Point p_bot = body.point_at_corner(0, 0);
    const Point p_top = body.point_at_corner(0, 1);
    const int v_bot = b.add_vertex(p_bot);
    const int v_top = b.add_vertex(p_top);
    const int e_bot = b.add_edge(b.add_curve_3d(Primitives::circle(0, 0, 0, radius)), v_bot, v_bot);
    const int e_top = b.add_edge(b.add_curve_3d(Primitives::circle(0, 0, height, radius)), v_top, v_top);
    const int e_seam = b.add_edge(b.add_curve_3d(NurbsCurve::create(false, 1, {p_bot, p_top})), v_bot, v_top);
    const int f_body = body_face(b, b.add_surface(body), e_bot, e_seam, e_top);
    const int f_bot = cap_face(b, cap_patch(radius, 0, false), e_bot);
    const int f_top = cap_face(b, cap_patch(radius, height, true), e_top);
    b.add_solid({{b.add_shell({{f_body, F}, {f_bot, F}, {f_top, F}}), F}});

    return b;
}

BRep BRep::create_sphere(double radius) {

    BRep b;
    b.name = "sphere";
    const NurbsSurface srf = Primitives::sphere_surface(0, 0, 0, radius);
    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const double u0 = du.first;
    const double u1 = du.second;
    const double v0 = dv.first;
    const double v1 = dv.second;
    const int v_s = b.add_vertex(Point(0, 0, -radius));
    const int v_n = b.add_vertex(Point(0, 0, radius));
    const int e_seam = b.add_edge(b.add_curve_3d(srf.iso_curve(1, u0)), v_s, v_n);
    const int e_south = b.add_edge(-1, v_s, v_s);
    const int e_north = b.add_edge(-1, v_n, v_n);
    const int si = b.add_surface(srf);
    b.add_pcurve(e_south, si, b.add_curve_2d(uv_line(u0, v0, u1, v0)));
    b.add_pcurve(e_north, si, b.add_curve_2d(uv_line(u0, v1, u1, v1)));
    b.add_pcurve(e_seam, si, b.add_curve_2d(uv_line(u1, v0, u1, v1)), b.add_curve_2d(uv_line(u0, v0, u0, v1)));
    const int fi = b.add_face(si, {{b.add_wire({{e_south, F}, {e_seam, F}, {e_north, R}, {e_seam, R}}), F}});
    b.add_solid({{b.add_shell({{fi, F}}), F}});

    return b;
}

BRep BRep::create_cone(double radius, double height) {

    BRep b;
    b.name = "cone";
    const NurbsSurface body = Primitives::cone_surface(0, 0, 0, radius, height);
    const Point p_base = body.point_at_corner(0, 0);
    const Point p_apex(0, 0, height);
    const int v_base = b.add_vertex(p_base);
    const int v_apex = b.add_vertex(p_apex);
    const int e_base = b.add_edge(b.add_curve_3d(Primitives::circle(0, 0, 0, radius)), v_base, v_base);
    const int e_seam = b.add_edge(b.add_curve_3d(NurbsCurve::create(false, 1, {p_base, p_apex})), v_base, v_apex);
    const int e_apex = b.add_edge(-1, v_apex, v_apex);
    const int f_body = body_face(b, b.add_surface(body), e_base, e_seam, e_apex);
    const int f_base = cap_face(b, cap_patch(radius, 0, false), e_base);
    b.add_solid({{b.add_shell({{f_body, F}, {f_base, F}}), F}});

    return b;
}

BRep BRep::create_pyramid(double base, double height) {

    BRep b;
    b.name = "pyramid";
    const double h = base * 0.5;
    b.add_vertex(Point(-h, -h, 0.0));
    b.add_vertex(Point(h, -h, 0.0));
    b.add_vertex(Point(h, h, 0.0));
    b.add_vertex(Point(-h, h, 0.0));
    const int v_apex = b.add_vertex(Point(0.0, 0.0, height));
    PolyFaceBuilder pb{b, {}};
    const std::vector<int> fv = {0, 3, 2, 1};
    std::vector<BRepRef> faces = {{pb.face(quad_patch(b, fv), fv), F}};

    for (int i = 0; i < 4; ++i) {
        const int a = i;
        const int c = (i + 1) % 4;
        const NurbsSurface srf = bilinear_patch(b.m_vertices[a].point, b.m_vertices[c].point, b.m_vertices[v_apex].point, b.m_vertices[v_apex].point);
        const int si = b.add_surface(srf);
        const int e_ac = pb.edge(a, c);
        const int e_c = pb.edge(c, v_apex);
        const int e_a = pb.edge(a, v_apex);
        const int e_deg = b.add_edge(-1, v_apex, v_apex);
        const bool ac_fwd = b.m_edges[e_ac].start_vertex == a;
        b.add_pcurve(e_ac, si, b.add_curve_2d(ac_fwd ? uv_line(0, 0, 1, 0) : uv_line(1, 0, 0, 0)));
        b.add_pcurve(e_c, si, b.add_curve_2d(uv_line(1, 0, 1, 1)));
        b.add_pcurve(e_deg, si, b.add_curve_2d(uv_line(1, 1, 0, 1)));
        b.add_pcurve(e_a, si, b.add_curve_2d(uv_line(0, 0, 0, 1)));
        const int wire = b.add_wire({{e_ac, ac_fwd ? F : R}, {e_c, F}, {e_deg, F}, {e_a, R}});
        faces.push_back({b.add_face(si, {{wire, F}}), F});
    }

    b.add_solid({{b.add_shell(faces), F}});

    return b;
}

BRep BRep::create_torus(double major_radius, double minor_radius) {

    BRep b;
    b.name = "torus";
    const NurbsSurface srf = Primitives::torus_surface(0, 0, 0, major_radius, minor_radius);
    const std::pair<double, double> du = srf.domain(0);
    const std::pair<double, double> dv = srf.domain(1);
    const double u0 = du.first;
    const double u1 = du.second;
    const double v0 = dv.first;
    const double v1 = dv.second;
    const int v = b.add_vertex(srf.point_at_corner(0, 0));
    const int e_u = b.add_edge(b.add_curve_3d(srf.iso_curve(1, u0)), v, v);
    const int e_v = b.add_edge(b.add_curve_3d(srf.iso_curve(0, v0)), v, v);
    const int si = b.add_surface(srf);
    b.add_pcurve(e_v, si, b.add_curve_2d(uv_line(u0, v0, u1, v0)), b.add_curve_2d(uv_line(u0, v1, u1, v1)));
    b.add_pcurve(e_u, si, b.add_curve_2d(uv_line(u1, v0, u1, v1)), b.add_curve_2d(uv_line(u0, v0, u0, v1)));
    const int fi = b.add_face(si, {{b.add_wire({{e_v, F}, {e_u, F}, {e_v, R}, {e_u, R}}), F}});
    b.add_solid({{b.add_shell({{fi, F}}), F}});

    return b;
}

BRep BRep::create_block_with_hole(double sx, double sy, double sz, double hole_radius) {

    BRep b;
    b.name = "block_with_hole";
    const double hz = sz * 0.5;
    box_corners(b, sx, sy, sz);
    PolyFaceBuilder pb{b, {}};
    std::vector<BRepRef> faces;

    for (int fi = 2; fi < 6; ++fi)
        faces.push_back({pb.face(quad_patch(b, BOX_FACES[fi]), BOX_FACES[fi]), F});

    const Point p_bot(hole_radius, 0, -hz);
    const Point p_top(hole_radius, 0, hz);
    const int v_bot = b.add_vertex(p_bot);
    const int v_top = b.add_vertex(p_top);
    const int e_bot = b.add_edge(b.add_curve_3d(Primitives::circle(0, 0, -hz, hole_radius)), v_bot, v_bot);
    const int e_top = b.add_edge(b.add_curve_3d(Primitives::circle(0, 0, hz, hole_radius)), v_top, v_top);
    const int e_seam = b.add_edge(b.add_curve_3d(NurbsCurve::create(false, 1, {p_bot, p_top})), v_bot, v_top);
    const NurbsSurface bore = Primitives::cylinder_surface(0, 0, -hz, hole_radius, sz);
    faces.push_back({body_face(b, b.add_surface(bore), e_bot, e_seam, e_top), R});

    for (int fi = 0; fi < 2; ++fi) {
        const std::vector<int>& fv = BOX_FACES[fi];
        const NurbsSurface cap = quad_patch(b, fv);
        const int si = b.add_surface(cap);
        const std::vector<BRepRef> outer = pb.wire_refs(si, fv);
        const int e_hole = fi == 0 ? e_bot : e_top;
        const NurbsCurve c2d = project_to_patch(b.m_curves_3d[b.m_edges[e_hole].curve_3d_index], cap);
        const BRepOrientation o = uv_signed_area(c2d) < 0.0 ? F : R;
        b.add_pcurve(e_hole, si, b.add_curve_2d(c2d));
        faces.push_back({b.add_face(si, {{b.add_wire(outer), F}, {b.add_wire({{e_hole, o}}), F}}), F});
    }

    b.add_solid({{b.add_shell(faces), F}});

    return b;
}

BRep BRep::from_polylines(const std::vector<Polyline>& polylines, const std::vector<std::vector<Polyline>>& holes) {

    BRep b;
    b.name = "polysurface";
    const double tol = 1e-6;
    PolyFaceBuilder pb{b, {}};

    for (size_t pi = 0; pi < polylines.size(); ++pi) {
        const std::vector<Point> given = open_points(polylines[pi]);

        if (given.size() < 3)
            continue;

        // corners the weld made one are one corner, and the face is drawn through the welded points: a loop left with less than three is no face
        std::vector<int> vi;

        for (const Point& pt : given) {
            const int vertex = find_or_add_vertex(b, pt, tol);

            if (vi.empty() || vi.back() != vertex)
                vi.push_back(vertex);
        }

        if (vi.size() > 1 && vi.back() == vi.front())
            vi.pop_back();

        if (vi.size() < 3)
            continue;

        std::vector<Point> pts;

        for (const int vertex : vi)
            pts.push_back(b.m_vertices[vertex].point);

        Point org;
        Plane plane;
        Polyline(pts).closed().get_fast_plane(org, plane);

        if (!plane.is_valid())
            continue;

        const Vector xa = plane.x_axis();
        Vector ya = plane.y_axis();

        // a concave outline can turn the averaged normal over: the outer wire must run counter-clockwise in the patch
        if (signed_area_in_plane(pts, org, xa, ya) < 0.0)
            ya *= -1.0;

        const double outer_area = signed_area_in_plane(pts, org, xa, ya);
        std::vector<Point> all_pts = pts;
        std::vector<std::vector<int>> hole_cycles;

        if (pi < holes.size())
            for (const Polyline& h : holes[pi]) {
                std::vector<Point> hp = open_points(h);

                if (hp.size() < 3)
                    continue;

                if (signed_area_in_plane(hp, org, xa, ya) * outer_area > 0.0)
                    std::reverse(hp.begin(), hp.end());

                std::vector<int> cycle;

                for (const Point& pt : hp)
                    cycle.push_back(find_or_add_vertex(b, pt, tol));

                hole_cycles.push_back(cycle);
                all_pts.insert(all_pts.end(), hp.begin(), hp.end());
            }

        pb.face(planar_patch_through(all_pts, org, xa, ya), vi, hole_cycles);
    }

    close_free_faces(b);

    return b;
}

BRep BRep::from_nurbscurves(const std::vector<NurbsCurve>& curves, const std::vector<std::vector<NurbsCurve>>& holes) {

    BRep b;
    b.name = "polysurface";
    const double tol = 1e-6;

    for (int ci = 0; ci < (int)curves.size(); ++ci) {
        const NurbsCurve& crv = curves[ci];
        std::vector<Point> pts = cv_points(crv);

        if (pts.size() >= 2 && pts.front().distance(pts.back()) < tol)
            pts.pop_back();

        if (pts.size() < 3)
            continue;

        Point org;
        Plane plane;
        Polyline(pts).get_fast_plane(org, plane);

        if (!plane.is_valid())
            continue;

        if (ci < (int)holes.size())
            for (const NurbsCurve& h : holes[ci]) {
                const std::vector<Point> hp = cv_points(h);
                pts.insert(pts.end(), hp.begin(), hp.end());
            }

        const int si = b.add_surface(planar_patch_through(pts, org, plane.x_axis(), plane.y_axis()));
        std::vector<BRepRef> wires = {{curve_wire(b, crv, si, tol), F}};

        if (ci < (int)holes.size())
            for (const NurbsCurve& h : holes[ci])
                wires.push_back({curve_wire(b, h, si, tol), F});

        b.add_face(si, wires);
    }

    close_free_faces(b);

    return b;
}

// ═══════════════════════════════════════════════════════════════════════════
// Operators
// ═══════════════════════════════════════════════════════════════════════════
bool BRep::operator==(const BRep& other) const {

    return name == other.name && is_visible == other.is_visible && is_locked == other.is_locked && width == other.width && surfacecolor == other.surfacecolor
        && m_surfaces.size() == other.m_surfaces.size()
        && m_vertices.size() == other.m_vertices.size()
        && m_edges.size() == other.m_edges.size()
        && m_wires.size() == other.m_wires.size()
        && m_faces.size() == other.m_faces.size()
        && m_shells.size() == other.m_shells.size()
        && m_solids.size() == other.m_solids.size();
}

bool BRep::operator!=(const BRep& other) const {

    return !(*this == other);
}

// ═══════════════════════════════════════════════════════════════════════════
// Accessors
// ═══════════════════════════════════════════════════════════════════════════
int BRep::vertex_count() const {

    return (int)m_vertices.size();
}

int BRep::edge_count() const {

    return (int)m_edges.size();
}

int BRep::wire_count() const {

    return (int)m_wires.size();
}

int BRep::face_count() const {

    return (int)m_faces.size();
}

int BRep::shell_count() const {

    return (int)m_shells.size();
}

int BRep::solid_count() const {

    return (int)m_solids.size();
}

bool BRep::is_valid() const {

    if (m_faces.empty())
        return false;

    for (const NurbsSurface& surface : m_surfaces)
        if (!surface.is_valid())
            return false;

    for (const std::vector<NurbsCurve>* curves : {&m_curves_3d, &m_curves_2d})
        for (const NurbsCurve& curve : *curves)
            if (!curve.is_valid())
                return false;

    for (const BRepVertex& vertex : m_vertices) {
        if (!std::isfinite(vertex.tolerance) || vertex.tolerance < 0.0)
            return false;

        for (int axis = 0; axis < 3; ++axis)
            if (!std::isfinite(vertex.point[axis]))
                return false;
    }

    for (const BRepEdge& e : m_edges) {
        if (!std::isfinite(e.tolerance) || e.tolerance < 0.0)
            return false;

        if (!in_range(e.start_vertex, m_vertices.size()) || !in_range(e.end_vertex, m_vertices.size()))
            return false;

        if (e.degenerated && e.start_vertex != e.end_vertex)
            return false;

        if (!e.degenerated && !in_range(e.curve_3d_index, m_curves_3d.size()))
            return false;

        if (e.world_range && (e.degenerated || !brep_curve_use::valid_domain(
            m_curves_3d[e.curve_3d_index],{e.world_range->first,e.world_range->last}))) return false;
        for (const BRepCurveOnSurface& pc : e.pcurves) {
            if (!in_range(pc.surface_index, m_surfaces.size()) || !in_range(pc.curve_2d_index, m_curves_2d.size()))
                return false;

            if (pc.curve_2d_index_2 >= 0 && !in_range(pc.curve_2d_index_2, m_curves_2d.size()))
                return false;
            for (const auto& prior:e.pcurves) {
                if (&prior==&pc) break;
                if (prior.surface_index==pc.surface_index && (e.world_range || pc.primary_range || pc.secondary_range ||
                    prior.primary_range || prior.secondary_range) &&
                    (prior.curve_2d_index!=pc.curve_2d_index || prior.curve_2d_index_2!=pc.curve_2d_index_2 ||
                     prior.primary_range!=pc.primary_range || prior.secondary_range!=pc.secondary_range)) return false;
            }
            if (pc.secondary_range && pc.curve_2d_index_2<0) return false;
            if (e.world_range || pc.primary_range || pc.secondary_range) {
                if (e.degenerated) return false; // UV-only range semantics are not this tranche.
                const auto& world=m_curves_3d[e.curve_3d_index];
                const auto wr=e.world_range?std::pair{e.world_range->first,e.world_range->last}:world.domain();
                for (int slot=0;slot<2;++slot) {
                    const int index=slot?pc.curve_2d_index_2:pc.curve_2d_index;
                    if (index<0) continue;
                    const auto& curve=m_curves_2d[index];const auto& range=slot?pc.secondary_range:pc.primary_range;
                    const auto pr=range?std::pair{range->first,range->last}:curve.domain();
                    if (!brep_curve_use::exact_correspondence(world,wr,curve,pr)) return false;
                }
            }
        }
    }

    for (const BRepWire& w : m_wires) {
        if (w.edges.empty())
            return false;

        for (const BRepRef& r : w.edges)
            if (!in_range(r.index, m_edges.size()))
                return false;

        int start = -1;
        int previous = -1;
        for (const BRepRef& r : w.edges) {
            if (r.orientation == BRepOrientation::Internal || r.orientation == BRepOrientation::External)
                continue;

            const BRepEdge& edge = m_edges[r.index];
            const int first = r.orientation == BRepOrientation::Reversed ? edge.end_vertex : edge.start_vertex;
            const int last = r.orientation == BRepOrientation::Reversed ? edge.start_vertex : edge.end_vertex;
            if (previous >= 0 && previous != first)
                return false;

            if (start < 0)
                start = first;
            previous = last;
        }

        if (start >= 0 && previous != start)
            return false;
    }

    for (const BRepFace& f : m_faces) {
        if (!std::isfinite(f.tolerance) || f.tolerance < 0.0)
            return false;

        if (!in_range(f.surface_index, m_surfaces.size()) || f.wires.empty())
            return false;

        for (const BRepRef& r : f.wires)
            if (!in_range(r.index, m_wires.size()))
                return false;
    }

    for (const BRepShell& s : m_shells) {
        if (s.faces.empty())
            return false;

        for (const BRepRef& r : s.faces)
            if (!in_range(r.index, m_faces.size()))
                return false;
    }

    for (const BRepSolid& s : m_solids) {
        if (s.shells.empty())
            return false;

        for (const BRepRef& r : s.shells)
            if (!in_range(r.index, m_shells.size()))
                return false;
    }

    return true;
}

bool BRep::is_closed(int shell_index) const {

    if (shell_index < 0 || shell_index >= (int)m_shells.size())
        return false;

    std::vector<int> uses(m_edges.size(), 0);
    bool boundary = false;

    for (const BRepRef& fr : m_shells[shell_index].faces) {
        if (!in_range(fr.index, m_faces.size()))
            return false;

        for (const BRepRef& wr : m_faces[fr.index].wires) {
            if (!in_range(wr.index, m_wires.size()))
                return false;

            for (const BRepRef& er : wire_edges(wr)) {
                if (!in_range(er.index, m_edges.size()))
                    return false;

                const BRepOrientation orientation = brep_compose(fr.orientation, er.orientation);
                if (m_edges[er.index].degenerated || orientation == BRepOrientation::Internal || orientation == BRepOrientation::External)
                    continue;

                boundary = true;
                ++uses[er.index];
            }
        }
    }

    for (size_t i = 0; i < m_edges.size(); ++i)
        if (!m_edges[i].degenerated && uses[i] != 0 && uses[i] != 2)
            return false;

    return boundary;
}

bool BRep::is_solid() const {

    if (m_solids.empty() || !is_valid())
        return false;

    for (const BRepSolid& s : m_solids)
        for (const BRepRef& r : s.shells) {
            if (!is_closed(r.index))
                return false;

            std::vector<int> balance(m_edges.size(), 0);
            for (const BRepRef& face : m_shells[r.index].faces)
                for (const BRepRef& wire : m_faces[face.index].wires)
                    for (const BRepRef& edge : wire_edges(wire)) {
                        if (m_edges[edge.index].degenerated)
                            continue;

                        const BRepOrientation orientation = brep_compose(face.orientation, edge.orientation);
                        if (orientation == BRepOrientation::Forward)
                            ++balance[edge.index];
                        else if (orientation == BRepOrientation::Reversed)
                            --balance[edge.index];
                    }

            for (int count : balance)
                if (count != 0)
                    return false;
        }

    return true;
}

BRepOrientation BRep::face_orientation(int face_index) const {

    for (const BRepSolid& solid : m_solids)
        for (const BRepRef& shell : solid.shells) {
            if (!in_range(shell.index, m_shells.size()))
                continue;

            for (const BRepRef& face : m_shells[shell.index].faces)
                if (face.index == face_index)
                    return brep_compose(shell.orientation, face.orientation);
        }

    for (const BRepShell& s : m_shells)
        for (const BRepRef& r : s.faces)
            if (r.index == face_index)
                return r.orientation;

    return BRepOrientation::Forward;
}

int BRep::pcurve_index(int edge_index, int face_index, BRepOrientation orientation) const {

    if (edge_index < 0 || edge_index >= (int)m_edges.size())
        return -1;

    if (face_index < 0 || face_index >= (int)m_faces.size())
        return -1;

    const int si = m_faces[face_index].surface_index;

    for (const BRepCurveOnSurface& pc : m_edges[edge_index].pcurves)
        if (pc.surface_index == si)
            return (orientation == BRepOrientation::Reversed && pc.curve_2d_index_2 >= 0) ? pc.curve_2d_index_2 : pc.curve_2d_index;

    return -1;
}

std::pair<double,double> BRep::edge_domain(int index) const {
    const auto& edge=m_edges.at(index);
    if (edge.degenerated || edge.curve_3d_index<0) throw std::invalid_argument("Degenerated edge has no world use range");
    return brep_curve_use::domain(m_curves_3d.at(edge.curve_3d_index),edge.world_range);
}
std::pair<double,double> BRep::pcurve_domain(int edge_index,int face_index,BRepOrientation orientation) const {
    const auto& edge=m_edges.at(edge_index);const int surface=m_faces.at(face_index).surface_index;
    std::optional<std::pair<double,double>> result;int selected=-1;
    for (const auto& image:edge.pcurves) {
        if (image.surface_index!=surface) continue;
        const bool secondary=orientation==BRepOrientation::Reversed && image.curve_2d_index_2>=0;
        const int index=secondary?image.curve_2d_index_2:image.curve_2d_index;
        if (index<0) throw std::invalid_argument("Boundary has no selected pcurve");
        const auto value=brep_curve_use::domain(m_curves_2d.at(index),secondary?image.secondary_range:image.primary_range);
        if (result && (selected!=index || *result!=value)) throw std::invalid_argument("Ambiguous selected pcurve use range");
        result=value;selected=index;
    }
    if (!result) throw std::invalid_argument("Edge has no pcurve on selected face");
    return *result;
}
bool BRep::has_curve_use_ranges() const {
    for (const auto& edge:m_edges) {
        if (edge.world_range) return true;
        for (const auto& image:edge.pcurves) if (image.primary_range || image.secondary_range) return true;
    }
    return false;
}

bool BRep::has_restricted_curve_uses() const {
    if (!has_curve_use_ranges()) return false;
    if (!is_valid()) throw std::invalid_argument("Cannot inspect restricted uses on invalid range metadata");
    for (const auto& edge:m_edges) {
        if (edge.world_range && std::pair{edge.world_range->first,edge.world_range->last}!=
            m_curves_3d[edge.curve_3d_index].domain()) return true;
        for (const auto& pc:edge.pcurves) {
            if (pc.primary_range && std::pair{pc.primary_range->first,pc.primary_range->last}!=
                m_curves_2d[pc.curve_2d_index].domain()) return true;
            if (pc.secondary_range && std::pair{pc.secondary_range->first,pc.secondary_range->last}!=
                m_curves_2d[pc.curve_2d_index_2].domain()) return true;
        }
    }
    return false;
}

std::vector<BRepRef> BRep::wire_edges(const BRepRef& wire) const {

    std::vector<BRepRef> out;

    if (wire.index < 0 || wire.index >= (int)m_wires.size())
        return out;

    for (const BRepRef& r : m_wires[wire.index].edges)
        out.push_back({r.index, brep_compose(wire.orientation, r.orientation)});

    if (wire.orientation == BRepOrientation::Reversed)
        std::reverse(out.begin(), out.end());

    return out;
}

std::vector<BRepRef> BRep::edge_faces(int edge_index) const {

    std::vector<BRepRef> out;

    for (int fi = 0; fi < (int)m_faces.size(); ++fi) {
        const BRepOrientation fo = face_orientation(fi);

        for (const BRepRef& wr : m_faces[fi].wires)
            for (const BRepRef& er : wire_edges(wr))
                if (er.index == edge_index)
                    out.push_back({fi, brep_compose(fo, er.orientation)});
    }

    return out;
}

std::vector<Point> BRep::vertex_points() const {

    std::vector<Point> pts;

    for (const BRepVertex& v : m_vertices)
        pts.push_back(v.point);

    return pts;
}

std::vector<Polyline> BRep::face_polylines() const {

    return planar_faces(*this).first;
}

std::vector<Plane> BRep::face_planes() const {

    return planar_faces(*this).second;
}

double BRep::update_tolerances() {
    if (has_curve_use_ranges()) throw std::invalid_argument("Range-aware tolerance update is not enabled");

    double worst = 0.0;

    for (BRepEdge& e : m_edges) {
        BRepVertex& vs = m_vertices[e.start_vertex];
        BRepVertex& ve = m_vertices[e.end_vertex];
        double tol = e.tolerance;

        if (e.curve_3d_index >= 0) {
            const NurbsCurve& c = m_curves_3d[e.curve_3d_index];
            tol = std::max(tol, c.point_at(c.domain().first).distance(vs.point));
            tol = std::max(tol, c.point_at(c.domain().second).distance(ve.point));
        }

        for (const BRepCurveOnSurface& pc : e.pcurves) {
            const NurbsSurface& srf = m_surfaces[pc.surface_index];

            for (const int ci : {pc.curve_2d_index, pc.curve_2d_index_2}) {
                if (ci < 0)
                    continue;

                const NurbsCurve& c2 = m_curves_2d[ci];
                const Point a = c2.point_at(c2.domain().first);
                const Point z = c2.point_at(c2.domain().second);
                tol = std::max(tol, srf.point_at(a[0], a[1]).distance(vs.point));
                tol = std::max(tol, srf.point_at(z[0], z[1]).distance(ve.point));
            }
        }

        e.tolerance = tol;
        vs.tolerance = std::max(vs.tolerance, tol);
        ve.tolerance = std::max(ve.tolerance, tol);
        worst = std::max(worst, tol);
    }

    return worst;
}

double BRep::volume() const {

    return mesh().volume();
}

double BRep::volume_exact(double tolerance) const {

    return brep_measure::volume(*this, tolerance);
}

// ═══════════════════════════════════════════════════════════════════════════
// Building
// ═══════════════════════════════════════════════════════════════════════════
int BRep::add_surface(const NurbsSurface& srf) {

    m_surfaces.push_back(srf);

    return (int)m_surfaces.size() - 1;
}

int BRep::add_curve_3d(const NurbsCurve& crv) {

    m_curves_3d.push_back(crv);

    return (int)m_curves_3d.size() - 1;
}

int BRep::add_curve_2d(const NurbsCurve& crv) {

    m_curves_2d.push_back(crv);

    return (int)m_curves_2d.size() - 1;
}

int BRep::add_vertex(const Point& pt, double tolerance) {

    m_vertices.push_back({pt, tolerance});

    return (int)m_vertices.size() - 1;
}

int BRep::add_edge(int curve_3d_index, int start_vertex, int end_vertex, double tolerance) {

    BRepEdge e;
    e.curve_3d_index = curve_3d_index;
    e.start_vertex = start_vertex;
    e.end_vertex = end_vertex;
    e.tolerance = tolerance;
    e.degenerated = curve_3d_index < 0;
    m_edges.push_back(e);

    return (int)m_edges.size() - 1;
}

void BRep::add_pcurve(int edge_index, int surface_index, int curve_2d_index, int curve_2d_index_2) {

    for (BRepCurveOnSurface& pc : m_edges[edge_index].pcurves)
        if (pc.surface_index == surface_index) {
            if (pc.primary_range || pc.secondary_range)
                throw std::invalid_argument("Replacing a ranged pcurve requires explicit range correspondence");
            pc.curve_2d_index = curve_2d_index;
            pc.curve_2d_index_2 = curve_2d_index_2;
            return;
        }

    m_edges[edge_index].pcurves.push_back({surface_index, curve_2d_index, curve_2d_index_2});
}

int BRep::add_wire(const std::vector<BRepRef>& edges) {

    m_wires.push_back({edges});

    return (int)m_wires.size() - 1;
}

int BRep::add_face(int surface_index, const std::vector<BRepRef>& wires, double tolerance) {

    BRepFace f;
    f.surface_index = surface_index;
    f.wires = wires;
    f.tolerance = tolerance;
    m_faces.push_back(f);

    return (int)m_faces.size() - 1;
}

int BRep::add_shell(const std::vector<BRepRef>& faces) {

    m_shells.push_back({faces});

    return (int)m_shells.size() - 1;
}

int BRep::add_solid(const std::vector<BRepRef>& shells) {

    m_solids.push_back({shells});

    return (int)m_solids.size() - 1;
}

// ═══════════════════════════════════════════════════════════════════════════
// Meshing
// ═══════════════════════════════════════════════════════════════════════════
Mesh BRep::mesh() const {

    std::vector<std::vector<Point>> polygons;

    for (const Mesh& fm : face_meshes())
        for (const std::pair<const size_t, std::vector<size_t>>& entry : fm.face) {
            std::vector<Point> poly;

            for (const size_t vi : entry.second)
                poly.push_back(fm.vertex.at(vi).position());

            polygons.push_back(poly);
        }

    return Mesh::from_polylines(polygons, 1e-6);
}

std::vector<Mesh> BRep::face_meshes() const {

    return face_meshes_q(false, 0.0, 0.0);
}


static void tag_parametric_boundaries(const BRep& brep, int face, Mesh& mesh, int path) {
    if (!mesh_parametric_metadata::capture_depth)
        return;
    mesh_parametric_metadata::from_vertices(mesh);
    if (path)
        for (const auto& triangle : mesh.face)
            mesh.facedata[triangle.first]["tessellation_path"] = path;
    std::vector<BRepRef> edges;
    for (const BRepRef& wire : brep.m_faces[face].wires) {
        const std::vector<BRepRef> uses = brep.wire_edges(wire);
        edges.insert(edges.end(), uses.begin(), uses.end());
    }
    for (const auto& triangle : mesh.face)
        for (size_t key : triangle.second) {
            mesh_parametric_metadata::UV uv;
            if (!mesh_parametric_metadata::read(mesh, triangle.first, key, uv))
                continue;
            for (const BRepRef& use : edges) {
                const int index = brep.pcurve_index(use.index, face, use.orientation);
                if (index < 0)
                    continue;
                const NurbsCurve& curve = brep.m_curves_2d[index];
                bool on_boundary = false;
                if (curve.degree() == 1 && curve.cv_count() == 2) {
                    const Point first = curve.get_cv(0), last = curve.get_cv(1);
                    for (int d = 0; d < 2; ++d)
                        on_boundary |= first[d] == last[d] && uv[d] == first[d]
                            && uv[1 - d] >= std::min(first[1 - d], last[1 - d])
                            && uv[1 - d] <= std::max(first[1 - d], last[1 - d]);
                }
                const std::string prefix = "brep_edge/" + std::to_string(use.index) + "/";
                const std::string interval = "brep_edge_interval/" + std::to_string(use.index) + "/";
                for (const auto& attribute : mesh.vertex.at(key).attributes)
                    on_boundary |= attribute.first.starts_with(prefix) || attribute.first.starts_with(interval);
                if (!on_boundary)
                    continue;
                mesh.vertex[key].attributes[prefix + "parametric"] = 1;
                const BRepEdge& edge = brep.m_edges[use.index];
                for (int vertex : {edge.start_vertex, edge.end_vertex}) {
                    const Point point = mesh.vertex.at(key).position();
                    const Point& source = brep.m_vertices[vertex].point;
                    if (point[0] == source[0] && point[1] == source[1] && point[2] == source[2])
                        mesh.vertex[key].attributes["brep_vertex/" + std::to_string(vertex)] = 1;
                }
            }
        }
}

std::vector<Mesh> BRep::face_meshes_q(bool has_quality, double max_angle_deg, double chord_factor) const {

    const int nf = (int)m_faces.size();
    const double angle = has_quality ? max_angle_deg : 20.0;
    const double chord = has_quality ? chord_factor : 0.005;
    const double scale = brep_diagonal(*this);
    std::vector<bool> face_strip(nf, false);
    std::vector<int> face_ruled(nf, -1);
    std::vector<bool> face_direct(nf, false);
    std::vector<bool> rebuild_grid(nf, false);
    std::vector<Mesh> fmesh(nf);
    EdgeBoundary boundary;

    for (int fi = 0; fi < nf; ++fi) {
        face_strip[fi] = strip_face(*this, fi, boundary);

        if (face_strip[fi])
            fmesh[fi] = strip_mesh(*this, fi, boundary, scale, angle, chord);
    }

    for (int fi = 0; fi < nf; ++fi)
        if (!face_strip[fi]) {
            face_ruled[fi] = ruled_face(*this, fi);

            if (mesh_parametric_metadata::capture_depth && face_ruled[fi] >= 0
                && ruled_twists(m_surfaces[m_faces[fi].surface_index], angle))
                face_ruled[fi] = -1;
        }

    ruled_boundaries(*this, face_ruled, boundary, scale, angle, chord);

    for (int fi = 0; fi < nf; ++fi) {
        if (face_ruled[fi] < 0)
            continue;

        fmesh[fi] = ruled_mesh(*this, fi, face_ruled[fi], boundary);

        if (fmesh[fi].face.empty())
            face_ruled[fi] = -1;
    }

    for (int fi = 0; fi < nf; ++fi)
        face_direct[fi] = !face_strip[fi] && face_ruled[fi] < 0 && direct_face(*this, fi);

    for (int fi = 0; fi < nf; ++fi) {
        if (!face_direct[fi])
            continue;

        const NurbsSurface& srf = m_surfaces[m_faces[fi].surface_index];
        fmesh[fi] = has_quality ? RemeshNurbsSurfaceGrid::from_u_v_q(srf, 0, 0, max_angle_deg, chord_factor) : srf.mesh();
        snap_grid_corners(*this, fi, fmesh[fi]);
        rebuild_grid[fi] = grid_boundaries(*this, fi, fmesh[fi], boundary);
    }

    refine_shared_boundaries(*this, face_direct, rebuild_grid, boundary, scale, angle, chord);

    std::vector<bool> paced(nf);
    for (int fi = 0; fi < nf; ++fi)
        paced[fi] = face_strip[fi] || face_ruled[fi] >= 0;

    const std::set<int> synchronized = synchronize_parametric_boundaries(*this, paced, boundary, scale, angle, chord);
    for (int face : synchronized) {
        face_strip[face] = false;
        face_ruled[face] = -1;
        face_direct[face] = false;
        rebuild_grid[face] = true;
    }

    for (int fi = 0; fi < nf; ++fi)
        if (rebuild_grid[fi])
            face_direct[fi] = false;

    for (int fi = 0; fi < nf; ++fi) {
        if (face_strip[fi] || face_ruled[fi] >= 0 || face_direct[fi])
            continue;

        const NurbsSurface& srf = m_surfaces[m_faces[fi].surface_index];
        TrimLoops loops;

        if (rebuild_grid[fi])
            loops.interior_uv = grid_interior_uv(srf, fmesh[fi]);

        std::vector<std::tuple<int, size_t, size_t, size_t>> uses;

        if (!trim_loops(*this, fi, boundary, scale, angle, chord, loops, uses))
            continue;

        if (loops.interior_uv.empty() && is_planar_patch(srf)) {
            fmesh[fi] = planar_loops_mesh(srf, loops);
        } else {
            NurbsSurfaceTrimmed ts;
            ts.m_surface = srf;
            fmesh[fi] = ts.mesh_loops(loops, angle, chord);
        }

        tag_edge_uses(fmesh[fi], loops, uses);
    }

    for (int face = 0; face < nf; ++face)
        tag_parametric_boundaries(*this, face, fmesh[face],
            face_strip[face] ? 1 : face_ruled[face] >= 0 ? 2 : face_direct[face] ? 3 : 0);
    flip_reversed_faces(*this, fmesh);

    return fmesh;
}

// ═══════════════════════════════════════════════════════════════════════════
// Evaluation
// ═══════════════════════════════════════════════════════════════════════════
Point BRep::point_at(int face_index, double u, double v) const {

    if (face_index < 0 || face_index >= (int)m_faces.size())
        return Point();

    return m_surfaces[m_faces[face_index].surface_index].point_at(u, v);
}

Vector BRep::normal_at(int face_index, double u, double v) const {

    if (face_index < 0 || face_index >= (int)m_faces.size())
        return Vector();

    const Vector n = m_surfaces[m_faces[face_index].surface_index].normal_at(u, v);

    if (face_orientation(face_index) == BRepOrientation::Reversed)
        return -n;

    return n;
}

// ═══════════════════════════════════════════════════════════════════════════
// Transformation
// ═══════════════════════════════════════════════════════════════════════════
void BRep::transform(const Xform& xform) {

    for (NurbsSurface& srf : m_surfaces)
        srf.transform(xform);

    for (NurbsCurve& crv : m_curves_3d)
        crv.transform(xform);

    for (BRepVertex& v : m_vertices)
        v.point = xform.transform_point(v.point);
}

BRep BRep::transformed(const Xform& xform) const {

    BRep b = *this;
    b.transform(xform);

    return b;
}

// ═══════════════════════════════════════════════════════════════════════════
// Cutting
// ═══════════════════════════════════════════════════════════════════════════
namespace {

/// Vertices of the bounded intersection of outward plane halfspaces.
std::vector<Point> halfspace_vertices(const std::vector<Plane>& planes, double tolerance) {

    std::vector<Point> points;
    for (size_t i = 0; i < planes.size(); ++i)
        for (size_t j = i + 1; j < planes.size(); ++j)
            for (size_t k = j + 1; k < planes.size(); ++k) {
                const Vector a = planes[i].z_axis();
                const Vector b = planes[j].z_axis();
                const Vector c = planes[k].z_axis();
                const double determinant = a.dot(b.cross(c));
                if (std::abs(determinant) < 1e-12)
                    continue;

                const Point origin = planes[i].origin();
                const double y = b.dot(planes[j].origin() - origin);
                const double z = c.dot(planes[k].origin() - origin);
                const Point point = origin + (c.cross(a) * y + a.cross(b) * z) / determinant;
                bool inside = true;
                for (const Plane& plane : planes)
                    if (plane.z_axis().dot(point - plane.origin()) > tolerance) {
                        inside = false;
                        break;
                    }

                for (const Point& previous : points)
                    if (previous.distance(point) <= tolerance) {
                        inside = false;
                        break;
                    }

                if (inside)
                    points.push_back(point);
            }

    return points;
}

/// Convex boundary polygons on the supporting planes.
std::vector<Polyline> halfspace_polylines(
    const std::vector<Plane>& planes,
    const std::vector<Point>& vertices,
    double tolerance
) {

    std::vector<Polyline> polygons;
    for (const Plane& plane : planes) {
        std::vector<Point> points;
        for (const Point& point : vertices)
            if (std::abs(plane.z_axis().dot(point - plane.origin())) <= tolerance)
                points.push_back(point);

        if (points.size() < 3)
            continue;

        const Point center = Point::centroid(points);
        std::vector<std::pair<double, size_t>> angles;
        for (size_t i = 0; i < points.size(); ++i) {
            const Vector delta = points[i] - center;
            angles.emplace_back(std::atan2(delta.dot(plane.y_axis()), delta.dot(plane.x_axis())), i);
        }
        std::sort(angles.begin(), angles.end());

        std::vector<Point> ordered;
        for (const std::pair<double, size_t>& angle : angles)
            ordered.push_back(points[angle.second]);
        ordered.push_back(ordered.front());
        polygons.emplace_back(ordered);
    }

    return polygons;
}

} // namespace

BRep BRep::offset_convex(double distance, double tolerance) const {

    if (!std::isfinite(distance) || !std::isfinite(tolerance) || tolerance <= 0.0)
        throw std::invalid_argument("BRep::offset_convex requires finite distance and positive tolerance");

    if (!is_solid() || solid_count() != 1 || m_solids[0].shells.size() != 1)
        throw std::invalid_argument("BRep::offset_convex requires one closed solid without cavities");

    if (distance == 0.0)
        return *this;

    std::vector<Plane> planes = face_planes();
    if (planes.size() != m_faces.size())
        throw std::invalid_argument("BRep::offset_convex requires planar faces");

    for (const BRepEdge& edge : m_edges)
        if (edge.degenerated || !m_curves_3d[edge.curve_3d_index].is_linear(tolerance))
            throw std::invalid_argument("BRep::offset_convex requires straight edges");

    for (const Plane& plane : planes)
        for (const BRepVertex& vertex : m_vertices)
            if (plane.z_axis().dot(vertex.point - plane.origin()) > tolerance)
                throw std::invalid_argument("BRep::offset_convex requires convex geometry");

    std::vector<Plane> unique;
    for (const Plane& plane : planes) {
        bool duplicate = false;
        for (const Plane& previous : unique)
            if (plane.z_axis().dot(previous.z_axis()) > 1.0 - 1e-12
                && std::abs(plane.z_axis().dot(plane.origin() - previous.origin())) <= tolerance) {
                duplicate = true;
                break;
            }

        if (!duplicate)
            unique.push_back(plane);
    }
    planes = std::move(unique);

    for (Plane& plane : planes)
        plane = Plane(plane.origin() + plane.z_axis() * distance, plane.x_axis(), plane.y_axis());

    const std::vector<Point> vertices = halfspace_vertices(planes, tolerance);
    if (vertices.size() < 4)
        return BRep();

    Vector axis;
    for (const Point& point : vertices) {
        const Vector delta = point - vertices[0];
        if (delta.dot(delta) > axis.dot(axis))
            axis = delta;
    }

    Vector normal;
    for (const Point& point : vertices) {
        const Vector cross = axis.cross(point - vertices[0]);
        if (cross.dot(cross) > normal.dot(normal))
            normal = cross;
    }

    double height = 0.0;
    for (const Point& point : vertices)
        height = std::max(height, std::abs(normal.dot(point - vertices[0])));

    if (height <= tolerance * normal.magnitude())
        return BRep();

    const std::vector<Polyline> polygons = halfspace_polylines(planes, vertices, tolerance);
    BRep result;
    PolyFaceBuilder builder{result, {}};
    for (const Polyline& polygon : polygons) {
        const std::vector<Point> points = open_points(polygon);
        Point origin;
        Plane plane;
        polygon.get_fast_plane(origin, plane);
        std::vector<int> cycle;
        for (const Point& point : points)
            cycle.push_back(find_or_add_vertex(result, point, tolerance));

        const NurbsSurface surface = planar_patch_through(points, origin, plane.x_axis(), plane.y_axis());
        builder.face(surface, cycle);
    }
    close_free_faces(result);
    if (!result.is_solid())
        throw std::runtime_error("BRep::offset_convex could not construct a closed offset within tolerance");

    result.name = name;
    result.is_visible = is_visible;
    result.is_locked = is_locked;
    result.width = width;
    result.surfacecolor = surfacecolor;

    return result;
}

BRep BRep::boolean_union(const BRep& other, double tolerance) const {

    return brep_boolean::apply(*this, other, brep_boolean::Operation::Union, tolerance);
}

BRep BRep::boolean_intersection(const BRep& other, double tolerance) const {

    return brep_boolean::apply(*this, other, brep_boolean::Operation::Intersection, tolerance);
}

BRep BRep::boolean_difference(const BRep& other, double tolerance) const {

    return brep_boolean::apply(*this, other, brep_boolean::Operation::Difference, tolerance);
}

BRep BRep::boolean_xor(const BRep& other, double tolerance) const {

    return brep_boolean::apply(*this, other, brep_boolean::Operation::Xor, tolerance);
}

BRep BRep::offset(double distance, double tolerance) const {

    return brep_offset::shape(*this, distance, tolerance);
}

BRep BRep::cut_by_plane(const Plane& plane) const {

    Mesh rings;

    if (!face_rings(*this, rings)) {
        const Mesh tessellation = mesh();

        return tessellation.cut_by_plane(plane) == tessellation ? *this : BRep();
    }

    const Mesh cut = rings.cut_by_plane(plane);

    if (cut == rings)
        return *this;

    if (cut.is_empty())
        return BRep();

    std::vector<Polyline> polylines;
    std::vector<std::vector<Polyline>> holes;

    for (const std::pair<const size_t, std::vector<size_t>>& entry : cut.face) {
        polylines.push_back(ring_polyline(cut, entry.second));
        holes.emplace_back();
        const auto it = cut.face_holes.find(entry.first);

        if (it != cut.face_holes.end())
            for (const std::vector<size_t>& hole : it->second)
                holes.back().push_back(ring_polyline(cut, hole));
    }

    BRep result = from_polylines(polylines, holes);
    result.name = name;
    result.width = width;
    result.surfacecolor = surfacecolor;

    return result;
}

// ═══════════════════════════════════════════════════════════════════════════
// JSON
// ═══════════════════════════════════════════════════════════════════════════
nlohmann::ordered_json BRep::jsondump() const {
    if (has_curve_use_ranges() && !is_valid()) throw std::invalid_argument("Cannot serialize invalid original curve use ranges");

    nlohmann::ordered_json j;
    j["curves_2d"] = nlohmann::ordered_json::array();

    for (const NurbsCurve& c : m_curves_2d)
        j["curves_2d"].push_back(c.jsondump());

    j["curves_3d"] = nlohmann::ordered_json::array();

    for (const NurbsCurve& c : m_curves_3d)
        j["curves_3d"].push_back(c.jsondump());

    j["edges"] = nlohmann::ordered_json::array();

    for (const BRepEdge& e : m_edges)
        j["edges"].push_back(edge_to_json(e));

    j["faces"] = nlohmann::ordered_json::array();

    for (const BRepFace& f : m_faces)
        j["faces"].push_back(face_to_json(f));

    j["guid"] = guid();
    j["is_locked"] = is_locked;
    j["is_visible"] = is_visible;
    j["name"] = name;
    j["shells"] = nlohmann::ordered_json::array();

    for (const BRepShell& s : m_shells)
        j["shells"].push_back({{"faces", refs_to_json(s.faces)}});

    j["solids"] = nlohmann::ordered_json::array();

    for (const BRepSolid& s : m_solids)
        j["solids"].push_back({{"shells", refs_to_json(s.shells)}});

    j["surfacecolor"] = surfacecolor.jsondump();
    j["surfaces"] = nlohmann::ordered_json::array();

    for (const NurbsSurface& s : m_surfaces)
        j["surfaces"].push_back(s.jsondump());

    j["type"] = "BRep";
    if (has_curve_use_ranges()) j["curve_use_ranges_version"]=1;
    j["vertices"] = nlohmann::ordered_json::array();

    for (const BRepVertex& v : m_vertices) {
        nlohmann::ordered_json vj;
        vj["point"] = nlohmann::ordered_json::array({v.point[0], v.point[1], v.point[2]});
        vj["tolerance"] = v.tolerance;
        j["vertices"].push_back(vj);
    }

    j["width"] = width;
    j["wires"] = nlohmann::ordered_json::array();

    for (const BRepWire& w : m_wires)
        j["wires"].push_back({{"edges", refs_to_json(w.edges)}});

    return j;
}

BRep BRep::jsonload(const nlohmann::json& data) {
    if (data.value("curve_use_ranges_version",0)>1) throw std::invalid_argument("Unsupported curve use range JSON version");
    BRep b;

    if (data.contains("guid"))
        b.guid() = data["guid"];

    if (data.contains("name"))
        b.name = data["name"];
    b.is_visible = data.value("is_visible", true);
    b.is_locked = data.value("is_locked", false);

    if (data.contains("width"))
        b.width = data["width"];

    if (data.contains("surfacecolor"))
        b.surfacecolor = Color::jsonload(data["surfacecolor"]);

    if (data.contains("curves_2d"))
        for (const nlohmann::json& c : data["curves_2d"])
            b.m_curves_2d.push_back(NurbsCurve::jsonload(c));

    if (data.contains("curves_3d"))
        for (const nlohmann::json& c : data["curves_3d"])
            b.m_curves_3d.push_back(NurbsCurve::jsonload(c));

    if (data.contains("surfaces"))
        for (const nlohmann::json& s : data["surfaces"])
            b.m_surfaces.push_back(NurbsSurface::jsonload(s));

    if (data.contains("vertices"))
        for (const nlohmann::json& v : data["vertices"])
            b.m_vertices.push_back({Point(v.at("point").at(0), v.at("point").at(1), v.at("point").at(2)), v.at("tolerance")});

    if (data.contains("edges"))
        for (const nlohmann::json& e : data["edges"])
            b.m_edges.push_back(edge_from_json(e));

    if (data.contains("wires"))
        for (const nlohmann::json& w : data["wires"])
            b.m_wires.push_back({refs_from_json(w.at("edges"))});

    if (data.contains("faces"))
        for (const nlohmann::json& f : data["faces"])
            b.m_faces.push_back(face_from_json(f));

    if (data.contains("shells"))
        for (const nlohmann::json& s : data["shells"])
            b.m_shells.push_back({refs_from_json(s.at("faces"))});

    if (data.contains("solids"))
        for (const nlohmann::json& s : data["solids"])
            b.m_solids.push_back({refs_from_json(s.at("shells"))});

    if (b.has_curve_use_ranges() && (data.value("curve_use_ranges_version",0)!=1 || !b.is_valid()))
        throw std::invalid_argument("Invalid or unversioned original curve use ranges");
    return b;
}

std::string BRep::file_json_dumps() const {

    return jsondump().dump();
}

BRep BRep::file_json_loads(const std::string& json_string) {

    return jsonload(nlohmann::ordered_json::parse(json_string));
}

void BRep::file_json_dump(const std::string& filename) const {

    std::ofstream file(filename);
    file << jsondump().dump(4);
}

BRep BRep::file_json_load(const std::string& filename) {

    std::ifstream file(filename);
    nlohmann::json data;
    file >> data;

    return jsonload(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// Protobuf
// ═══════════════════════════════════════════════════════════════════════════
session_proto::BRep BRep::to_proto() const {
    if (has_curve_use_ranges()) throw std::invalid_argument("Protobuf curve use ranges are not supported; refusing a lossy export");

    session_proto::BRep proto;

    if (has_guid())
        proto.set_guid(guid());

    proto.set_name(name);

    if (!is_visible)
        proto.set_is_visible(false);

    if (is_locked)
        proto.set_is_locked(true);

    proto.set_width(width);

    for (const NurbsCurve& c : m_curves_2d)
        *proto.add_curves_2d() = c.to_proto();

    for (const NurbsCurve& c : m_curves_3d)
        *proto.add_curves_3d() = c.to_proto();

    for (const NurbsSurface& s : m_surfaces)
        *proto.add_surfaces() = s.to_proto();

    for (const BRepVertex& v : m_vertices) {
        session_proto::BRepVertex* p = proto.add_vertices();
        p->mutable_point()->set_x(v.point[0]);
        p->mutable_point()->set_y(v.point[1]);
        p->mutable_point()->set_z(v.point[2]);
        p->set_tolerance(v.tolerance);
    }

    for (const BRepEdge& e : m_edges)
        edge_to_proto(e, proto.add_edges());

    for (const BRepWire& w : m_wires)
        refs_to_proto(w.edges, proto.add_wires()->mutable_edges());

    for (const BRepFace& f : m_faces)
        face_to_proto(f, proto.add_faces());

    for (const BRepShell& s : m_shells)
        refs_to_proto(s.faces, proto.add_shells()->mutable_faces());

    for (const BRepSolid& s : m_solids)
        refs_to_proto(s.shells, proto.add_solids()->mutable_shells());

    *proto.mutable_surfacecolor() = surfacecolor.to_proto();

    return proto;
}

BRep BRep::from_proto(const session_proto::BRep& proto) {
    for (const auto& edge:proto.edges()) {
        if (unknown_range_field(edge,7)) throw std::invalid_argument("Unsupported protobuf world use range");
        for (const auto& image:edge.pcurves())
            if (unknown_range_field(image,4) || unknown_range_field(image,5))
                throw std::invalid_argument("Unsupported protobuf pcurve use range");
    }

    BRep b;

    if (!proto.guid().empty())
        b.guid() = proto.guid();

    b.name = proto.name();
    b.is_visible = !proto.has_is_visible() || proto.is_visible();
    b.is_locked = proto.is_locked();
    b.width = proto.width();

    for (const session_proto::NurbsCurve& c : proto.curves_2d())
        b.m_curves_2d.push_back(NurbsCurve::from_proto(c));

    for (const session_proto::NurbsCurve& c : proto.curves_3d())
        b.m_curves_3d.push_back(NurbsCurve::from_proto(c));

    for (const session_proto::NurbsSurface& s : proto.surfaces())
        b.m_surfaces.push_back(NurbsSurface::from_proto(s));

    for (const session_proto::BRepVertex& v : proto.vertices())
        b.m_vertices.push_back({Point(v.point().x(), v.point().y(), v.point().z()), v.tolerance()});

    for (const session_proto::BRepEdge& e : proto.edges())
        b.m_edges.push_back(edge_from_proto(e));

    for (const session_proto::BRepWire& w : proto.wires())
        b.m_wires.push_back({refs_from_proto(w.edges())});

    for (const session_proto::BRepFace& f : proto.faces())
        b.m_faces.push_back(face_from_proto(f));

    for (const session_proto::BRepShell& s : proto.shells())
        b.m_shells.push_back({refs_from_proto(s.faces())});

    for (const session_proto::BRepSolid& s : proto.solids())
        b.m_solids.push_back({refs_from_proto(s.shells())});

    b.surfacecolor = Color::from_proto(proto.surfacecolor());

    return b;
}

std::string BRep::pb_dumps() const {

    return to_proto().SerializeAsString();
}

BRep BRep::pb_loads(const std::string& data) {

    session_proto::BRep proto;

    if (!proto.ParseFromString(data))
        throw std::runtime_error("Failed to parse BRep protobuf data");

    return from_proto(proto);
}

void BRep::pb_dump(const std::string& filename) const {

    const std::string data = pb_dumps();
    std::ofstream file(filename, std::ios::binary);
    file.write(data.data(), data.size());
}

BRep BRep::pb_load(const std::string& filename) {

    std::ifstream file(filename, std::ios::binary);
    const std::string data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());

    return pb_loads(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// String
// ═══════════════════════════════════════════════════════════════════════════
std::string BRep::str() const {

    return fmt::format("BRep(name={}, faces={}, edges={}, vertices={})", name, face_count(), edge_count(), vertex_count());
}

std::string BRep::repr() const {

    return fmt::format(
        "BRep(\n  name={},\n  faces={},\n  edges={},\n  vertices={},\n  solid={}\n)",
        name,
        face_count(),
        edge_count(),
        vertex_count(),
        is_solid() ? "true" : "false"
    );
}

std::ostream& operator<<(std::ostream& os, const BRep& brep) {

    os << brep.str();

    return os;
}

} // namespace session_cpp
